//
//  ZCLeaveDetailCell.m
//  SobotKit
//
//  Created by 张新耀 on 2019/9/30.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import "ZCLeaveDetailCell.h"

#import "SobotDateTimes.h"

#import "ZCUIColorsDefine.h"
#import "ZCLibGlobalDefine.h"
#import "ZCUIImageTools.h"
#import "ZCLibSatisfaction.h"
#import "ZCHtmlCore.h"
#import "ZCHtmlFilter.h"
#import "ZCMLEmojiLabel.h"

#import "ZCToolsCore.h"

#import "ZCReplyFileView.h"
#import "ZCDocumentLookController.h"
#import "ZCLibMessage.h"

//#import "ZCXJAlbumController.h"
#import "SobotXHImageViewer.h"
#import "SobotImageView.h"
#import "ZCVideoPlayer.h"
#import "ZCUIWebController.h"
#import "ZCToolsCore.h"

#import "ZCLibMessage.h"
@interface ZCLeaveDetailCell()<ZCMLEmojiLabelDelegate>
{
    ZCRecordListModel *tempModel;// 临时的变量
}

@property (nonatomic,strong) UILabel * timeLab;

@property (nonatomic,strong) UIButton * statusIcon; // 受理状态图标

@property (nonatomic,strong) UILabel * statusLab;

@property (nonatomic,strong) ZCMLEmojiLabel * replycont;// 回复内容
//@property (nonatomic,strong) UILabel * replycont;// 回复内容

@property (nonatomic,strong) UIView * lineView; // 竖线条



@property (nonatomic,strong) UIView *infoCardView;//图片卡片显示

@property (nonatomic,strong) UIView *infoCardLineView;//图片卡片白线

@property (nonatomic,strong) UIButton * detailBtn;//跳转webview显示详情的按钮


@property(nonatomic,strong) void (^btnClickBlock)(ZCRecordListModel *model);//评价按钮点击回调

@property(nonatomic,strong) void (^LookdetailClickBlock)(ZCRecordListModel *model,NSString *urlStr);//显示详细按钮点击回调

@property (nonatomic,strong) UIView *lineView_0;//

@property (nonatomic,strong) UIView *lineView_1;//


@end

@implementation ZCLeaveDetailCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]){
//        self.contentView.backgroundColor = UIColorFromRGB(0xF0F0F0);
        
        _timeLab = [[UILabel alloc]init];
        _timeLab.textColor = UIColorFromThemeColor(ZCTextSubColor);
        _timeLab.font = ZCUIFont10;
        _timeLab.numberOfLines =  2;
        _timeLab.textAlignment = NSTextAlignmentCenter;
//        _timeLab.backgroundColor = [UIColor redColor];
        [self.contentView addSubview:_timeLab];
        
        
        _lineView = [[UIView alloc]init];
        _lineView.backgroundColor = [ZCUITools zcgetBackgroundBottomLineColor];
        [self.contentView addSubview:_lineView];
        
        _statusIcon = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.contentView addSubview:_statusIcon];
        
        
        
        
        _infoCardView = [[UIView alloc] init];
        _infoCardView.backgroundColor = UIColorFromThemeColor(ZCBgChatLightGrayColor);
        _infoCardView.layer.cornerRadius = 4.0;
        _infoCardView.layer.masksToBounds = YES;
        [self.contentView addSubview:_infoCardView];
        
        _infoCardLineView = [[UIView alloc] init];
        _infoCardLineView.backgroundColor = [ZCUITools zcgetCommentButtonLineColor];
        [self.contentView addSubview:_infoCardLineView];
        
        _replycont =  [[ZCMLEmojiLabel alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, 0)];
//        _replycont =  [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, 0)];
//        _replycont.textColor = UIColorFromRGB(TextRecordDetailColor);
        _replycont.font = ZCUIFont14;
        _replycont.numberOfLines = 0;
        _replycont.delegate = self;
        _replycont.lineSpacing = 3.0f;
        _replycont.isNeedAtAndPoundSign = NO;
        _replycont.disableEmoji = NO;
        [_replycont setLinkColor:[ZCUITools zcgetChatLeftLinkColor]];
        _replycont.verticalAlignment = ZCTTTAttributedLabelVerticalAlignmentCenter;
        _replycont.lineBreakMode = NSLineBreakByTruncatingTail;
        [self.contentView addSubview:_replycont];
        
        _detailBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _detailBtn.titleLabel.font = ZCUIFont12;
//        _detailBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [_detailBtn setTitle:ZCSTLocalString(@"查看详情") forState:UIControlStateNormal];
        [_detailBtn setTitleColor:UIColorFromRGB(0x45B2E6) forState:UIControlStateNormal];
        [_detailBtn addTarget:self action:@selector(showDetailAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:_detailBtn];
        _detailBtn.hidden = YES;
        
        
        _statusLab = [[UILabel alloc]init];
        _statusLab.font = ZCUIFontBold14;
        
        [self.contentView addSubview:_statusLab];
        
        _lineView_0 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.contentView.frame.size.width, 0.5)];
                _lineView_0.backgroundColor = [ZCUITools zcgetBackgroundBottomLineColor];
//        _lineView_0.backgroundColor = [UIColor redColor];
        [self.contentView addSubview:_lineView_0];
        
        _lineView_1 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.contentView.frame.size.width, 0.5)];
        _lineView_1.backgroundColor =  [ZCUITools zcgetBackgroundBottomLineColor];
        
        [self.contentView addSubview:_lineView_1];
        
    }
    
    return self;
}

-(void)setShowDetailClickCallback:(void (^)(ZCRecordListModel *model,NSString *urlStr))_detailClickBlock{
    
    _LookdetailClickBlock = _detailClickBlock;
}


-(void)setString:(NSString *)string withlLabel:(UILabel *)label withColor:(UIColor *)textColor {
    [ZCHtmlCore filterHtml: [ZCHtmlCore filterHTMLTag:string] result:^(NSString * _Nonnull text1, NSMutableArray * _Nonnull arr, NSMutableArray * _Nonnull links) {
 
        if (text1.length > 0 && text1 != nil) {
            label.attributedText =   [ZCHtmlFilter setHtml:text1 attrs:arr view:label textColor:textColor textFont:label.font linkColor:[ZCUITools zcgetChatLeftLinkColor]];
        }else{
            label.attributedText =   [[NSAttributedString alloc] initWithString:@""];
        }

    }];
    
}



- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)initWithData:(ZCRecordListModel *)model IndexPath:(NSUInteger)row count:(int)count{
    
    

    
    tempModel = model;
    
    // 回执
    _timeLab.text = @"";
    _statusLab.text = @"";
//    _statusIcon.image = nil;
    _replycont.text = @"";
    
    
    _lineView.frame = CGRectMake(0, 0, 0, 0);
    
    CGFloat cy = 10;
    if(row == 0){
        cy = 21;
    }
    
     //@"2018-04-11 22:22:22";
    NSString *timeText = sobotDateTransformString(@"MM-dd HH:mm", sobotStringFormateDate(model.timeStr));
    if(sobotConvertToString(model.replyTimeStr).length > 8){
        timeText = sobotDateTransformString(@"MM-dd HH:mm", sobotStringFormateDate(model.replyTimeStr));
    }
    
    
    [_timeLab setFrame:CGRectMake(20, cy - 2, 38, 36)];
    
    // 完成、关闭
    CGFloat  lineY = 0;
    
    if(row == 0){
        if(model.flag == 3){
            
            [_statusIcon setImage:[ZCUITools zcuiGetBundleImage:@"zcicon_addleavemsgStatus_3"] forState:0];
            _statusIcon.frame = CGRectMake(64, cy+2, 16, 16);
            _statusIcon.imageView.layer.cornerRadius = 5.0f;
            _statusIcon.imageView.layer.masksToBounds  =  YES;
            lineY = 50;
        }
        else if (model.flag == 2){
            [_statusIcon setImage:[ZCUITools zcuiGetBundleImage:@"zcicon_addleavemsgStatus_2"] forState:0];
            _statusIcon.frame = CGRectMake(64, cy+2, 16, 16);
            _statusIcon.imageView.layer.cornerRadius = 5.0f;
            _statusIcon.imageView.layer.masksToBounds  =  YES;
            lineY = 50;
        }
        else if (model.flag == 1){
            [_statusIcon setImage:[ZCUITools zcuiGetBundleImage:@"zcicon_addleavemsgStatus_1"] forState:0];
            _statusIcon.frame = CGRectMake(64, cy+2, 16, 16);
            _statusIcon.imageView.layer.cornerRadius = 5.0f;
            _statusIcon.imageView.layer.masksToBounds  =  YES;
            lineY = 50;
        }
        
    }else{
        [_statusIcon setImage:[ZCUITools zcuiGetBundleImage:@"zciocn_point_old"] forState:0];
        _statusIcon.frame = CGRectMake(68, cy+6, 8, 8);
        _statusIcon.imageView.layer.cornerRadius = 2.0f;
        _statusIcon.imageView.layer.masksToBounds  =  YES;
        [_statusIcon setBackgroundColor:UIColor.clearColor];
        
        lineY = 0;
    }
    

    
    _statusLab.frame = CGRectMake(92, cy, 160, 20);
    _statusLab.text = ZCSTLocalString(@"已创建");
    [_statusLab setTextAlignment:NSTextAlignmentLeft];

    [_statusLab setTextColor:UIColorFromThemeColor(ZCTextSubColor)];
    
    NSString *tmp = sobotConvertToString(model.replyContent);
    
    
    // 过滤标签 改为过滤图片
//    tmp = [self filterHtmlImage:tmp];
    BOOL isCardView = NO;
    //1 创建了  2 受理了 3 关闭了
    switch (model.flag) {
        case 1:
             _statusLab.text = ZCSTLocalString(@"已创建");
            tmp = @"";
            break;
        case 2:
             _statusLab.text = ZCSTLocalString(@"受理中");
            _timeLab.text =  timeText;
           
            if (model.startType == 0) {
                tmp = @"";//ZCSTLocalString(@"客服回复");
                if (model.replyContent.length > 0) {
                    tmp = sobotConvertToString(model.replyContent);
                    isCardView = [self isContaintImage:tmp];
                    tmp = [self filterHtmlImage:tmp];
                }
            }else if (model.startType == 1){
                
                _statusLab.text = ZCSTLocalString(@"我的回复");
                if (model.replyContent.length > 0) {
                    tmp = sobotConvertToString(model.replyContent);
                    
                    isCardView = [self isContaintImage:tmp];
                    tmp = [self filterHtmlImage:tmp];
                }else{
                    tmp = ZCSTLocalString(@"无");
                }
            }
            break;
        case 3:{
            if (model.startType == 1){
                _statusLab.text = ZCSTLocalString(@"我的回复");
                if (model.replyContent.length > 0) {
                    tmp = sobotConvertToString(model.replyContent);
                    
                    isCardView = [self isContaintImage:tmp];
                    tmp = [self filterHtmlImage:tmp];
                }else{
                    tmp = ZCSTLocalString(@"无");
                }
            }else{
                [_statusLab setTextColor:UIColorFromThemeColor(ZCTextMainColor)];
                _statusLab.text = ZCSTLocalString(@"已完成");
            }
            
            tmp = sobotConvertToString(model.content);
            
            isCardView = [self isContaintImage:tmp];
            tmp = [self filterHtmlImage:tmp];
        }
            break;
        default:
            break;
    }
    
   if(isCardView){
       _replycont.frame = CGRectMake(92 + 15, CGRectGetMaxY(_statusLab.frame) + ZCNumber(2) + 11, ScreenWidth - 92 - 30 - 30, ZCNumber(20));
   }else{
       _replycont.frame = CGRectMake(92, CGRectGetMaxY(_statusLab.frame) + ZCNumber(2), ScreenWidth - 92 - 30, ZCNumber(20));
   }
    
    if(row == 0 ){
        [_replycont setTextColor:UIColorFromThemeColor(ZCTextMainColor)];
        _timeLab.textColor = UIColorFromThemeColor(ZCTextMainColor);
    }
    else{
        [_replycont setTextColor:UIColorFromThemeColor(ZCTextSubColor)];
        _timeLab.textColor = UIColorFromThemeColor(ZCTextSubColor);
    }
    // 富文本赋值
    NSString *text = [[ZCLibMessage new] getHtmlAttrStringWithText:tmp];
    if(text.length == 0){
        _replycont.text = @"";
    }else{
        UIColor *textColor = [ZCUITools zcgetLeftChatTextColor];
        UIColor *linkColor = [ZCUITools zcgetChatLeftLinkColor];
//        textColor = [ZCUITools zcgetRightChatTextColor];
            [ZCHtmlCore filterHtml:text result:^(NSString * _Nonnull text1, NSMutableArray * _Nonnull arr, NSMutableArray * _Nonnull links) {
                if (text1 != nil && text1.length > 0) {
                    NSMutableAttributedString *attr;
                    UIFont *font = [ZCUITools zcgetKitChatFont];
                    attr   =  [ZCHtmlFilter setHtml:text1 attrs:arr view:_replycont textColor:textColor textFont:font linkColor:linkColor];
                    _replycont.attributedText =   attr;
                }else{
                    _replycont.attributedText =   [[NSAttributedString alloc] initWithString:@""];
                }
            }];
    }
//    _replycont.text = tmp;
    if ([timeText containsString:@" "]) {
       if (model.replyTimeStrAttr) {
           _timeLab.attributedText = model.replyTimeStrAttr;
       }else{
           _timeLab.text = timeText;
       }
   }
    
    CGRect replyf = _replycont.frame;
    
    CGRect rf = [self getTextRectWith:replyf.size.width AddLabel:_replycont];
    
    CGFloat h = 0;
    if (isCardView) {
        self.infoCardView.hidden = NO;
        self.infoCardLineView.hidden = NO;
        self.detailBtn.hidden = NO;
        self.infoCardLineView.hidden = NO;
        
        
        [_infoCardView setFrame:CGRectMake(92, CGRectGetMaxY(_statusLab.frame) + 2, ScreenWidth - 92 - 20, rf.size.height + 63)];
        
        [_infoCardLineView setFrame:CGRectMake(92 + 15, CGRectGetMaxY(rf) + 11, ScreenWidth - 92 - 20 - 30, 1)];
        [_detailBtn setFrame:CGRectMake(92,  CGRectGetMaxY(_infoCardLineView.frame) + 11, ScreenWidth - 92 - 20, 18)];

        h = CGRectGetMaxY(_infoCardView.frame) + 10;
    }else{
        self.infoCardView.hidden = YES;
        self.infoCardLineView.hidden = YES;
        self.detailBtn.hidden = YES;
        self.infoCardLineView.hidden = YES;
        
        h = CGRectGetMaxY(_replycont.frame) + 10;
    }
    
    
//    2.8.2 如果 有附件：
    for (UIView *view in [self.contentView subviews]) {
        
        if ([view isKindOfClass:[ZCReplyFileView class]]) {
            [view removeFromSuperview];
        }
    }
    
    if(model.fileList.count > 0 && model.flag != 1) {
        
        float fileBgView_margin_left = 92;
        float fileBgView_margin_top = 0;
        float fileBgView_margin_right = 20;
        float fileBgView_margin = 10;
        
//      宽度固定为  （屏幕宽度 - 60)/3
        CGSize fileViewRect = CGSizeMake((ScreenWidth - 60)/3, 85);
        
//      算一下每行多少个 ，
        float nums = (ScreenWidth - fileBgView_margin_left - fileBgView_margin_right)/(fileViewRect.width + fileBgView_margin);
        NSInteger numInt = floor(nums);
        
//      行数：
        NSInteger rows = ceil(model.fileList.count/(float)numInt);
        
        
        for (int i = 0 ; i < model.fileList.count;i++) {
            NSDictionary *modelDic = model.fileList[i];
            
            NSMutableDictionary *mutDic = [modelDic mutableCopy];
            [mutDic setValue:[NSString stringWithFormat:@"%lu",(unsigned long)row] forKey:@"cellIndex"];
            
            //           当前列数
            NSInteger currentColumn = i%numInt;
//           当前行数
            NSInteger currentRow = i/numInt;
            
            
            float x = fileBgView_margin_left + (fileViewRect.width + fileBgView_margin)*currentColumn;
            float y = h + fileBgView_margin_top + (fileViewRect.height + fileBgView_margin)*currentRow;
            float w = fileViewRect.width;
            float h = fileViewRect.height;
            
            ZCReplyFileView *fileBgView = [[ZCReplyFileView alloc]initWithDic:mutDic withFrame:CGRectMake(x, y, w, h)];
            fileBgView.layer.cornerRadius = 4;
            fileBgView.layer.masksToBounds = YES;
                
            
            [fileBgView setClickBlock:^(NSDictionary * _Nonnull modelDic, UIImageView * _Nonnull imgView) {
               NSString *fileType = modelDic[@"fileType"];
               NSString *fileUrlStr = modelDic[@"fileUrl"];
//                NSArray *imgArray = [[NSArray alloc]initWithObjects:fileUrlStr, nil];
                if ([fileType isEqualToString:@"jpg"] ||
                    [fileType isEqualToString:@"png"] ||
                    [fileType isEqualToString:@"gif"] ) {
                    
                    //     图片预览
                    
                    UIImageView *picView = imgView;
                    CALayer *calayer = picView.layer.mask;
                    [picView.layer.mask removeFromSuperlayer];
                    
                    SobotXHImageViewer *xh=[[SobotXHImageViewer alloc] initWithImageViewerWillDismissWithSelectedViewBlock:^(SobotXHImageViewer *imageViewer, UIImageView *selectedView) {
                        
                    } didDismissWithSelectedViewBlock:^(SobotXHImageViewer *imageViewer, UIImageView *selectedView) {
                        
                        selectedView.layer.mask = calayer;
                        [selectedView setNeedsDisplay];
                    } didChangeToImageViewBlock:^(SobotXHImageViewer *imageViewer, UIImageView *selectedView) {
                        
                    }];
                    
                    NSMutableArray *photos = [[NSMutableArray alloc] init];
                    [photos addObject:picView];
                    xh.disableTouchDismiss = NO;
                    [xh showWithImageViews:photos selectedView:picView];
                    
                    
                }
                else if ([fileType isEqualToString:@"mp4"]){
                    NSURL *imgUrl = [NSURL URLWithString:fileUrlStr];
                    
                     UIWindow *window = [[ZCToolsCore getToolsCore] getCurWindow];
                     ZCVideoPlayer *player = [[ZCVideoPlayer alloc] initWithFrame:window.bounds withShowInView:window url:imgUrl Image:nil];
                     [player showControlsView];
                    
                }
                
                else{
                    ZCLibMessage *message = [[ZCLibMessage alloc]init];
                    ZCLibRich *rich = [[ZCLibRich alloc]init];
                    rich.richmoreurl = fileUrlStr;
                    
                    /**
                    * 13 doc文件格式
                    * 14 ppt文件格式
                    * 15 xls文件格式
                    * 16 pdf文件格式
                    * 17 mp3文件格式
                    * 18 mp4文件格式
                    * 19 压缩文件格式
                    * 20 txt文件格式
                    * 21 其他文件格式
                    */
                    if ([fileType isEqualToString:@"doc"] || [fileType isEqualToString:@"docx"] ) {
                        rich.fileType = 13;
                    }
                    else if ([fileType isEqualToString:@"ppt"]){
                        rich.fileType = 14;
                    }
                    else if ([fileType isEqualToString:@"xls"] || [fileType isEqualToString:@"xlsx"]){
                        rich.fileType = 15;
                    }
                    else if ([fileType isEqualToString:@"pdf"]){
                        rich.fileType = 16;
                    }
                    else if ([fileType isEqualToString:@"mp3"]){
                        rich.fileType = 17;
                    }
//                    else if ([fileType isEqualToString:@"mp4"]){
//                        rich.fileType = 18;
//                    }
                    else if ([fileType isEqualToString:@"zip"]){
                        rich.fileType = 19;
                    }
                    else if ([fileType isEqualToString:@"txt"]){
                        rich.fileType = 20;
                    }
                    else{
                        rich.fileType = 21;
                    }
                    
                    
                    message.richModel = rich;
                    message.richModel.msg = modelDic[@"fileName"];
                    ZCDocumentLookController *docVc = [[ZCDocumentLookController alloc]init];
                    docVc.message = message;
                    [self openNewPage:docVc];
                    
                }
                
                
            }];
            [self.contentView addSubview:fileBgView];
        }
        
        h = h + (fileViewRect.height + fileBgView_margin_top)*rows + 30;
    }
    
    
    if(model.flag == 1){
        _lineView.frame = CGRectMake(72, lineY,0.75,cy);
        //cell大小控制
        self.contentView.frame = CGRectMake(0, 0, ScreenWidth, h+20);
        

        
    }else{
        _lineView.frame = CGRectMake(72, lineY,1,h - lineY + 2);
        //cell大小控制
        self.contentView.frame = CGRectMake(0, 0, ScreenWidth, h);
    }
    
    if(row == 0 ){
        if (count == 1) {
            _lineView.hidden = YES;
        }else{
            _lineView.hidden = NO;
        }
        _statusLab.textColor = UIColorFromThemeColor(ZCTextMainColor);
        _replycont.textColor = UIColorFromThemeColor(ZCTextMainColor);
        
        
    }else{
        _lineView.hidden = NO;
        _statusLab.textColor = UIColorFromThemeColor(ZCTextSubColor);
        _replycont.textColor = UIColorFromThemeColor(ZCTextSubColor);
    }
    
    if (row == 0) {
        _lineView_0.hidden = NO;
        _lineView_1.hidden = YES;
    }
    else if (row == count -1){
        _lineView_0.hidden = YES;
        _lineView_1.hidden = NO;
    }else{
        _lineView_0.hidden = YES;
        _lineView_1.hidden = YES;
    }
    
    if (count == 1) {
        _lineView_0.hidden = NO;
        _lineView_1.hidden = NO;
    }
    

    _lineView.backgroundColor = UIColorFromThemeColor(ZCBgLineColor);
    self.frame = self.contentView.frame;
    
    _lineView_0.frame = CGRectMake(0,0, self.contentView.frame.size.width, 0.5);

    _lineView_1.frame = CGRectMake(0, CGRectGetMaxY(self.frame) - 0.5, self.contentView.frame.size.width, 0.5);
    
    if(sobotIsRTLLayout()){
        [_statusLab setTextAlignment:NSTextAlignmentRight];
        [_replycont setTextAlignment:NSTextAlignmentRight];
        for(UIView *v in self.contentView.subviews){
            [[ZCToolsCore getToolsCore] setRTLFrame:v];
        }
    }
    
}

#pragma mark -- 计算文本高度
-(CGRect)getTextRectWith:(CGFloat)width  AddLabel:(UILabel *)label{
//    if ([str isKindOfClass:[NSAttributedString class]]) {
//        label.attributedText = (NSAttributedString *)str;
//    }else{
//        NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc]initWithString:str];
//        NSMutableParagraphStyle * parageraphStyle = [[NSMutableParagraphStyle alloc]init];
//        [parageraphStyle setLineSpacing:LineSpacing];
//        [attributedString addAttribute:NSParagraphStyleAttributeName value:parageraphStyle range:NSMakeRange(0, [str length])];
//        [attributedString addAttribute:NSFontAttributeName value:label.font range:NSMakeRange(0, str.length)];
//
//        label.attributedText = attributedString;
//
//    }
    
    CGSize size = [self autoHeightOfLabel:label with:width];
    
    CGRect labelF = label.frame;
    labelF.size.height = size.height;
    label.frame = labelF;
    
    
    return labelF;
}



/**
 计算Label高度
 
 @param label 要计算的label，设置了值
 @param width label的最大宽度
 @param type 是否从新设置宽，1设置，0不设置
 */
- (CGSize )autoHeightOfLabel:(UILabel *)label with:(CGFloat )width{
    //Calculate the expected size based on the font and linebreak mode of your label
    // FLT_MAX here simply means no constraint in height
    CGSize maximumLabelSize = CGSizeMake(width, FLT_MAX);
    
    CGSize expectedLabelSize = [label sizeThatFits:maximumLabelSize];// 返回最佳的视图大小
    
    //adjust the label the the new height.
    CGRect newFrame = label.frame;
    newFrame.size.height = expectedLabelSize.height;
    label.frame = newFrame;
    [label updateConstraintsIfNeeded];
    
    return expectedLabelSize;
}




//- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
//    [super setSelected:selected animated:NO];
//
//    // Configure the view for the selected state
//}



-(NSString *)filterHtmlImage:(NSString *)tmp{
    
    NSString *picStr = [NSString stringWithFormat:@"[%@]",ZCSTLocalString(@"图片")];

    NSRegularExpression *regularExpression = [NSRegularExpression regularExpressionWithPattern:@"<img.*?/>" options:0 error:nil];
    tmp  = [regularExpression stringByReplacingMatchesInString:tmp options:0 range:NSMakeRange(0, tmp.length) withTemplate:picStr];
    
//    tmp = [tmp stringByReplacingOccurrencesOfString:@"<br />" withString:@"\n"];
//    tmp = [tmp stringByReplacingOccurrencesOfString:@"<br/>" withString:@"\n"];
//    tmp = [tmp stringByReplacingOccurrencesOfString:@"<br>" withString:@"\n"];
//    tmp = [tmp stringByReplacingOccurrencesOfString:@"<BR/>" withString:@"\n"];
//    tmp = [tmp stringByReplacingOccurrencesOfString:@"<BR />" withString:@"\n"];
//    tmp = [tmp stringByReplacingOccurrencesOfString:@"<p>" withString:@"\n"];
//    tmp = [tmp stringByReplacingOccurrencesOfString:@"</p>" withString:@" "];
//    tmp = [tmp stringByReplacingOccurrencesOfString:@"&nbsp;" withString:@" "];
//    while ([tmp hasPrefix:@"\n"]) {
//        tmp=[tmp substringWithRange:NSMakeRange(1, tmp.length-1)];
//    }
    return tmp;
    
}

-(BOOL)isContaintImage:(NSString *)srcString{
    
    NSRegularExpression *regularExpression = [NSRegularExpression regularExpressionWithPattern:@"<img.*?/>" options:0 error:nil];
    NSArray *result = [regularExpression matchesInString:srcString options:NSMatchingReportCompletion range:NSMakeRange(0, srcString.length)];
    
    return result.count;
    
    
}


-(void)showDetailAction:(UIButton *)btn{
    
    if (self.LookdetailClickBlock) {
        self.LookdetailClickBlock(tempModel,nil);
    }
    
}

#pragma mark EmojiLabel链接点击事件
- (void)ZCMLEmojiLabel:(ZCMLEmojiLabel*)emojiLabel didSelectLink:(NSString*)link withType:(ZCMLEmojiLabelLinkType)type{
    link=[link stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    if (link) {
        NSURL *url = [NSURL URLWithString:link];
        [[ZCToolsCore getToolsCore] dealWithLinkClickWithLick:url.absoluteString viewController:[self getControllerFromView:self]];
    }
}
// 链接点击
-(void)attributedLabel:(ZCTTTAttributedLabel *)label didSelectLinkWithURL:(NSURL *)url{
    // 此处得到model 对象对应的值
//    NSLog(@"url:%@  url.absoluteString:%@",url,url.absoluteString);
//    if (self.LookdetailClickBlock) {
//           self.LookdetailClickBlock(nil,url.absoluteString);
//       }
//    else{
//
//    }
    
    //        链接处理：
    [[ZCToolsCore getToolsCore] dealWithLinkClickWithLick:url.absoluteString viewController:[self getControllerFromView:self]];
}

#pragma mark - gesture delegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    return ![self.replycont containslinkAtPoint:[touch locationInView:self.replycont]];
}


#pragma mark - tools 获取当前控制器
- (UIViewController *)getControllerFromView:(UIView *)view {
    // 遍历响应者链。返回第一个找到视图控制器
    UIResponder *responder = view;
    while ((responder = [responder nextResponder])){
        if ([responder isKindOfClass: [UIViewController class]]){
            return (UIViewController *)responder;
        }
    }
    // 如果没有找到则返回nil
    return nil;
}

-(void)openNewPage:(UIViewController *) vc{
    if([self getControllerFromView:self] && [[self getControllerFromView:self] isKindOfClass:[UIViewController class]]){
        if ([self getControllerFromView:self].navigationController) {
//            vc.isNavOpen = YES;
            [[self getControllerFromView:self].navigationController pushViewController:vc animated:YES];
        }else{
            UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
//            vc.isNavOpen = NO;
            nav.modalPresentationStyle = UIModalPresentationOverFullScreen;
            [[self getControllerFromView:self]  presentViewController:nav animated:YES completion:^{
                
            }];
            
        }
    }
}


@end
