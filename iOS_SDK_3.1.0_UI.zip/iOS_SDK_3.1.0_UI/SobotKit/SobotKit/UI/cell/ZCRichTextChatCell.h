//
//  ZCTextChatCell.h
//  SobotApp
//
//  Created by 张新耀 on 15/9/15.
//  Copyright (c) 2015年 com.sobot.chat. All rights reserved.
//

#import "ZCChatBaseCell.h"
#import "ZCMLEmojiLabel.h"

/**
 *  富媒体cell
 *  图片放大 电话链接 cell大小根据内容自适应
 */
@interface ZCRichTextChatCell : ZCChatBaseCell


@end
