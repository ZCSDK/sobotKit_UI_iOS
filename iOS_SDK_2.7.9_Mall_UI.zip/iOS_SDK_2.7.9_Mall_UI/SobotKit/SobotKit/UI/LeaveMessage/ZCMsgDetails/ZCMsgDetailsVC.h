//
//  ZCMsgDetailsVC.h
//  SobotKit
//
//  Created by lizhihui on 2019/2/20.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import <SobotKit/SobotKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZCMsgDetailsVC : ZCUIBaseController

@property (nonatomic,copy) NSString * ticketId; // 工单id


@end

NS_ASSUME_NONNULL_END
