//
//  ZCSatisfactionCell.h
//  SobotKit
//
//  Created by lizhihui on 16/1/21.
//  Copyright © 2016年 zhichi. All rights reserved.
//

#import "ZCChatBaseCell.h"



/**
 *  满意度评价
 */
@interface ZCSatisfactionCell : ZCChatBaseCell



@end
