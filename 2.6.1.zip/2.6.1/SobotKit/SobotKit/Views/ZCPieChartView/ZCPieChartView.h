//
//  HKPieChartView.h
//  PieChart
//
//  Created by hukaiyin on 16/6/20.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCPieChartView : UIView

- (void)updatePercent:(CGFloat)percent animation:(BOOL)animationed;

@end
