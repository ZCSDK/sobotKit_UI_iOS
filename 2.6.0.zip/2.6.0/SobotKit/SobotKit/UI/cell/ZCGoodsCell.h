//
//  ZCGoodsCell.h
//  SobotKit
//
//  Created by zhangxy on 16/3/18.
//  Copyright © 2016年 zhichi. All rights reserved.
//

#import "ZCChatBaseCell.h"

/**
 * ZCGoodsCell
 */
@interface ZCGoodsCell : ZCChatBaseCell

@end
