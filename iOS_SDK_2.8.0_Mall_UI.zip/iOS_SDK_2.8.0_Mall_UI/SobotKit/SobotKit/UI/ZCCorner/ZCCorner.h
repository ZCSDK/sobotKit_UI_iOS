//
//  ZCCorner.h
//  SobotKit
//
//  Created by xuhan on 2019/9/12.
//  Copyright © 2019 zhichi. All rights reserved.
//

#ifndef ZCCorner_h
#define ZCCorner_h

#import "UIImage+ZCCorner.h"
#import "UIView+ZCCorner.h"
#import "CALayer+ZCCorner.h"

#endif /* ZCCorner_h */
