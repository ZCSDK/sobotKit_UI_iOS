//
//  ZCButton.h
//  GCDtestDemo
//
//  Created by lizhihui on 2016/11/1.
//  Copyright © 2016年 lizhihui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCButton : UIButton


// 排列方式
@property (nonatomic,assign) int type;

@property (nonatomic,assign) CGFloat space; // 图片和文字间距

@end
