//
//  PlatformTestController.m
//  SobotKitFrameworkTest
//
//  Created by zhangxy on 2017/9/5.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "PlatformTestController.h"
#import <SobotKit/SobotKit.h>
//#import "SobotKit.h" 

#import "ViewController.h"
//#import <SobotKit/ZCPlatformTools.h>
//#import <SobotKit/ZCLibServer.h>

@interface PlatformTestController (){
    BOOL  isPlatformUnion;
}

@end

@implementation PlatformTestController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //     [self hideTabBar:YES];
    self.navigationController.toolbarHidden = YES;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
#pragma mark 设置默认APPKEY
    NSString *appKey_Text = [[NSUserDefaults standardUserDefaults] valueForKey:@"appKey_Text"];

   
    _textAppkey.text = appKey_Text;
    
    _textUserId.text=@"";
    
    _switView.on = NO;
//    _textApiHost.text = @"http://test.sobot.com";
    
    
    self.title = @"智齿SDK平台版本";
    
    
    
    UIGestureRecognizer *tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapAnywhere1:)];
    [self.view addGestureRecognizer:tap];
    
}


//屏幕点击事件
- (void)didTapAnywhere1:(UITapGestureRecognizer *)recognizer {
    [_textAppkey resignFirstResponder];
    [_textUserId resignFirstResponder];
    [_textApiHost resignFirstResponder];
    
    
}


-(IBAction)startPlatformServer:(id)sender{
    
    [ZCLibClient getZCLibClient].platformUnionCode = @"1001";
    [ZCLibClient getZCLibClient].autoNotification = YES;
//
//    [[ZCLibClient getZCLibClient] initSobotSDK:_textAppkey.text];
    //  初始化配置信息
    ZCLibInitInfo *initInfo = [ZCLibClient getZCLibClient].libInitInfo;
////_textAppkey.text;//@"1ff3e4ff91314f5ca308e19570ba24bb";

//    initInfo.platformKey = @"私钥";
//    initInfo.userId = @"123-test";
//    initInfo.customerCode = @"1111";
    // 获取AppKey
//    initInfo.appKey = _textAppkey.text;
//    initInfo.userId = _textUserId.text;
    

    [[ZCLibClient getZCLibClient] setLibInitInfo:initInfo];
    
    
    ZCKitInfo *uiInfo=[ZCKitInfo new];

//    uiInfo.topViewTextColor = [UIColor redColor];
    uiInfo.navcBarHidden = YES;
    // 测试模式
//    [ZCSobot setShowDebug:YES];
    
    
    // 启动
//    [ZCSobot startZCChatView:uiInfo with:self target:nil pageBlock:^(ZCUIChatController *object, ZCPageBlockType type) {
//        // 点击返回
//        if(type==ZCPageBlockGoBack){
//            NSLog(@"点击了关闭按钮");
//            // 显示导航栏
//        }
//
//        // 页面UI初始化完成，可以获取UIView，自定义UI
//        if(type==ZCPageBlockLoadFinish){
//        }
//
//    } messageLinkClick:nil];
    
    [ZCSobot startZCChatVC:uiInfo with:self target:nil pageBlock:^(id object, ZCPageBlockType type) {
        if (type == ZCPageBlockGoBack) {
          
        }
    } messageLinkClick:nil];
    
}


-(IBAction)startListServer:(id)sender{
     [ZCLibClient getZCLibClient].platformUnionCode = @"";//

    ZCLibInitInfo *info = [ZCLibClient getZCLibClient].libInitInfo;
    if(!info){
        info = [ZCLibInitInfo new];
    }
//    info.userId = _textUserId.text;
//    info.appKey = @"";

//    info.userId = @"123-test";
//    info.customerCode = @"";
    
//    info.flowType = 1;
    
    

    
//    info.platformKey = @"kjds1kh62xzbfgl4";
    
    [[ZCLibClient getZCLibClient] setLibInitInfo:info];
    
    ZCKitInfo *uiInfo=[ZCKitInfo new];
//    uiInfo.apiHost =//_textApiHost.text;
//    uiInfo.socketStatusButtonBgColor = [UIColor redColor];
    uiInfo.topViewBgColor = [UIColor redColor];
    
    [ZCSobot startZCChatListView:uiInfo with:self onItemClick:^(ZCUIChatListController *object, ZCPlatformInfo *info) {
        [ZCSobot startZCChatVC:uiInfo with:object target:nil pageBlock:^(id object, ZCPageBlockType type ) {
            
        } messageLinkClick:nil];
    }];
    
    
  
}

-(IBAction)swValueChange:(UISwitch *)sender{
    if(sender.on){
        _textApiHost.text = @"https://api.sobot.com";
    }else{
        _textApiHost.text = @"http://test.sobot.com";
    }
}

-(IBAction)cloaseAPP:(id)sender{
    [ZCLibClient closeAndoutZCServer:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
