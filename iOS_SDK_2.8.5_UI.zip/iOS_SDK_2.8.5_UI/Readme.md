1、文件说明说明：  
	SobotKit:UI源码framework  
	SobotKitFrameworkTest:调试项目，可以任意新建项目引用SobotKit项目    
	SobotLib_Mall:电商版本库文件(普通版本无需关注)  
	【2.8.5以后UI源码合并为同一个文件，如果电商版本需要使用UI源码，使用SobotLib_Mall替换iOS_SDK_2.8.5_UI/SobotKit/SobotKit/SobotLib下资源文件即可，普通版本无需更改；】


