//
//  ZCMultitemHorizontaRollCell.h
//  SobotKit
//
//  Created by xuhan on 2019/9/10.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import "ZCChatBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZCMultitemHorizontaRollCell : ZCChatBaseCell

@property (nonatomic,strong) NSMutableArray * listArray;

@end

NS_ASSUME_NONNULL_END
