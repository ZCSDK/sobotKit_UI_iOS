//
//  ZCMultiRichCell.h
//  SobotKit
//
//  Created by lizhihui on 2017/12/6.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCChatBaseCell.h"

@interface ZCMultiRichCell : ZCChatBaseCell

@end
