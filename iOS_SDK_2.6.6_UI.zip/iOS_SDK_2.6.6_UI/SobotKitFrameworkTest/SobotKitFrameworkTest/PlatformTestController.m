//
//  PlatformTestController.m
//  SobotKitFrameworkTest
//
//  Created by zhangxy on 2017/9/5.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "PlatformTestController.h"
#import <SobotKit/SobotKit.h>
#import "ViewController.h"

@interface PlatformTestController (){
    BOOL  isPlatformUnion;
}

@end

@implementation PlatformTestController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //     [self hideTabBar:YES];
    self.navigationController.toolbarHidden = YES;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
#pragma mark 设置默认APPKEY
    NSString *appKey_Text = [[NSUserDefaults standardUserDefaults] valueForKey:@"appKey_Text"];

   
    _textAppkey.text = appKey_Text;
    
    _textUserId.text=@"";
    
    _switView.on = NO;
//    _textApiHost.text = @"http://test.sobot.com";
    
    
    self.title = @"智齿SDK平台版本";
    
    
    
    UIGestureRecognizer *tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapAnywhere1:)];
    [self.view addGestureRecognizer:tap];
    
}


//屏幕点击事件
- (void)didTapAnywhere1:(UITapGestureRecognizer *)recognizer {
    [_textAppkey resignFirstResponder];
    [_textUserId resignFirstResponder];
    [_textApiHost resignFirstResponder];
    
    
}


-(IBAction)startPlatformServer:(id)sender{
    
//    [ZCLibClient getZCLibClient].platformUnionCode = @"019";
//    [[ZCLibClient getZCLibClient] initSobotSDK:@"1ff3e4ff91314f5ca308e19570ba24bb"];
    [[ZCLibClient getZCLibClient] initSobotSDK:_textAppkey.text];
    //  初始化配置信息
    ZCLibInitInfo *initInfo = [ZCLibClient getZCLibClient].libInitInfo;
//    initInfo.appKey = @"";
//    initInfo.platformKey = @"私钥";
//    initInfo.userId = @"123";
//    initInfo.customerCode = @"1111";
    // 获取AppKey
//    initInfo.appKey = _textAppkey.text;
//    initInfo.userId = _textUserId.text;
    
    [[ZCLibClient getZCLibClient] setLibInitInfo:initInfo];
    
    
    ZCKitInfo *uiInfo=[ZCKitInfo new];

//    uiInfo.topViewTextColor = [UIColor redColor];
    uiInfo.navcBarHidden = YES;
    // 测试模式
    [ZCSobot setShowDebug:YES];
    
    
    // 启动
    [ZCSobot startZCChatVC:uiInfo with:self target:nil pageBlock:^(id object, ZCPageBlockType type) {
        
    } messageLinkClick:nil];
    
}


-(IBAction)startListServer:(id)sender{
     [ZCLibClient getZCLibClient].platformUnionCode = @"019";
    ZCLibInitInfo *info = [ZCLibClient getZCLibClient].libInitInfo;
    if(!info){
        info = [ZCLibInitInfo new];
    }

    [[ZCLibClient getZCLibClient] setLibInitInfo:info];
    
    ZCKitInfo *uiInfo=[ZCKitInfo new];

    uiInfo.customBannerColor = [UIColor redColor];
    
    [ZCSobot startZCChatListView:uiInfo with:self onItemClick:^(ZCUIChatListController *object, ZCPlatformInfo *info) {
        [ZCSobot startZCChatVC:uiInfo with:object target:nil pageBlock:^(id object, ZCPageBlockType type ) {
            
        } messageLinkClick:nil];
    }];
}

-(IBAction)swValueChange:(UISwitch *)sender{
    if(sender.on){
        _textApiHost.text = @"https://api.sobot.com";
    }else{
        _textApiHost.text = @"http://test.sobot.com";
    }
}

-(IBAction)cloaseAPP:(id)sender{
    [ZCLibClient closeAndoutZCServer:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
