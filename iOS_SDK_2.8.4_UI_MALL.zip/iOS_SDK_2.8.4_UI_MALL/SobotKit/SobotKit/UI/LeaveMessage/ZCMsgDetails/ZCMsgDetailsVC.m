//
//  ZCMsgDetailsVC.m
//  SobotKit
//
//  Created by lizhihui on 2019/2/20.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import "ZCMsgDetailsVC.h"
#import "ZCUIColorsDefine.h"
#import "ZCLibGlobalDefine.h"
#import "ZCUIImageTools.h"
#import "ZCUICore.h"
//#import "ZCMsgDetailCell.h"
#import "ZCButton.h"
#import "ZCHtmlCore.h"


#import "ZCPlatformTools.h"
#import "ZCUICore.h"
#import "ZCRecordListModel.h"
#import "ZCLeaveDetailCell.h"
#define cellmsgDetailIdentifier @"ZCLeaveDetailCell"
#import "ZCUICustomActionSheet.h"
#import "ZCUIWebController.h"
#import "ZCUIRatingView.h"
#import "ZCHtmlFilter.h"

#import "ZCReplyLeaveController.h"

#import "ZCReplyLeaveView.h"

#import "ZCSobotCore.h"
#import <AVFoundation/AVFoundation.h>

#import "ZCToolsCore.h"

#import "ZCUIXHImageViewer.h"
#import "ZCVideoPlayer.h"

#import "ZCReplyFileView.h"
#import "ZCDocumentLookController.h"
#import "ZCLocalStore.h"

@interface ZCMsgDetailsVC ()
<UITableViewDelegate,
UITableViewDataSource,
ZCUIBackActionSheetDelegate,
RatingViewDelegate,
ZCReplyLeaveViewDelegate,
UIImagePickerControllerDelegate,
UINavigationControllerDelegate>
{
    
    BOOL     isShowHeard;
    BOOL     isAddShowBtn;// 添加展开按钮
    
}
@property(nonatomic,strong)UITableView      *listTable;

@property (nonatomic,strong) NSMutableArray * listArray;

@property (nonatomic,strong) ZCButton * showBtn;

@property (nonatomic,strong) UIView * headerView;
@property (nonatomic,strong) UIView * footView;

@property (nonatomic,strong) UIView * commitFootView;


/***  评价页面 **/
@property (nonatomic,strong) ZCUICustomActionSheet *sheet;

@property (nonatomic, strong) UIImagePickerController *zc_imagepicker;

@property (nonatomic, strong) ZCReplyLeaveView *replyLeaveView;

@property (nonatomic, strong) NSMutableArray *imageArr;
@property (nonatomic, strong) NSMutableArray * imagePathArr;

//  2.8.2 已创建  model ，单独处理 ，
@property (nonatomic, strong) ZCRecordListModel *creatRecordListModel;

@property (nonatomic, strong) UIView *buttonBgView;
@property (nonatomic, strong) UIButton *replyButton;
@property (nonatomic, strong) UIButton *evaluateButton;

@property (nonatomic, strong) NSString *replyStr;
@property (nonatomic, strong) NSDictionary *evaluateModelDic;
@end

@implementation ZCMsgDetailsVC


#pragma mark - lift cycle
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if(self.listTable){
        [self orientationChanged];
        [self viewDidLayoutSubviews];
    }
    
    if (isLandspace) {
        [self loadData];
    }
}


- (void)viewDidLoad {
    [super viewDidLoad];
    if ([ZCUICore getUICore].kitInfo.navcBarHidden) {
        self.navigationController.navigationBarHidden = YES;
        self.navigationController.navigationBar.translucent = NO;
    }
    
    if (self.navigationController.navigationBarHidden) {
        self.navigationController.navigationBar.translucent = NO;
    }
    
    if(!self.navigationController.navigationBarHidden){
        self.navigationController.navigationBar.translucent = NO;
        [self setNavigationBarStyle];
        self.title = ZCSTLocalString(@"留言详情");
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[ZCUITools zcgetTitleFont],NSForegroundColorAttributeName:[ZCUITools zcgetTopViewTextColor]}];
    }else{
        [self createTitleView];
        self.titleLabel.text = ZCSTLocalString(@"留言详情");
        [self.backButton.imageView setContentMode:UIViewContentModeScaleAspectFit];
        [self.backButton setTitle:ZCSTLocalString(@"返回") forState:UIControlStateNormal];
        [self.moreButton setHidden:YES];
        
    }
    
    
    isShowHeard = NO;
    _listArray = [NSMutableArray arrayWithCapacity:0];
    [self.view setBackgroundColor:UIColorFromRGB(0xF8F9FA)];
    [self createTableView];
    [self loadData];
}

-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    [self setTableSeparatorInset];
    
    CGFloat Y = 0;
    if (self.navigationController.navigationBarHidden) {
        Y = NavBarHeight;
    }
    CGFloat scrollHeight = [self getCurViewHeight] - 74 - XBottomBarHeight - Y ;
    [self reloadReplyButton];
    
    int direction = [[ZCToolsCore getToolsCore] getCurScreenDirection];
    CGFloat spaceX = 0;
    CGFloat LW = [self getCurViewWidth];
    // iphoneX 横屏需要单独处理
    if(direction > 0){
        LW = LW - XBottomBarHeight;
    }
    if(direction == 2){
        spaceX = XBottomBarHeight;
    }
    
    [self.listTable setFrame:CGRectMake(spaceX, Y, LW, scrollHeight)];
    [self.listTable reloadData];
    if(isLandspace){
        if(self.replyLeaveView){
            [self.replyLeaveView tappedCancel:YES];
        }
    }
    
    if(_sheet){
        [_sheet tappedCancel];
    }
    
}

-(ZCLibConfig *)getCurConfig{
    return [[ZCUICore getUICore] getLibConfig];
}
// 加载数据
-(void)loadData{
    [[ZCUIToastTools shareToast] showProgress:@"" with:self.view];
    __weak ZCMsgDetailsVC * weakSelf = self;
    NSDictionary *dict = @{
        @"partnerid":zcLibConvertToString([ZCLibClient getZCLibClient].libInitInfo.partnerid),
        @"uid":zcLibConvertToString([self getCurConfig].uid),
        @"companyId":zcLibConvertToString(_companyId)};
    [[[ZCUICore getUICore] getAPIServer] postUserDealTicketinfoListWith:dict ticketld:_ticketId start:^{
        
    } success:^(NSDictionary *dict, NSMutableArray *itemArray, ZCNetWorkCode sendCode) {
        [[ZCUIToastTools shareToast] dismisProgress];
        if (itemArray.count > 0) {
            [_listArray removeAllObjects];
            // flag ==2 时是 还需要处理
            for (ZCRecordListModel * model in itemArray) {
                
                if (model.flag == 2 && model.replayList.count > 0) {
                    for (ZCRecordListModel * item in model.replayList) {
                        item.flag = 2;
                        item.content = model.content;
                        item.timeStr = model.timeStr;
                        item.time = model.time;
                        
                        [self.listArray addObject:item];
                    }
                }else{
                    
                    if(model.flag == 1){
                        self.creatRecordListModel = model;
//                       创建 状态，去掉 附件
//                        model.fileList = nil;
                    }
                    
                    [self.listArray addObject:model];
                }
                
                [self reloadReplyButton];
                    
            }
    
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self createStarView];
            
            //这里进行UI更新
            [weakSelf.listTable reloadData];
            [weakSelf.listTable layoutIfNeeded];
//            NSLog(@"刷新了");
        });
        
        [self updateReadStatus];
    } failed:^(NSString *errorMessage, ZCNetWorkCode errorCode) {
        [[ZCUIToastTools shareToast] dismisProgress];
        [self updateReadStatus];
    } ];
    
}

// 设置留言已读
-(void)updateReadStatus{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithDictionary:@{
    @"partnerId":zcLibConvertToString([ZCLibClient getZCLibClient].libInitInfo.partnerid),
    @"ticketId":zcLibConvertToString(_ticketId),
    @"companyId":zcLibConvertToString(_companyId)}];
    [[[ZCUICore getUICore] getAPIServer] updateUserTicketReplyInfo:dict start:^{
       
    } success:^(NSDictionary *dict, ZCNetWorkCode sendCode) {
       
    } failed:^(NSString *errorMessage, ZCNetWorkCode errorCode) {
        
    }];
}

-(void)buttonClick:(UIButton *)sender{
    if([self autoAlertEvaluate]){
        return;
    }
    
    if (self.presentingViewController) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}


-(void)didMoveToParentViewController:(UIViewController *)parent{
    
    [super didMoveToParentViewController:parent];
    NSLog(@"页面侧滑返回：%@",parent);
    if(!parent){
        if([self autoAlertEvaluate]){
            return;
        }
    }
}

-(BOOL)autoAlertEvaluate{
    
    if(self.listArray!=nil && self.listArray.count > 0){
        ZCRecordListModel *first = self.listArray.firstObject;
        // evaluateModelDic当前评价信息，已经评价过
        if(first.isOpen && first.isEvalution == 0 && !self.evaluateModelDic)
        {
            NSString *key = [NSString stringWithFormat:@"TicketKEY_%@",zcLibConvertToString(_ticketId)];
            
            if([ZCUICore getUICore].kitInfo.showLeaveDetailBackEvaluate && zcLibConvertToString([ZCLocalStore getLocalParamter:key]).length == 0){
                [ZCLocalStore addObject:key forKey:key];
                [self commitScore];
                return YES;
            }
        }
    }
    
    return NO;
    
}


-(void)createTableView{
    // 计算Y值
    CGFloat Y = 0;
    if (self.navigationController.navigationBarHidden) {
        Y = NavBarHeight;
    }
    
//    线条
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(0, Y, self.view.frame.size.width, 0.5)];
    lineView.backgroundColor = UIColorFromRGB(lineGrayColor);
    [self.view addSubview:lineView];
    
    _listTable = [[UITableView alloc]initWithFrame:CGRectMake(0, Y+1, [self getCurViewWidth], [self getCurViewHeight] - Y- 60-XBottomBarHeight) style:UITableViewStyleGrouped];
    _listTable.delegate = self;
    _listTable.dataSource = self;
    _listTable.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    _listTable.autoresizesSubviews = YES;
//    _listTable.backgroundColor = [UIColor redColor];
    [self.view addSubview:_listTable];
    // 关闭安全区域，否则UITableViewCell横屏时会是全屏的宽
      NSString *version = [UIDevice currentDevice].systemVersion;
      if (version.doubleValue >= 11.0) {
          [_listTable setInsetsContentViewsToSafeArea:NO];
      }
//    2.8.2 增加 客户回复
    
    self.buttonBgView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.listTable.frame) + 10, [self getCurViewWidth], 50 + XBottomBarHeight)];
    self.buttonBgView.backgroundColor = [UIColor whiteColor];
    self.buttonBgView.layer.shadowOpacity= 1;
    self.buttonBgView.layer.shadowColor = UIColorFromRGBAlpha(0x515a7c, 0.15).CGColor;
    self.buttonBgView.layer.shadowOffset = CGSizeZero;//投影偏移
    self.buttonBgView.layer.shadowRadius = 2;
    
    self.buttonBgView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleTopMargin;
    [self.view addSubview:self.buttonBgView];
    
    
//    UIView *buttonTopLineView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, viewWidth, 0.5)];
//    buttonTopLineView.backgroundColor = UIColorFromRGB(lineGrayColor);
//    buttonTopLineView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
//    [self.buttonBgView addSubview:buttonTopLineView];
    
    
    self.replyButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.replyButton setFrame:CGRectMake(0,7, [self getCurViewWidth], 36)];
    self.replyButton.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleTopMargin;
    self.replyButton.backgroundColor = [UIColor whiteColor];
    self.replyButton.titleLabel.font = ZCUIFontBold14;
    [self.replyButton setTitleColor:[ZCUITools zcgetLeaveSubmitImgColor] forState:UIControlStateNormal];
    [self.replyButton setTitle:ZCSTLocalString(@"回复") forState:UIControlStateNormal];
    [self.replyButton setImage:[ZCUITools zcuiGetBundleImage:@"zcicon_reply_button_icon"] forState:UIControlStateNormal];
//    [self.replyButton setTitleEdgeInsets:UIEdgeInsetsMake(0, -self.replyButton.imageView.image.size.width, 0, self.replyButton.imageView.image.size.width)];
//    [self.replyButton setImageEdgeInsets:UIEdgeInsetsMake(0, self.replyButton.titleLabel.bounds.size.width, 0, -self.replyButton.titleLabel.bounds.size.width)];
//    [self.replyButton setTitleEdgeInsets:UIEdgeInsetsMake(0, -6, 0, 6)];
    if(isRTLLayout()){

        [self.replyButton setTitleEdgeInsets:UIEdgeInsetsMake(0, -6, 0, 6)];
    }else{
        [self.replyButton setImageEdgeInsets:UIEdgeInsetsMake(0, -6, 0, 6)];
    }
     
    [self.replyButton addTarget:self action:@selector(replyButtonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.buttonBgView addSubview:self.replyButton];
//    self.replyButton.hidden = YES;
    
    
    self.evaluateButton = [[UIButton alloc]initWithFrame:CGRectMake(0,5, ScreenWidth, 36 )];
    self.evaluateButton.backgroundColor = [ZCUITools zcgetLeaveSubmitImgColor];
    self.evaluateButton.layer.cornerRadius = 18;
    self.evaluateButton.layer.masksToBounds = YES;
    self.evaluateButton.titleLabel.font = [UIFont systemFontOfSize:14];
    [self.evaluateButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.evaluateButton setTitle:ZCSTLocalString(@"服务评价") forState:UIControlStateNormal];
    self.evaluateButton.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [self.evaluateButton addTarget:self action:@selector(commitScore) forControlEvents:UIControlEventTouchUpInside];
    
    [self.buttonBgView addSubview:self.evaluateButton];
    self.evaluateButton.hidden = YES;
    
    
    
    
    [_listTable registerClass:[ZCLeaveDetailCell class] forCellReuseIdentifier:cellmsgDetailIdentifier];
    
    if (iOS7) {
        _listTable.backgroundView = nil;
    }
    
    [_listTable setSeparatorColor:UIColorFromRGB(0xdce0e5)];
    [_listTable setSeparatorStyle:UITableViewCellSeparatorStyleNone];
//    [_listTable setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [_listTable setBackgroundColor:UIColorFromRGB(TextRecordBgColor)];
    [self setTableSeparatorInset];
    

}

- (void)reloadReplyButton {
    CGFloat viewWidth = [self getCurViewWidth];
    float replyButton_height = 36;
    
    float evaluateButton_margin = 10;
    
    float replyButton_y = 10;
    ZCRecordListModel *first = self.listArray.firstObject;
    if( (first.isOpen && first.isEvalution == 0) && !self.evaluateModelDic)
    {
        if (first.flag == 3 && ![ZCUICore getUICore].kitInfo.leaveCompleteCanReply) {
            //        已完成 状态，并且 配置 不能回复，
            self.replyButton.hidden = YES;
            self.evaluateButton.hidden = NO;
            self.evaluateButton.frame = CGRectMake(0, replyButton_y, viewWidth, replyButton_height );
        }else{
            //        有评价按钮
            self.replyButton.hidden = NO;
            self.evaluateButton.hidden = NO;
            //        self.replyButton.backgroundColor = UIColor.redColor;
            //        self.evaluateButton.backgroundColor = UIColor.redColor;
            self.replyButton.frame = CGRectMake(0, replyButton_y, viewWidth/3, replyButton_height );
            
            self.evaluateButton.frame = CGRectMake(viewWidth/3 + evaluateButton_margin, replyButton_y, viewWidth/3*2 - evaluateButton_margin*2, replyButton_height );
        }
    }else{
        
        if (first.flag == 3 && ![ZCUICore getUICore].kitInfo.leaveCompleteCanReply) {
            //        已完成 状态，并且 配置 不能回复，
            self.replyButton.hidden = YES;
            self.evaluateButton.hidden = YES;
            
        }else{
            self.replyButton.hidden = NO;
            self.evaluateButton.hidden = YES;
            self.replyButton.frame = CGRectMake(0, replyButton_y, [self getCurViewWidth], replyButton_height );
        }
    }
    
}

-(void)commitScore{
    if(_sheet){
        [_sheet tappedCancel];
    }
    
     ZCRecordListModel *model = self.listArray.firstObject;
    // 去评价
    _sheet = [[ZCUICustomActionSheet alloc] initActionSheet:ServerSatisfcationOrderType Name:@"" Cofig:[ZCUICore getUICore].getLibConfig cView:self.view IsBack:NO isInvitation:1 WithUid:[ZCUICore getUICore].getLibConfig.uid   IsCloseAfterEvaluation:NO Rating:5 IsResolved:YES IsAddServerSatifaction:NO txtFlag:model.txtFlag ticketld:_ticketId ticketScoreInfooList:model.ticketScoreInfooList];
    _sheet.delegate = self;
    [_sheet showInView:self.view];
}

#pragma mark - click
- (void)replyButtonClick {
    
//    如果是横屏 跳转页面
    if (isLandspace) {
        ZCReplyLeaveController *vc = [[ZCReplyLeaveController alloc]init];
        vc.ticketId = _ticketId;
        [self.navigationController pushViewController:vc animated:YES];
        
    }else{
        //    弹出留言
            self.replyLeaveView = [[ZCReplyLeaveView alloc]initActionSheetWithView:self.view];
            self.replyLeaveView.delegate = self;
            self.replyLeaveView.ticketId = _ticketId;
            
            [self.replyLeaveView showInView:self.view];
            
        //
            self.replyLeaveView.imageArr = self.imageArr;
            self.replyLeaveView.imagePathArr = self.imagePathArr;
            self.replyLeaveView.textDesc.text = self.replyStr;
            
            [self.replyLeaveView reloadScrollView];
    }
    


}

#pragma mark - view
-(void)createStarView{
    ZCRecordListModel *first = self.listArray.firstObject;
    if(first.isOpen && first.isEvalution == 0 && !self.evaluateModelDic)
    {
        UIView * bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 64 + XBottomBarHeight)];
        bgView.backgroundColor = UIColorFromRGB(0xF8F9FA);
        _listTable.tableFooterView = bgView;
        
        
        _commitFootView = [[UIView alloc]initWithFrame:CGRectMake(0, ScreenHeight - 84 - XBottomBarHeight - NavBarHeight, ScreenWidth, 84 + XBottomBarHeight)];
        _commitFootView.backgroundColor = [UIColor whiteColor];

        
        _commitFootView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleTopMargin;
        _commitFootView.autoresizesSubviews = YES;
//        [self.view addSubview:_commitFootView];
        
        // 区尾添加提交按钮 2.7.1改版
        UIButton * commitBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [commitBtn setTitle:ZCSTLocalString(@"服务评价") forState:UIControlStateNormal];
        
        [commitBtn setTitleColor:UIColorFromRGB(TextWhiteColor) forState:UIControlStateNormal];
        [commitBtn setTitleColor:UIColorFromRGB(TextWhiteColor) forState:UIControlStateHighlighted];
        UIImage * img = [ZCUIImageTools zcimageWithColor:[ZCUITools zcgetLeaveSubmitImgColor]];// UIColorFromRGB(BgTitleColor)
        [commitBtn setBackgroundImage:img forState:UIControlStateNormal];
        [commitBtn setBackgroundImage:img forState:UIControlStateSelected];
        commitBtn.frame = CGRectMake(ZCNumber(20), 20, ScreenWidth- ZCNumber(40), ZCNumber(44));
        commitBtn.tag = BUTTON_MORE;
        [commitBtn addTarget:self action:@selector(commitScore) forControlEvents:UIControlEventTouchUpInside];
        commitBtn.layer.masksToBounds = YES;
        commitBtn.layer.cornerRadius = 22.f;
        commitBtn.titleLabel.font = ZCUIFont17;
        commitBtn.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleTopMargin;
        commitBtn.autoresizesSubviews = YES;
        [_commitFootView addSubview:commitBtn];
    }else{
        UIView * bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 0, 0)];
        bgView.backgroundColor = UIColorFromRGB(0xEFF3FA);
        _listTable.tableFooterView = bgView;
        
        if(self.commitFootView){
            [self.commitFootView removeFromSuperview];
        }
    }
}


#pragma mark UITableView delegate Start
// 返回section数
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

// 返回section高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if(section == 0){
        UIView *bgView = [self getHeaderViewHeight];
        return bgView.frame.size.height;
    }else{
        return 114;
    }
    
}




-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
   if(section == 0){
       
        ZCRecordListModel *first = self.listArray.firstObject;
               if((first.isOpen && first.isEvalution == 1) || self.evaluateModelDic)
               {
                   NSString *remarkStr = @"";
//                   NSString *scoreStr = @"";
                   if(self.evaluateModelDic){
                       NSDictionary *dic = self.evaluateModelDic[@"data"];
                       if (dic) {
                           NSDictionary *itemDic = dic[@"item"];
                           if (itemDic) {
//                               scoreStr = zcLibConvertToString(itemDic[@"score"]);
                               remarkStr = zcLibConvertToString(itemDic[@"remark"]);
                           }
                       }
                   }
                   
                   NSString *sting = @"--";

                   ZCRecordListModel * model = _listArray[0];

                   if (remarkStr.length > 0) {
                       sting = remarkStr;
                   }else{
                       if(zcLibConvertToString(model.remark).length > 0){
                           sting = zcLibConvertToString(model.remark);
                       }
                   }
                   
                   NSString *lanStr = ZCSTLocalString(@"评语");
                                      
                   UILabel *conlab = [[UILabel alloc]init];
                   conlab.text = [NSString stringWithFormat:@"%@：%@",lanStr,sting];
                   
                   
                   CGSize textSize = [self autoHeightOfLabel:conlab with: self.listTable.frame.size.width - ZCNumber(40) IsSetFrame:NO];
                                      
                   
                   return ZCNumber(20) + ZCNumber(114) - ZCNumber(18) + textSize.height + ZCNumber(10);
                   
                   
               }
       
       return 20;
    }
    return 0;
}

// 返回section 的View
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if(section == 0){
        NSString * str = @"";
        if (self.listArray.count > 0) {
            ZCRecordListModel * model = [_listArray lastObject];
            
            str = zcLibConvertToString(model.content);
        }
        return [self getHeaderViewHeight];
    }else{
        UIView *view=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, 1)];
        view.backgroundColor = [UIColor clearColor];

        return view;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    if (section == 0) {
        
        ZCRecordListModel *first = self.listArray.firstObject;
        if((first.isOpen && first.isEvalution == 1) || self.evaluateModelDic)
        {
            return [self getHeaderStarViewHeight];
        }else{
            UIView *bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 20)];
            bgView.backgroundColor = UIColorFromRGB(0xF8F9FA);
            return bgView;
        }
    }
    else {
        return nil;
    }
}


-(void)showMoreAction:(UIButton *)sender{
    if (sender.tag == 1001) {
        isShowHeard = YES;
    }else{
        isShowHeard = NO;
    }
    [self.listTable reloadData];
}

// 返回section下得行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
//    if(_listArray==nil){
//        return 0;
//    }
    if(section == 0){
        return _listArray.count;
    }
    return 0;
}

// cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ZCLeaveDetailCell *cell = (ZCLeaveDetailCell*)[tableView dequeueReusableCellWithIdentifier:cellmsgDetailIdentifier];
    if (cell == nil) {
        cell = [[ZCLeaveDetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellmsgDetailIdentifier];
    }
    if(indexPath.row==_listArray.count-1){
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
            [cell setSeparatorInset:UIEdgeInsetsZero];
        }
        
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:UIEdgeInsetsZero];
        }
        
        if([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]){
            [cell setPreservesSuperviewLayoutMargins:NO];
        }
    }
    if ( indexPath.row > _listArray.count -1) {
        return cell;
    }
    
    [cell setBackgroundColor:UIColor.whiteColor];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    ZCRecordListModel * model = _listArray[indexPath.row];
    
    __weak ZCMsgDetailsVC * saveSelf = self;
    
    [cell initWithData:model IndexPath:indexPath.row count:(int)self.listArray.count btnClick:^(ZCRecordListModel * _Nonnull model) {
        
    }];

    [cell setShowDetailClickCallback:^(ZCRecordListModel * _Nonnull model,NSString *urlStr) {
        if (urlStr) {
            ZCUIWebController *webVC = [[ZCUIWebController alloc] initWithURL:urlStr];
            [saveSelf.navigationController pushViewController:webVC animated:YES];
            return;
        }

        NSString *htmlString = model.replyContent;
        if (model.flag == 3) {
            htmlString = model.content;
        }
        ZCUIWebController *webVC = [[ZCUIWebController alloc] initWithURL:htmlString];

        [saveSelf.navigationController pushViewController:webVC animated:YES];
    }];

    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    cell.selected = NO;

    return cell;
}

//-(void)dimissCustomActionSheetPage{
//    _sheet = nil;
//    [ZCUICore getUICore].isDismissSheetPage = YES;
    // 刷新数据
//    [self loadData];
//}


// table 行的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [self tableView:tableView cellForRowAtIndexPath:indexPath];
    return cell.frame.size.height;
}

// table 行的点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

//设置分割线间距
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    if((indexPath.row+1) < _listArray.count){
        UIEdgeInsets inset = UIEdgeInsetsMake(0, 39, 0, 0);
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
            [cell setSeparatorInset:inset];
        }

        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:inset];
        }
    }
}



#pragma mark UITableView delegate end

/**
 *  设置UITableView分割线空隙
 */
-(void)setTableSeparatorInset{
    UIEdgeInsets inset = UIEdgeInsetsMake(0, 39, 0, 0);
    if ([_listTable respondsToSelector:@selector(setSeparatorInset:)]) {
        [_listTable setSeparatorInset:inset];
    }
    
    if ([_listTable respondsToSelector:@selector(setLayoutMargins:)]) {
        [_listTable setLayoutMargins:inset];
    }
}


#pragma mark -- 计算文本高度
-(CGRect)getTextRectWith:(NSString *)str WithMaxWidth:(CGFloat)width  WithlineSpacing:(CGFloat)LineSpacing AddLabel:(UILabel *)label {
    
    [ZCHtmlCore filterHtml:[self filterHtmlImage:str] result:^(NSString * _Nonnull text1, NSMutableArray * _Nonnull arr, NSMutableArray * _Nonnull links) {
        if (text1.length > 0 && text1 != nil) {
            label.attributedText =   [ZCHtmlFilter setHtml:text1 attrs:arr view:label textColor:UIColorFromRGB(TextWordOrderListTextColor) textFont:label.font linkColor:[ZCUITools zcgetChatLeftLinkColor]];
        }else{
            label.attributedText =   [[NSAttributedString alloc] initWithString:@""];
        }
        
        CGRect labelF = label.frame;
        label.text = text1;
        CGSize size = [self autoHeightOfLabel:label with:width IsSetFrame:YES];
        
        labelF.size.height = size.height;
        label.frame = labelF;

    }];
    
    
    return label.frame;
}

/**
 计算Label高度
 
 @param label 要计算的label，设置了值
 @param width label的最大宽度
 @param type 是否从新设置宽，1设置，0不设置
 */
- (CGSize )autoHeightOfLabel:(UILabel *)label with:(CGFloat )width IsSetFrame:(BOOL)isSet{
    //Calculate the expected size based on the font and linebreak mode of your label
    // FLT_MAX here simply means no constraint in height
    CGSize maximumLabelSize = CGSizeMake(width, FLT_MAX);
    
    CGSize expectedLabelSize = [label sizeThatFits:maximumLabelSize];// 返回最佳的视图大小
    
    //adjust the label the the new height.
    if (isSet) {
        CGRect newFrame = label.frame;
        newFrame.size.height = expectedLabelSize.height;
        label.frame = newFrame;
        [label updateConstraintsIfNeeded];
    }
    return expectedLabelSize;
}


-(UIView*)getHeaderViewHeight{
    if (_headerView != nil) {
        [_headerView removeFromSuperview];
        _headerView = nil;
    }
    CGFloat tableWidth = self.listTable.frame.size.width;
    
    _headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableWidth, ZCNumber(140))];
    _headerView.backgroundColor = [UIColor whiteColor];
    _headerView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    _headerView.autoresizesSubviews = YES;
    
    UILabel *titleLab = [[UILabel alloc] initWithFrame:CGRectMake(20,27, 170, ZCNumber(22))];
    [titleLab setFont:ZCUIFontBold17];
    [titleLab setTextAlignment:NSTextAlignmentLeft];
    [titleLab setTextColor:UIColorFromRGB(0x515A7C)];
    titleLab.autoresizesSubviews = UIViewAutoresizingFlexibleWidth;
    [_headerView addSubview:titleLab];
    
    UILabel *labState = [[UILabel alloc] initWithFrame:CGRectMake(tableWidth - 70, 30,50, 20)];
    [labState setBackgroundColor:UIColorFromRGB(0x0DAEAF)];
    [labState setFont:ZCUIFont12];
    labState.layer.cornerRadius = 10.0f;
    [labState setTextColor:UIColorFromRGB(TextWhiteColor)];
    [labState setTextAlignment:NSTextAlignmentCenter];
    labState.layer.masksToBounds = YES;
    labState.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    labState.autoresizesSubviews = YES;
    [_headerView addSubview:labState];
    
    
    NSString * str = @"";
    if(_listArray.count > 0){
        ZCRecordListModel * model = [_listArray lastObject];
        titleLab.text = zcLibConvertToString(model.timeStr);
        str = zcLibConvertToString(model.content);
        
        ZCRecordListModel *firstFlag = [_listArray firstObject];
        
        
        switch (firstFlag.flag) {
            case 1:
                labState.text =  ZCSTLocalString(@"已创建");
                labState.backgroundColor = UIColorFromRGB(0xE4EAF2);
                break;
            case 2:
                labState.text =  ZCSTLocalString(@"受理中");
                labState.backgroundColor = UIColorFromRGB(0xF6AF38);
                break;
            case 3:
                labState.text =  ZCSTLocalString(@"已完成");
                labState.backgroundColor = UIColorFromRGB(BgTitleColor);
                break;
            default:
                break;
        }
    }
//    str = @"jkdlfj按时间拉开点附近绿卡交了多少客服建立刺啦地方呢个电动阀SDK静安寺老地方金额卢卡斯";
   
    CGSize s = [labState.text sizeWithAttributes:@{NSFontAttributeName:labState.font}];
    if(s.width > 50){
        labState.frame = CGRectMake(tableWidth - 20 - s.width-10, 30, s.width+10, ZCNumber(20));
    }
    
    UILabel * conlab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(titleLab.frame) + ZCNumber(8), tableWidth - ZCNumber(40), ZCNumber(50))];
    conlab.numberOfLines = 0;
    conlab.textColor = UIColorFromRGB(0xacb5c4);
    conlab.font = ZCUIFont14;
    [self getTextRectWith:str WithMaxWidth:ScreenWidth - ZCNumber(40) WithlineSpacing:6 AddLabel:conlab];
//    conlab.text = ;
    [_headerView addSubview:conlab];
    
    CGSize conlabSize = [self autoHeightOfLabel:conlab with:tableWidth - ZCNumber(30) IsSetFrame:NO];
    
    
//    2.8.2 增加客户回复：
    float pics_height = 0;
    float h = conlab.frame.origin.y + conlabSize.height + 10;
       if(self.creatRecordListModel.fileList.count > 0) {
            
            float fileBgView_margin_left = 20;
            float fileBgView_margin_top = 10;
            float fileBgView_margin_right = 20;
            float fileBgView_margin = 10;
            
    //      宽度固定为  （屏幕宽度 - 60)/3
            CGSize fileViewRect = CGSizeMake((self.view.frame.size.width - 60)/3, 85);
            
    //      算一下每行多少个 ，
            float nums = (self.view.frame.size.width - fileBgView_margin_left - fileBgView_margin_right)/(fileViewRect.width + fileBgView_margin);
            NSInteger numInt = floor(nums);
            
    //      行数：
            NSInteger rows = ceil(self.creatRecordListModel.fileList.count/(float)numInt);
            
            
            for (int i = 0 ; i < self.creatRecordListModel.fileList.count;i++) {
                NSDictionary *modelDic = self.creatRecordListModel.fileList[i];
                
                //           当前列数
                NSInteger currentColumn = i%numInt;
    //           当前行数
                NSInteger currentRow = i/numInt;
                
                float x = fileBgView_margin_left + (fileViewRect.width + fileBgView_margin)*currentColumn;
                float y = h + fileBgView_margin_top + (fileViewRect.height + fileBgView_margin)*currentRow;
                float w = fileViewRect.width;
                float h = fileViewRect.height;
                
                ZCReplyFileView *fileBgView = [[ZCReplyFileView alloc]initWithDic:modelDic withFrame:CGRectMake(x, y, w, h)];
                fileBgView.layer.cornerRadius = 4;
                fileBgView.layer.masksToBounds = YES;
                
                [fileBgView setClickBlock:^(NSDictionary * _Nonnull modelDic, UIImageView * _Nonnull imgView) {
                   NSString *fileType = modelDic[@"fileType"];
                   NSString *fileUrlStr = modelDic[@"fileUrl"];
    //                NSArray *imgArray = [[NSArray alloc]initWithObjects:fileUrlStr, nil];
                    if ([fileType isEqualToString:@"jpg"] ||
                        [fileType isEqualToString:@"png"] ||
                        [fileType isEqualToString:@"gif"] ) {
                        
                        //     图片预览
                        
                        UIImageView *picView = imgView;
                        CALayer *calayer = picView.layer.mask;
                        [picView.layer.mask removeFromSuperlayer];
                        
                        ZCUIXHImageViewer *xh=[[ZCUIXHImageViewer alloc] initWithImageViewerWillDismissWithSelectedViewBlock:^(ZCUIXHImageViewer *imageViewer, UIImageView *selectedView) {
                            
                        } didDismissWithSelectedViewBlock:^(ZCUIXHImageViewer *imageViewer, UIImageView *selectedView) {
                            
                            selectedView.layer.mask = calayer;
                            [selectedView setNeedsDisplay];
                        } didChangeToImageViewBlock:^(ZCUIXHImageViewer *imageViewer, UIImageView *selectedView) {
                            
                        }];
                        
                        NSMutableArray *photos = [[NSMutableArray alloc] init];
                        [photos addObject:picView];
                        xh.disableTouchDismiss = NO;
                        [xh showWithImageViews:photos selectedView:picView];
                        
                        
                    }
                    else if ([fileType isEqualToString:@"mp4"]){
                        NSURL *imgUrl = [NSURL URLWithString:fileUrlStr];
                        
                         UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
                         ZCVideoPlayer *player = [[ZCVideoPlayer alloc] initWithFrame:window.bounds withShowInView:window url:imgUrl Image:nil];
                         [player showControlsView];
                        
                    }
                    
                    else{
                        ZCLibMessage *message = [[ZCLibMessage alloc]init];
                        ZCLibRich *rich = [[ZCLibRich alloc]init];
                        rich.richmoreurl = fileUrlStr;
                        
                        /**
                        * 13 doc文件格式
                        * 14 ppt文件格式
                        * 15 xls文件格式
                        * 16 pdf文件格式
                        * 17 mp3文件格式
                        * 18 mp4文件格式
                        * 19 压缩文件格式
                        * 20 txt文件格式
                        * 21 其他文件格式
                        */
                        if ([fileType isEqualToString:@"doc"] || [fileType isEqualToString:@"docx"]) {
                            rich.fileType = 13;
                        }
                        else if ([fileType isEqualToString:@"ppt"]){
                            rich.fileType = 14;
                        }
                        else if ([fileType isEqualToString:@"xls"] || [fileType isEqualToString:@"xlsx"]){
                            rich.fileType = 15;
                        }
                        else if ([fileType isEqualToString:@"pdf"]){
                            rich.fileType = 16;
                        }
                        else if ([fileType isEqualToString:@"mp3"]){
                            rich.fileType = 17;
                        }
    //                    else if ([fileType isEqualToString:@"mp4"]){
    //                        rich.fileType = 18;
    //                    }
                        else if ([fileType isEqualToString:@"zip"]){
                            rich.fileType = 19;
                        }
                        else if ([fileType isEqualToString:@"txt"]){
                            rich.fileType = 20;
                        }
                        else{
                            rich.fileType = 21;
                        }
                        
                        
                        message.richModel = rich;
                        
                        ZCDocumentLookController *docVc = [[ZCDocumentLookController alloc]init];
                        docVc.message = message;
                        [self.navigationController pushViewController:docVc animated:YES];
                        
                    }
                    
                    
                }];
                [_headerView addSubview:fileBgView];
            }
            
            pics_height =  (fileViewRect.height + fileBgView_margin_top)*rows;
        }
    
    
    
    _showBtn = [ZCButton buttonWithType:UIButtonTypeCustom];
    [_showBtn addTarget:self action:@selector(showMoreAction:) forControlEvents:UIControlEventTouchUpInside];
    _showBtn.tag = 1001;
    _showBtn.type = 2;
    _showBtn.space = ZCNumber(18);
    _showBtn.titleLabel.font = ZCUIFont12;
    [_showBtn setTitle: ZCSTLocalString(@"查看更多") forState:UIControlStateNormal];
    [_showBtn setImage:[ZCUITools zcuiGetBundleImage:@"zciocn_arrow_down"] forState:UIControlStateNormal];


//    _showBtn.backgroundColor = [UIColor redColor];
    [_headerView addSubview: _showBtn];
    _showBtn.frame = CGRectMake([self getCurViewWidth]/2- ZCNumber(120/2), pics_height + conlabSize.height + ZCNumber(8), 120, ZCNumber(0));
    _showBtn.hidden = YES;
    [_showBtn setTitleColor:UIColorFromRGB(BgTitleColor) forState:UIControlStateNormal];
    
    if (conlabSize.height > 35 || self.creatRecordListModel.fileList.count > 0) {
        // 添加 展开全文btn
        _showBtn.hidden = NO;
    }
    
    if (!_showBtn.hidden) {
        if (isShowHeard) {
            
           NSString *clickText = ZCSTLocalString(@"收起");
            // 防止英文过长，箭头被覆盖
            CGSize s = [clickText sizeWithAttributes:@{NSFontAttributeName:_showBtn.titleLabel.font}];
            // 显示全部
            _showBtn.frame = CGRectMake(tableWidth/2- ZCNumber((s.width + 50)/2), CGRectGetMaxY(conlab.frame) + ZCNumber(8) + pics_height, s.width + 50, ZCNumber(20));
//            [self getTextRectWith:str WithMaxWidth:tableWidth - ZCNumber(30) WithlineSpacing:6 AddLabel:conlab];
            //展开之后
            conlab.frame = CGRectMake(ZCNumber(15), CGRectGetMaxY(titleLab.frame) + ZCNumber(10) , conlabSize.width, conlabSize.height);
            _showBtn.tag = 1002;
            _showBtn.space = ZCNumber(10);
            [_showBtn setTitle:clickText forState:UIControlStateNormal];
            [_showBtn setImage:[ZCUITools zcuiGetBundleImage:@"zciocn_arrow_up"] forState:UIControlStateNormal];
            CGRect sf = _showBtn.frame;
            sf.origin.y = CGRectGetMaxY(conlab.frame) + ZCNumber(20) + pics_height;
            _showBtn.frame = sf;
            for (UIView *view in [_headerView subviews]) {
                 if ([view isKindOfClass:[ZCReplyFileView class]]) {
                     view.hidden = NO;
                 }
             }
        }else{
            // 收起之后
            conlab.frame = CGRectMake(ZCNumber(20), CGRectGetMaxY(titleLab.frame) + ZCNumber(8), tableWidth - ZCNumber(40), ZCNumber(40));
            
            _showBtn.frame = CGRectMake(tableWidth/2- ZCNumber(120/2), CGRectGetMaxY(conlab.frame) + ZCNumber(8), ZCNumber(120), ZCNumber(20));
            _showBtn.tag = 1001;
            _showBtn.space = ZCNumber(18);
            [_showBtn setTitle:ZCSTLocalString(@"查看更多") forState:UIControlStateNormal];
            [_showBtn setImage:[ZCUITools zcuiGetBundleImage:@"zciocn_arrow_down"] forState:UIControlStateNormal];
            
            for (UIView *view in [_headerView subviews]) {
                 if ([view isKindOfClass:[ZCReplyFileView class]]) {
                     view.hidden = YES;
                 }
             }
            
        }
    }
    
    // 线条
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(0,0, tableWidth, 10)];
    lineView.backgroundColor = UIColorFromRGB(0xF8F9FA);
    [_headerView addSubview:lineView];
    
    CGFloat y = CGRectGetMaxY(_showBtn.frame)+17;
    if(_showBtn.isHidden){
        y = CGRectGetMaxY(conlab.frame)+17;
    }
    
    // 线条
    UIView *lineView1 = [[UIView alloc]initWithFrame:CGRectMake(0,y, tableWidth, 10)];
    lineView1.backgroundColor = UIColorFromRGB(0xF8F9FA);
    [_headerView addSubview:lineView1];
    
    CGRect hf = _headerView.frame;
    hf.size.height = y + 10;
    _headerView.frame = hf;
    
    UIView *lineView_0 = [[UIView alloc]initWithFrame:CGRectMake(0, 10, tableWidth, 0.5)];
    lineView_0.backgroundColor = UIColorFromRGB(lineGrayColor);
    
    [_headerView addSubview:lineView_0];
    
    UIView *lineView_1 = [[UIView alloc]initWithFrame:CGRectMake(0, y, tableWidth, 0.5)];
    lineView_1.backgroundColor = UIColorFromRGB(lineGrayColor);
    
    [_headerView addSubview:lineView_1];
    
    
    return _headerView;
}


-(UIView*)getHeaderStarViewHeight{
    if (_footView != nil) {
        [_footView removeFromSuperview];
        _footView = nil;
    }
    if(_listArray.count == 0){
        return nil;
    }

    [self createStarView];
    
    NSString *remarkStr = @"";
    NSString *scoreStr = @"";
    if(self.evaluateModelDic){
        NSDictionary *dic = self.evaluateModelDic[@"data"];
        if (dic) {
            NSDictionary *itemDic = dic[@"item"];
            if (itemDic) {
                scoreStr = zcLibConvertToString(itemDic[@"score"]);
                remarkStr = zcLibConvertToString(itemDic[@"remark"]);
            }
        }
    }
    
    ZCRecordListModel * model = _listArray[0];
    
    _footView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.listTable.frame.size.width, ZCNumber(114))];
    _footView.backgroundColor = [UIColor whiteColor];
    
    UIView *bgView_1 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 10)];
    bgView_1.backgroundColor = UIColorFromRGB(0xF8F9FA);
    [_footView addSubview:bgView_1];
    
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(0, 10, self.listTable.frame.size.width, 0.5)];
    lineView.backgroundColor = UIColorFromRGB(lineGrayColor);
    [_footView addSubview:lineView];
    
    UILabel *titleLab = [[UILabel alloc] initWithFrame:CGRectMake(ZCNumber(21), ZCNumber(26), self.listTable.frame.size.width - ZCNumber(40), ZCNumber(24))];
    [titleLab setFont:ZCUIFontBold14];
    titleLab.text =ZCSTLocalString(@"我的服务评价");
    [titleLab setTextAlignment:NSTextAlignmentLeft];
    [titleLab setTextColor:UIColorFromRGB(0x455C73)];
    [_footView addSubview:titleLab];
    
    UILabel * labScore = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(titleLab.frame) + ZCNumber(5), 36, ZCNumber(18))];
    labScore.numberOfLines = 0;
    labScore.textColor = UIColorFromRGB(0xACB5C4);
    labScore.font = ZCUIFont12;
    labScore.text = ZCSTLocalString(@"评分：");
    [_footView addSubview:labScore];
    
    
    ZCUIRatingView *startView = [[ZCUIRatingView alloc] initWithFrame:CGRectMake(54, CGRectGetMaxY(titleLab.frame)+5, 140, 18)];
    [startView setImagesDeselected:@"zcicon_star_unsatisfied" partlySelected:@"zcicon_star_satisfied" fullSelected:@"zcicon_star_satisfied" andDelegate:self];
    startView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin;
    
    if (scoreStr.length > 0) {
        [startView displayRating:[scoreStr floatValue]];
    }else{
        [startView displayRating:[model.score floatValue]];
    }
    
    startView.backgroundColor = [UIColor clearColor];
    startView.userInteractionEnabled = NO;
    [_footView addSubview:startView];
    
    
    if(isRTLLayout()){
        [titleLab setTextAlignment:NSTextAlignmentRight];
        [[ZCToolsCore getToolsCore] setRTLFrame:labScore];
        [[ZCToolsCore getToolsCore] setRTLFrame:startView];
    }
    
    
    UILabel * conlab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(labScore.frame) + ZCNumber(7), self.listTable.frame.size.width - ZCNumber(40), ZCNumber(18))];
    conlab.numberOfLines = 0;
    conlab.textColor = UIColorFromRGB(0xACB5C4);
    conlab.font = ZCUIFont12;
    NSString *sting = @"--";

    if (remarkStr.length > 0) {
        sting = remarkStr;
    }else{
        if(zcLibConvertToString(model.remark).length > 0){
            sting = zcLibConvertToString(model.remark);
        }
    }
    
    NSString *lanStr = ZCSTLocalString(@"评语");
        
    conlab.text = [NSString stringWithFormat:@"%@：%@",lanStr,sting];
    
    [_footView addSubview:conlab];
    [conlab setTextAlignment:NSTextAlignmentLeft];
    if(isRTLLayout()){
           [conlab setTextAlignment:NSTextAlignmentRight];
    }
        
    
    CGSize textSize = [self autoHeightOfLabel:conlab with: self.listTable.frame.size.width - ZCNumber(40) IsSetFrame:NO];
    
    conlab.frame = CGRectMake(ZCNumber(20), CGRectGetMaxY(labScore.frame) + ZCNumber(7), self.listTable.frame.size.width - ZCNumber(40), textSize.height);
    
    _footView.frame = CGRectMake(0, 0, self.listTable.frame.size.width, ZCNumber(114) - ZCNumber(18) + textSize.height);
    
    
    // 线条
    UIView *lineView_1 = [[UIView alloc]initWithFrame:CGRectMake(0, _footView.frame.size.height - 1, self.listTable.frame.size.width, 0.5)];
    lineView_1.backgroundColor = UIColorFromRGB(lineGrayColor);
    [_footView addSubview:lineView_1];
    
    UIView *bgView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(lineView_1.frame), ScreenWidth, 40)];
    bgView.backgroundColor = UIColorFromRGB(0xF8F9FA);
    [_footView addSubview:bgView];

    return _footView;
}




-(NSString *)filterHtmlImage:(NSString *)tmp{
    
    NSString *picStr = [NSString stringWithFormat:@"[%@]",ZCSTLocalString(@"图片")];
    
    NSRegularExpression *regularExpression = [NSRegularExpression regularExpressionWithPattern:@"<img.*?/>" options:0 error:nil];
    tmp  = [regularExpression stringByReplacingMatchesInString:tmp options:0 range:NSMakeRange(0, tmp.length) withTemplate:picStr];
    
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<br />" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<br/>" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<br>" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<BR/>" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<BR />" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<p>" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"</p>" withString:@" "];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"&nbsp;" withString:@" "];
    while ([tmp hasPrefix:@"\n"]) {
        tmp=[tmp substringWithRange:NSMakeRange(1, tmp.length-1)];
    }
    return tmp;
    
}

#pragma mark - 评论返回结果
- (void)actionSheetClickWithDic:(NSDictionary *)modelDic{
    self.evaluateModelDic = modelDic;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        ZCRecordListModel *first = self.listArray.firstObject;
        first.isEvalution = 1;
        
        [self loadData];
        
        NSString *key = [NSString stringWithFormat:@"TicketKEY_%@",zcLibConvertToString(_ticketId)];
        [ZCLocalStore removeObjectByKey:key];
    });
}

#pragma delegate
// 赋值的时候，不执行
-(void)ratingChanged:(float)newRating{

}

-(void)ratingChangedWithTap:(float)newRating{
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


#pragma mark - ZCReplyLeaveView delegate

- (void)replyLeaveViewPickImg:(NSInteger )buttonIndex {
//    [self.replyLeaveView tappedCancel:YES];
    
    
    self.zc_imagepicker = nil;
    self.zc_imagepicker = [[UIImagePickerController alloc]init];
    self.zc_imagepicker.delegate = self;
    _zc_imagepicker.mediaTypes = [NSArray arrayWithObjects:@"public.movie", @"public.image", nil];
    self.zc_imagepicker.modalPresentationStyle = UIModalPresentationFullScreen;
    [ZCSobotCore getPhotoByType:buttonIndex byUIImagePickerController:_zc_imagepicker Delegate:self];
    
}

- (void)replyLeaveViewPreviewImg:(UIButton *)button{
    NSInteger currentInt = button.tag - 100;

    NSString *imgPathStr;
    if(zcLibCheckFileIsExsis([_imagePathArr objectAtIndex:currentInt])){
        imgPathStr = [_imagePathArr objectAtIndex:currentInt];
    }
    NSDictionary *imgDic = [_imageArr objectAtIndex:currentInt];
    NSString *imgFileStr =  zcLibConvertToString(imgDic[@"cover"]);
    
    if (imgFileStr.length>0) {
//        视频预览
        
        NSURL *imgUrl = [NSURL fileURLWithPath:imgPathStr];
        UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
        ZCVideoPlayer *player = [[ZCVideoPlayer alloc] initWithFrame:window.bounds withShowInView:window url:imgUrl Image:button.imageView.image];
        [player showControlsView];
        
    }else{
//     图片预览
        
        UIImageView *picView=(UIImageView*)button.imageView ;
        CALayer *calayer = picView.layer.mask;
        [picView.layer.mask removeFromSuperlayer];
        
        ZCUIXHImageViewer *xh=[[ZCUIXHImageViewer alloc] initWithImageViewerWillDismissWithSelectedViewBlock:^(ZCUIXHImageViewer *imageViewer, UIImageView *selectedView) {
            
        } didDismissWithSelectedViewBlock:^(ZCUIXHImageViewer *imageViewer, UIImageView *selectedView) {
            
            selectedView.layer.mask = calayer;
            [selectedView setNeedsDisplay];
        } didChangeToImageViewBlock:^(ZCUIXHImageViewer *imageViewer, UIImageView *selectedView) {
            
        }];
        
        NSMutableArray *photos = [[NSMutableArray alloc] init];
        [photos addObject:picView];
        xh.disableTouchDismiss = NO;
        [xh showWithImageViews:photos selectedView:picView];
    }
    
}

- (void)closeWithReplyStr:(NSString *)replyStr{
    self.replyStr = replyStr;
    
}

- (void)replyLeaveViewDeleteImg:(NSInteger )buttonIndex{
    NSInteger currentInt = buttonIndex - 100;
    [_imageArr removeObjectAtIndex:currentInt];
    [_imagePathArr removeObjectAtIndex:currentInt];
    
    self.replyLeaveView.imagePathArr = self.imagePathArr;
    self.replyLeaveView.imageArr = self.imageArr;
    [self.replyLeaveView reloadScrollView];
    
    
}

- (void)replySuccess{
    
    [_imageArr removeAllObjects];
    [_imagePathArr removeAllObjects];
//    [self.replyLeaveView reloadScrollView];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [[ZCUIToastTools shareToast] showToast:ZCSTLocalString(@"提交成功！") duration:1.0f view:self.view position:ZCToastPositionCenter Image:[ZCUITools zcuiGetBundleImage:@"zcicon_successful"]];
    });
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
       [self loadData];
    });
    
    
}


#pragma mark - UIImagePickerControllerDelegate
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:^{
        
    }];
}


-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{

    [_zc_imagepicker dismissViewControllerAnimated:YES completion:^{
        
        __weak  ZCMsgDetailsVC *_myselft  = self;
        [ZCSobotCore imagePickerController:_zc_imagepicker didFinishPickingMediaWithInfo:info WithView:self.view Delegate:self block:^(NSString *filePath, ZCMessageType type, NSDictionary *duration) {

            if(type == ZCMessageTypePhoto){
                [_myselft updateloadFile:filePath type:ZCMessageTypePhoto dict:info];
            }else{
                [_myselft converToMp4:duration withInfoDic:info];
            }
        }];
    }];
}


-(void)updateloadFile:(NSString *)filePath type:(ZCMessageType) type dict:(NSDictionary *) cover{

    __weak  ZCMsgDetailsVC *_myself  = self;
//        [ZCSobotCore imagePickerController:_zc_imagepicker didFinishPickingMediaWithInfo:cover WithView:self.view Delegate:self block:^(NSString *filePath, ZCMessageType type, NSDictionary *dict) {

            [[[ZCUICore getUICore] getAPIServer] fileUploadForLeave:filePath commanyId:@"" start:^{
                [[ZCUIToastTools shareToast] showProgress:[NSString stringWithFormat:@"%@...",ZCSTLocalString(@"上传中")]  with:_myself.view];
            } success:^(NSString *fileURL, ZCNetWorkCode code) {

                [[ZCUIToastTools shareToast] dismisProgress];
                if (zcLibIs_null(_imageArr)) {
                    _myself.imageArr = [NSMutableArray arrayWithCapacity:0];
                }
                if (zcLibIs_null(_imagePathArr)) {
                    _myself.imagePathArr = [NSMutableArray arrayWithCapacity:0];
                }
                [_myself.imagePathArr addObject:filePath];

                NSDictionary * dic = @{@"fileUrl":fileURL};
    //            ZCUploadImageModel * item = [[ZCUploadImageModel alloc]initWithMyDict:dic];
                
                if(type == ZCMessageTypeVideo){
                    dic = @{@"cover":cover[@"cover"],@"fileUrl":fileURL};
                    [_myself.imageArr addObject:dic];
//
                }else{
                    [_myself.imageArr addObject:dic];
                }
                
                _myself.replyLeaveView.imagePathArr = _myself.imagePathArr;
                _myself.replyLeaveView.imageArr = _myself.imageArr;
                [_myself.replyLeaveView reloadScrollView];
    ////            [_listTable reloadData];
    //            [_myself reloadScrollView];

            } fail:^(ZCNetWorkCode errorCode) {
                [[ZCUIToastTools shareToast] showToast:ZCSTLocalString(@"网络错误，请检查网络后重试") duration:1.0f view:_myself.view position:ZCToastPositionCenter];
            }];

//        }];
}

- (NSString *)URLDecodedString:(NSString *) url
{
    NSString *result = [(NSString *)url stringByReplacingOccurrencesOfString:@"+" withString:@" "];
    return [result stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
}

-(void) converToMp4:(NSDictionary *)dict withInfoDic:(NSDictionary *)infoDic{

    NSURL *videoUrl = dict[@"video"];
    NSString *coverImg = dict[@"image"];
    
    NSMutableDictionary *infoMutDic = [infoDic mutableCopy];
    [infoMutDic setValue:coverImg forKey:@"cover"];

    AVURLAsset *avAsset = [AVURLAsset URLAssetWithURL:videoUrl options:nil];

    //    NSArray *compatiblePresets = [AVAssetExportSession exportPresetsCompatibleWithAsset:avAsset];

    [[ZCUIToastTools shareToast] showToast:ZCSTLocalString(@"视频处理中，请稍后!") duration:1.0 view:self.view  position:ZCToastPositionCenter];

    __weak  ZCMsgDetailsVC *keyboardSelf  = self;
    AVAssetExportSession *exportSession = [[AVAssetExportSession alloc] initWithAsset:avAsset presetName:AVAssetExportPresetMediumQuality];

    //    NSDateFormatter *formater = [[NSDateFormatter alloc] init];//用时间给文件全名，以免重复
    //    [formater setDateFormat:@"yyyy-MM-dd-HH:mm:ss"];

    NSString * fname = [NSString stringWithFormat:@"/sobot/output-%ld.mp4",(long)[NSDate date].timeIntervalSince1970];
    zcLibCheckPathAndCreate(zcLibGetDocumentsFilePath(@"/sobot/"));
    NSString *resultPath=zcLibGetDocumentsFilePath(fname);
    //    NSLog(@"resultPath = %@",resultPath);
    exportSession.outputURL = [NSURL fileURLWithPath:resultPath];
    exportSession.outputFileType = AVFileTypeMPEG4;
    exportSession.shouldOptimizeForNetworkUse = YES;
    [exportSession exportAsynchronouslyWithCompletionHandler:^(void)
     {
         switch (exportSession.status) {
             case AVAssetExportSessionStatusCompleted:{
                 //                 NSLog(@"AVAssetExportSessionStatusCompleted%@",[NSThread currentThread]);
                 // 主队列回调
                 dispatch_async(dispatch_get_main_queue(), ^{
                     [keyboardSelf updateloadFile:[self URLDecodedString:resultPath] type:ZCMessageTypeVideo dict:infoMutDic];
                 });
             }
                 break;
             case AVAssetExportSessionStatusUnknown:
                 //                 NSLog(@"AVAssetExportSessionStatusUnknown");
                 break;

             case AVAssetExportSessionStatusWaiting:

                 //                 NSLog(@"AVAssetExportSessionStatusWaiting");

                 break;

             case AVAssetExportSessionStatusExporting:

                 //                 NSLog(@"AVAssetExportSessionStatusExporting");

                 break;
             case AVAssetExportSessionStatusFailed:

                 //                 NSLog(@"AVAssetExportSessionStatusFailed");

                 break;
             case AVAssetExportSessionStatusCancelled:

                 break;
         }
     }];
}



@end
