//
//  ZCMsgRecordCell.m
//  SobotKit
//
//  Created by lizhihui on 2019/2/19.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import "ZCMsgRecordCell.h"
#import "ZCUIColorsDefine.h"
#import "ZCLibGlobalDefine.h"
#import "ZCHtmlCore.h"
#import "ZCHtmlFilter.h"

@interface ZCMsgRecordCell(){
    
}

@property (nonatomic,strong) UILabel * titleLab;

@property (nonatomic,strong) UIImageView * picLab;

@property (nonatomic,strong) UILabel * statusLab;

@property (nonatomic,strong) UILabel * conLab;// content

@property (nonatomic,strong) UILabel * timeLab;

@property (nonatomic,strong) UILabel * orderIdLab;// 工单编号

@property (nonatomic,strong) UIView * bgView;

@property (nonatomic,strong) UIView * lineView;

// 2.8.0 增加两条线
@property (nonatomic,strong) UIView * topLineView;

@property (nonatomic,strong) UIView * bottomLineView;


@end

@implementation ZCMsgRecordCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]){
        self.contentView.backgroundColor = UIColorFromRGB(TextRecordBgColor);
        _bgView = [[UIView alloc]init];
        _bgView.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:_bgView];
//        _bgView.layer.cornerRadius = 3.5f;
//        _bgView.layer.masksToBounds = YES;
        
        _topLineView = [[UIView alloc]init];
        _topLineView.backgroundColor = UIColorFromRGB(lineGrayColor);
//        _topLineView.backgroundColor = [UIColor redColor];
        [_bgView addSubview:_topLineView];
        
        _bottomLineView = [[UIView alloc]init];
        _bottomLineView.backgroundColor = UIColorFromRGB(lineGrayColor);
//        _bottomLineView.backgroundColor = [UIColor clearColor];

        [_bgView addSubview:_bottomLineView];
        
        _titleLab = [[UILabel alloc]init];
        _titleLab.font = ZCUIFont14;
        _titleLab.textColor = UIColorFromRGB(TextRecordOrderIdColor);
        [_titleLab setNumberOfLines:2];
        [_bgView addSubview:_titleLab];
        
//        _picLab = [[UILabel alloc]init];
//        _picLab.text = @"NEW";
//        _picLab.textColor = UIColorFromRGB(TextTopColor);
//        _picLab.font = ZCUIFontBold10; // FF4467
//        _picLab.backgroundColor = UIColorFromRGB(0xFF4467);
//        _picLab.textAlignment = NSTextAlignmentCenter;
//        _picLab.layer.masksToBounds = YES;
//        _picLab.layer.cornerRadius = 3.0f;
        
        _picLab = [[UIImageView alloc] initWithImage:[ZCUITools zcuiGetBundleImage:@"zcicon_new_tag"]];
        
        
        
        [_bgView addSubview:_picLab];
        
        
        
        _statusLab = [[UILabel alloc]init];
        _statusLab.textAlignment = NSTextAlignmentCenter;
        _statusLab.textColor = UIColorFromRGB(TextTopColor);
        _statusLab.backgroundColor = UIColorFromRGB(BgTitleColor);
        _statusLab.font = ZCUIFont14;
        _statusLab.layer.cornerRadius = ZCNumber(15);
        _statusLab.layer.masksToBounds = YES;
        [_bgView addSubview:_statusLab];
        
//        _conLab = [[UILabel alloc]init];
//        [_conLab setNumberOfLines:2];
//        _conLab.textColor = UIColorFromRGB(TextRecordDetailColor);
//        _conLab.font = ZCUIFont14;
//        [_bgView addSubview:_conLab];
        
        
        _timeLab = [[UILabel alloc]init];
        _timeLab.textAlignment = NSTextAlignmentLeft;
        _timeLab.font = ZCUIFontBold16;
        [_timeLab setTextColor:UIColorFromRGB(recordTimeTextColor)];
        [_bgView addSubview:_timeLab];
        
        _orderIdLab = [[UILabel alloc]init];

//        _orderIdLab.textColor = UIColorFromRGB(TextRecordOrderIdColor);
//        _orderIdLab.font = ZCUIFont11;
//        _orderIdLab.textAlignment = NSTextAlignmentLeft;
//        [_bgView addSubview:_orderIdLab];
//
//        _lineView = [[UIView alloc] init];
//        _lineView.backgroundColor = UIColorFromRGB(lineGrayColor);
//        [_bgView addSubview:_lineView];
        
    }
    
    return self;
}


-(void)initWithDict:(ZCRecordListModel*)model with:(CGFloat) width{
    
    _bgView.frame = CGRectMake(ZCNumber(0), 11, width - ZCNumber(0), ZCNumber(110));
    _bgView.backgroundColor = UIColorFromRGB(TextTopColor);
    
    _timeLab.frame =  CGRectMake(ZCNumber(20), ZCNumber(16), ZCNumber(170), ZCNumber(20));
//    _timeLab.backgroundColor = [UIColor blueColor];
    NSMutableAttributedString *attributedStr = [[NSMutableAttributedString alloc] initWithString:zcLibConvertToString(model.content)];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 6.0; // 设置行间距
    [attributedStr addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, attributedStr.length)];
    
//    _titleLab.text = zcLibConvertToString(model.content);
//    _titleLab.attributedText = attributedStr;
    
    //@"问题描述lsakl阿里速度快缴费拉卡掉了金风科技埃里克森的家乐福卡拉伸的开发";
    _titleLab.frame = CGRectMake(ZCNumber(20),ZCNumber(47), CGRectGetWidth(_bgView.frame) -ZCNumber(122), ZCNumber(20));
//    _titleLab.backgroundColor = [UIColor blueColor];
    // 计算文本的宽度
    CGSize titleSize = [self sizeWithText:_titleLab.text withFont:_titleLab.font];
    if (titleSize.width > _titleLab.frame.size.width) {
        [_titleLab sizeToFit];
    }
    
    
    [self setString:zcLibConvertToString(model.content) withlLabel:_titleLab withColor:UIColorFromRGB(0xacb5c4)];
    
    
//    _titleLab.backgroundColor = [UIColor redColor];
    //    _timeLab.frame = CGRectMake(CGRectGetMaxX(_orderIdLab.frame), CGRectGetMaxY(_lineView.frame) + ZCNumber(6), CGRectGetWidth(_orderIdLab.frame), CGRectGetHeight(_orderIdLab.frame));
        _timeLab.text = zcLibConvertToString(model.timeStr);// @"2019年01月11日 22:10";
    [_timeLab sizeToFit];
    // 显示最新处理过的工单编号 new

    _picLab.frame = CGRectMake(CGRectGetMaxX(_timeLab.frame)+ZCNumber(5), _timeLab.frame.origin.y+ZCNumber(2), ZCNumber(26), ZCNumber(14));

    _picLab.hidden = YES;
    if (model.newFlag == 2) {
        _picLab.hidden = NO;
    }
    
//    [_picLab sizeToFit];
    
    _statusLab.frame = CGRectMake(CGRectGetWidth(_bgView.frame) - ZCNumber(92), CGRectGetHeight(_bgView.frame) - ZCNumber(30) - ZCNumber(24), ZCNumber(72), ZCNumber(30));
    _statusLab.text = ZCSTLocalString(@"已创建");
    
    switch (model.flag) {
        case 1:
            _statusLab.text =  ZCSTLocalString(@"已创建");
            _statusLab.backgroundColor = UIColorFromRGB(0xE4EAF2);
            break;
        case 2:
            _statusLab.text =  ZCSTLocalString(@"受理中");
            _statusLab.backgroundColor = UIColorFromRGB(0xF6AF38);
            break;
        case 3:
            _statusLab.text =  ZCSTLocalString(@"已完成");
            _statusLab.backgroundColor = UIColorFromRGB(BgTitleColor);
            break;
        default:
            break;
    }
    
    
    CGSize s = [_statusLab.text sizeWithAttributes:@{NSFontAttributeName:_statusLab.font}];
    if(s.width > 72){
        _statusLab.frame = CGRectMake(CGRectGetWidth(_bgView.frame) - 10 - s.width-10, _titleLab.frame.origin.y, s.width+10, ZCNumber(20));
    }
//    _conLab.frame = CGRectMake(ZCNumber(10), CGRectGetMaxY(_titleLab.frame) +ZCNumber(10), CGRectGetWidth(_bgView.frame) - ZCNumber(20), ZCNumber(40));
//    _conLab.backgroundColor = [UIColor redColor];
//    _conLab.text = @"";//@"手机号不变更问题-由于近期些地方拉开接待来访控件的拉看电视剧了父控件拉开的设计费拉拉伸的开发就拉开的设计费老款就阿里山的开发拉卡世纪东方老卡机拉开的设计费老卡机的斯洛伐克就拉开大姐夫了卡上的缴费了拉开到健身房拉卡拉的控件";
    
//    _lineView.frame = CGRectMake(ZCNumber(10), CGRectGetMaxY(_conLab.frame) + ZCNumber(6), CGRectGetWidth(_bgView.frame)-ZCNumber(20), 0.5);

//    _orderIdLab.frame = CGRectMake(ZCNumber(10), CGRectGetMaxY(_lineView.frame)+ ZCNumber(6), CGRectGetWidth(_conLab.frame)/2, ZCNumber(15));
//
//    _orderIdLab.text = [NSString stringWithFormat:ZCSTLocalString(@"工单号：%@"),model.ticketCode];// @"工单号：390876677443";
    
//    _lineView.hidden = YES;
//    _orderIdLab.hidden = YES;
    
    
    _topLineView.frame = CGRectMake(0, 0, _bgView.frame.size.width, 0.5);
    _bottomLineView.frame = CGRectMake(0, _bgView.frame.size.height - 0.5, _bgView.frame.size.width, 0.5);

}


#pragma mark -- 获取文本的宽度
/**
 
 计算单行文字的size
 
 @parms  文本
 
 @parms  字体
 
 @return  字体的CGSize
 
 */
-(CGSize)sizeWithText:(NSString *)text withFont:(UIFont *)font{
    
    CGSize size = [text sizeWithAttributes:@{NSFontAttributeName:font}];
    
    return size;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setString:(NSString *)string withlLabel:(UILabel *)label withColor:(UIColor *)textColor {
    [ZCHtmlCore filterHtml: [ZCHtmlCore filterHTMLTag:string] result:^(NSString * _Nonnull text1, NSMutableArray * _Nonnull arr, NSMutableArray * _Nonnull links) {
 
        if (text1.length > 0 && text1 != nil) {
            label.attributedText =   [ZCHtmlFilter setHtml:text1 attrs:arr view:label textColor:textColor textFont:label.font linkColor:[ZCUITools zcgetChatLeftLinkColor]];
        }else{
            label.attributedText =   [[NSAttributedString alloc] initWithString:@""];
        }

    }];
    
}

@end
