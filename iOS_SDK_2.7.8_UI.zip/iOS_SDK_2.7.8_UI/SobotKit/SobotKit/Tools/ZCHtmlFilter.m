//
//  ZCHtmlFilter.m
//  SobotKit
//
//  Created by zhangxy on 2019/4/25.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import "ZCHtmlFilter.h"

#import "ZCMLEmojiLabel.h"

@implementation ZCHtmlFilter

+(NSMutableAttributedString *)setHtml:(NSString *)text attrs:(NSMutableArray *) attrs view:(UILabel *) label  textColor:(UIColor*)textColor textFont:(UIFont*)textFont linkColor:(UIColor*)linkColor{
    __block NSMutableAttributedString  *str = nil;
    
    str = [[NSMutableAttributedString alloc] initWithString:text];
    
    // 先处理 ZCMLEmojiLabel 正则的匹配
    if ([label isKindOfClass:[ZCMLEmojiLabel class]]) {
        [label setTextColor:textColor];
        [((ZCMLEmojiLabel *)label) setLinkColor:linkColor];
        [((ZCMLEmojiLabel *)label) setText:str];
        str =[[NSMutableAttributedString alloc] initWithAttributedString:((ZCMLEmojiLabel *)label).attributedText];
    }
    
    [str addAttribute:NSFontAttributeName value:textFont range:NSMakeRange(0, str.length)];
    [str addAttribute:NSForegroundColorAttributeName value:textColor range:NSMakeRange(0, str.length)];
    
    
    for (NSDictionary *item in attrs) {
        NSRange range = NSMakeRange([item[@"location"] intValue], [item[@"len"] intValue]);
        
        if([item[@"tag"] isEqual:@"B"]){
            [str addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Helvetica-BoldOblique" size:17] range:range];
        }
        
        if([item[@"tag"] isEqual:@"A"]){
            [str addAttribute:NSForegroundColorAttributeName value:linkColor range:range];
            
            
            if([label isKindOfClass:[ZCMLEmojiLabel class]]){
                 [((ZCMLEmojiLabel *)label) addLinkToURL:[NSURL URLWithString:item[@"href"]] withRange:range];
            }else{
                [str addAttribute:NSLinkAttributeName value:[NSURL URLWithString:item[@"href"]] range:range];
            }
        }
        if([item[@"tag"] isEqual:@"I"]){
            CGAffineTransform matrix =  CGAffineTransformMake(1, 0, tanf(10 * (CGFloat)M_PI / 180), 1, 0, 0);
            UIFontDescriptor *desc = [UIFontDescriptor fontDescriptorWithName:[UIFont boldSystemFontOfSize:textFont.pointSize].fontName matrix:matrix];
            [str addAttribute:NSFontAttributeName value:[UIFont fontWithDescriptor:desc size:textFont.pointSize] range:range];
        }
        if([item[@"tag"] isEqual:@"IMG"]){
//            NSString *cachesPath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
//            NSString *filename = [item[@"src"] lastPathComponent];
//            NSString *file = [cachesPath stringByAppendingPathComponent:filename];
//            NSData *data = [NSData dataWithContentsOfFile:file];
//            if (data) {
//                UIImage *image = [UIImage imageWithData:data];
//                [self insertMs:image dit:item str:str];
//            } else {
//
//                [self insertMs:[UIImage imageNamed:@"Icon-72"] dit:item str:str];
//
//                [self.queue addOperationWithBlock:^{
//                    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:item[@"src"]]];
//                    UIImage *image = [UIImage imageWithData:data];
//                    [[NSOperationQueue mainQueue] addOperationWithBlock:^{
//                        [self replaceMs:image dit:item str:str];
//                    }];
//
//                    [data writeToFile:file atomically:YES];
//                }];
//            }
        }
        
    }
    
   
    
    
    label.attributedText = str;
    return str;
}


@end
