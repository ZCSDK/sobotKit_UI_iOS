//
//  BaseNavViewController.h
//  SobotKitFrameworkTest
//
//  Created by zhangxy on 16/3/31.
//  Copyright © 2016年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseNavViewController : UINavigationController

@end
