//
//  ZCDemoSettingVC.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCDemoSettingVC : UIViewController

@property (nonatomic,strong) ZCKitInfo * kitInfo;

@end
