//
//  ZCSettingevaluationVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCSettingevaluationVC.h"

@interface ZCSettingevaluationVC ()

@end

@implementation ZCSettingevaluationVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setNavc];
    [self layoutSubviews];
    self.bgScrollView.backgroundColor = UIColorFromRGB(0xEFF3FA);
    self.lineView.backgroundColor = UIColorFromRGB(0xdadada);
    CGRect lineF = self.lineView.frame;
    lineF.size.height = 0.5f;
    self.lineView.frame = lineF;
}

-(void)layoutSubviews{
    
    _isCloseSessionWhenBackSwitch.on = NO;
    _isBackevaluationSwitch.on = NO;

    
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"isOpenEvaluation"]) {
        _isBackevaluationSwitch.on = [[NSUserDefaults standardUserDefaults] boolForKey:@"isOpenEvaluation"];
    }
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"isCloseAfterEvaluation"]) {
        _isCloseSessionWhenBackSwitch.on = [[NSUserDefaults standardUserDefaults] boolForKey:@"isCloseAfterEvaluation"];
    }
    
    _isBackevaluationSwitch.tag = 401;
    _isCloseSessionWhenBackSwitch.tag = 402;
     [_isBackevaluationSwitch addTarget:self action:@selector(selectorswitchValueChanged:) forControlEvents:UIControlEventValueChanged];
     [_isCloseSessionWhenBackSwitch addTarget:self action:@selector(selectorswitchValueChanged:) forControlEvents:UIControlEventValueChanged];
}

-(void)setNavc{
    self.title = @"评价";
    
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    [leftBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 0);
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
}

-(void)backAction:(UIButton *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)selectorswitchValueChanged:(UISwitch *)sender{
    switch (sender.tag) {
        case 401:
            if (sender.on) {
//                _kitInfo.isOpenEvaluation = YES;
                [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isOpenEvaluation"];
            }else{
//                _kitInfo.isOpenEvaluation = NO;
                [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"isOpenEvaluation"];
            }
            break;
        case 402:
            if (sender.on) {
//                _kitInfo.isCloseAfterEvaluation = YES;
                [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isCloseAfterEvaluation"];
            }else{
//                _kitInfo.isCloseAfterEvaluation = YES;
                [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"isCloseAfterEvaluation"];
            }
            break;
        default:
            break;
    }
    
    if (_evaluationBlock) {
        _evaluationBlock(_kitInfo);
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
