//
//  ZCRobotIntroduceView.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/12/8.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCRobotIntroduceView.h"

@interface ZCRobotIntroduceView(){
    
}

@property (nonatomic,strong) UIImageView * imgView;

@property (nonatomic,strong) UILabel * titleLab;


@end



@implementation ZCRobotIntroduceView

-(instancetype)initWithFrame:(CGRect)frame WithDict:(NSDictionary *)dict WithSuperView:(UIView*)superView{

    if (self == [super initWithFrame:frame]) {
        self.frame = frame;
        self.imgView = [[UIImageView alloc]initWithFrame:CGRectMake(ZCNumber(20), 0, ScreenWidth - ZCNumber(40), 160)];
        self.imgView.image = [UIImage imageNamed:dict[@"Img"]];
        self.imgView.contentMode = UIViewContentModeScaleAspectFit;
        [self addSubview: self.imgView];
        
        
        self.titleLab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(self.imgView.frame) + ZCNumber(23), ScreenWidth - ZCNumber(40), 20)];
        self.titleLab.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:14];
//        self.titleLab.textColor = UIColorFromRGB(0x3D4966);
        self.titleLab.textAlignment = NSTextAlignmentLeft;
        self.titleLab.text = dict[@"title"];
        [self addSubview:self.titleLab];
        
        
        CGFloat height = [self createTitleArr:dict[@"titleArr"] WithView:self Height:CGRectGetMaxY(self.titleLab.frame) + ZCNumber(10)];
        CGRect SF = self.frame;
        SF.size.height = height + 50;
        self.frame = SF;
        
        
        [superView addSubview:self];
        
    }
    return self;
    
    
}

// 循环创建 label
-(CGFloat)createTitleArr:(NSArray *)arr WithView:(UIView *)view Height:(CGFloat)height{
    
    CGFloat itemH = height;
    for (int i = 0; i<arr.count; i++) {
        UILabel * listLab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), itemH, ScreenWidth - ZCNumber(40), 20)];
        listLab.textAlignment = NSTextAlignmentLeft;
        listLab.text = arr[i];
        listLab.textColor = UIColorFromRGB(0x001F2A);
        listLab.numberOfLines = 0;
        listLab.font = [UIFont systemFontOfSize:14];
        [view addSubview:listLab];
        // 重新计算label的高度
        [self getTextRectWith:arr[i] WithMaxWidth:ScreenWidth - ZCNumber(40) WithlineSpacing:5 AddLabel:listLab];
        itemH  = itemH + CGRectGetHeight(listLab.frame) + 10;
    }
    
    return itemH;
    
}

-(CGRect)getTextRectWith:(NSString *)str WithMaxWidth:(CGFloat)width  WithlineSpacing:(CGFloat)LineSpacing AddLabel:(UILabel *)label{
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc]initWithString:str];
    // 文字颜色
    NSUInteger firstloc = [[attributedString string]rangeOfString:@"·"].location ;
    NSRange range = NSMakeRange(firstloc, 1);
    [attributedString addAttribute:NSForegroundColorAttributeName value:UIColorFromRGB(0x0DAEAF) range:range];
    NSMutableParagraphStyle * parageraphStyle = [[NSMutableParagraphStyle alloc]init];
    [parageraphStyle setLineSpacing:LineSpacing];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:parageraphStyle range:NSMakeRange(0, [str length])];
    [attributedString addAttribute:NSFontAttributeName value:label.font range:NSMakeRange(0, str.length)];
    
    label.attributedText = attributedString;
    
    // 这里的高度的计算，不能在按 attributedString的属性去计算了，需要拿到label中的
    CGSize size = [self autoHeightOfLabel:label with:width];
    
    CGRect labelF = label.frame;
    labelF.size.height = size.height;
    label.frame = labelF;
    
    
    return labelF;
}


/**
 计算Label高度
 
 @param label 要计算的label，设置了值
 @param width label的最大宽度
 @param type 是否从新设置宽，1设置，0不设置
 */
- (CGSize )autoHeightOfLabel:(UILabel *)label with:(CGFloat )width{
    //Calculate the expected size based on the font and linebreak mode of your label
    // FLT_MAX here simply means no constraint in height
    CGSize maximumLabelSize = CGSizeMake(width, FLT_MAX);
    
    CGSize expectedLabelSize = [label sizeThatFits:maximumLabelSize];
    
    //adjust the label the the new height.
    CGRect newFrame = label.frame;
    newFrame.size.height = expectedLabelSize.height;
    label.frame = newFrame;
    [label updateConstraintsIfNeeded];
    
    return expectedLabelSize;
}


@end
