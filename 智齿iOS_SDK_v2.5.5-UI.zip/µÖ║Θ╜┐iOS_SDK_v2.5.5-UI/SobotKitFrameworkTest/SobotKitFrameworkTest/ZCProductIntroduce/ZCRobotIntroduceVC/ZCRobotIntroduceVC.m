//
//  ZCRobotIntroduceVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/12/8.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCRobotIntroduceVC.h"
#import "ZCRobotIntroduceView.h"
//#import "ZCOnlineButton.h"
#import "ZCNSuserdefaultdManager.h"
@interface ZCRobotIntroduceVC (){
    
}

@property (nonatomic,strong) UIScrollView * scrollView;

@property (nonatomic ,strong) UILabel * titleLab;

@property (nonatomic,strong) UILabel * detailLab;

@property (nonatomic,strong) ZCRobotIntroduceView *robotView;
@end

@implementation ZCRobotIntroduceVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"智能机器人";
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    [self.navigationController setToolbarHidden:YES animated:NO];
   
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    //    [leftBtn setTitleColor:UIColorFromRGB(0x39B9C2) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    //    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    [self setupUI];
}

-(void)backAction:(UIButton *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)setupUI{
    
    CGFloat XH = 0;
    if (ZC_iPhoneX) {
        XH = 34;
    }
    self.scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, NavBarHeight, ScreenWidth, ScreenHeight - NavBarHeight - 50 -XH)];
    self.scrollView.backgroundColor = [UIColor clearColor];
    self.scrollView.scrollEnabled = YES;
    self.scrollView.alwaysBounceVertical = YES;
    self.scrollView.alwaysBounceHorizontal = NO;
    self.scrollView.showsVerticalScrollIndicator = NO;
    self.scrollView.bounces = NO;
    self.scrollView.userInteractionEnabled = YES;
    [self.view addSubview:self.scrollView];
    
    
    self.titleLab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), ZCNumber(21), ScreenWidth - ZCNumber(40), 25)];
    self.titleLab.textAlignment = NSTextAlignmentLeft;
    self.titleLab.text = @"最懂业务场景的客服机器人为您服务";
    self.titleLab.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:18];
//    self.titleLab.textColor = UIColorFromRGB(0x3D4966);
    [self.scrollView addSubview:self.titleLab];
    
    self.detailLab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(self.titleLab.frame) + 6, ScreenWidth - ZCNumber(40), 17)];
    self.detailLab.text = @"金牌客服永不离线，节省85%以上人力成本";
    self.detailLab.textColor = UIColorFromRGB(0xBDC3D1);
    self.detailLab.font = [UIFont systemFontOfSize:12];
    [self.scrollView addSubview:_detailLab];
    
    // 组合控件
    
    NSMutableArray * arr = [NSMutableArray arrayWithCapacity:0];
    
    NSDictionary * dict1 = @{@"Img":@"robot_1",
                             @"title":@"1.客服效率提升100%",
                             @"titleArr":@[@"·客服机器人7×24小时在线。",
                                           @"·机器人辅助人工，人工客服效率提升100%。",
                                           @"·人工忙时机器人主动接管，客服接待0延迟"]
                             };
    NSDictionary * dict2 = @{@"Img":@"robot_2",
                             @"title":@"2.人力成本节约85%",
                             @"titleArr":@[@"·四种接待方式，匹配不同业务场景。",
                                           @"·五分钟配置知识库，新问题自动学习。"
                                           ]
                             };
    NSDictionary * dict3 = @{@"Img":@"robot_3",
                             @"title":@"3.客户满意度提升70%",
                             @"titleArr":@[@"·机器人回答命中率高达97%。",
                                           @"·寒暄+业务回答，85%常见问题自主解决。"
                                           ]
                             };
    
    [arr addObject:dict1];
    [arr addObject:dict2];
    [arr addObject:dict3];
    
    CGFloat  itemH = CGRectGetMaxY(self.detailLab.frame) + ZCNumber(40);
    
    for (int i = 0; i<arr.count; i++) {
        _robotView = [[ZCRobotIntroduceView alloc]initWithFrame:CGRectMake(0, itemH, ScreenWidth, 280) WithDict:arr[i] WithSuperView:self.scrollView];
        
        itemH = itemH + _robotView.frame.size.height;
    }
    self.scrollView.contentSize = CGSizeMake(ScreenWidth, itemH);
    
    
    //咨询客服
    [self layoutBtn];
}


#pragma mark -- 联系我们
-(void)layoutBtn{
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    CGFloat Y = ScreenHeight - 50;
    if (ZC_iPhoneX) {
        Y = ScreenHeight - 50 - 34;
    }
    btn.frame = CGRectMake(0, Y, ScreenWidth, 50);
    [btn setBackgroundColor:UIColorFromRGB(0x0DAEAF)];
    [btn setTitle:@" 咨询客服" forState:UIControlStateNormal];
    [btn setTitle:@" 咨询客服" forState:UIControlStateHighlighted];
    [btn setImage:[UIImage imageNamed:@"Online"] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:@"Online"] forState:UIControlStateHighlighted];
    [btn addTarget:self action:@selector(openSDK:) forControlEvents:UIControlEventTouchUpInside];

//    btn.imageEdgeInsets = UIEdgeInsetsMake(5, btn.titleLabel.frame.origin.x - 3 - btn.imageView.frame.size.width, 5, btn.titleLabel.frame.origin.x -3);
//    btn.type = 1;
    [self.view addSubview:btn];
}


-(void)openSDK:(UIButton*)sender{
    [ZCNSuserdefaultdManager shareUserdefaultd].type = 1;
    [[ZCNSuserdefaultdManager shareUserdefaultd] openSDKWith:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
