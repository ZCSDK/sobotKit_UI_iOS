//
//  ZCServerIntroduceVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/12/8.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCServerIntroduceVC.h"
#import "ZCRobotIntroduceView.h"
#import "ZCNSuserdefaultdManager.h"
@interface ZCServerIntroduceVC (){
    
}

@property (nonatomic,strong) UIScrollView * scrollView;

@property (nonatomic ,strong) UILabel * titleLab;

@property (nonatomic,strong) UILabel * detailLab;

@property (nonatomic,strong) ZCRobotIntroduceView *robotView;

@end

@implementation ZCServerIntroduceVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"人工在线客服";
    [self.navigationController setToolbarHidden:YES animated:NO];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    //    [leftBtn setTitleColor:UIColorFromRGB(0x39B9C2) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    //    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    [self setupUI];
}

-(void)backAction:(UIButton*)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)setupUI{
    CGFloat XH = 0;
    if (ZC_iPhoneX) {
        XH = 34;
    }
    self.scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, NavBarHeight, ScreenWidth, ScreenHeight - NavBarHeight - 50 -XH)];
    self.scrollView.backgroundColor = [UIColor clearColor];
    self.scrollView.scrollEnabled = YES;
    self.scrollView.alwaysBounceVertical = YES;
    self.scrollView.alwaysBounceHorizontal = NO;
    self.scrollView.showsVerticalScrollIndicator = NO;
    self.scrollView.bounces = NO;
    self.scrollView.userInteractionEnabled = YES;
    [self.view addSubview:self.scrollView];
    
    
    self.titleLab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), ZCNumber(21), ScreenWidth - ZCNumber(40), 25)];
    self.titleLab.textAlignment = NSTextAlignmentLeft;
    self.titleLab.text = @"全渠道智能在线客服统一管理，智能服务";
    self.titleLab.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:18];
    //    self.titleLab.textColor = UIColorFromRGB(0x3D4966);
    [self.scrollView addSubview:self.titleLab];
    
    self.detailLab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(self.titleLab.frame) + 6, ScreenWidth - ZCNumber(40), 17)];
    self.detailLab.text = @"提升在线客服效率，专注线上转化";
    self.detailLab.textColor = UIColorFromRGB(0xBDC3D1);
    self.detailLab.font = [UIFont systemFontOfSize:12];
    [self.scrollView addSubview:_detailLab];
    
    // 组合控件
    
    NSMutableArray * arr = [NSMutableArray arrayWithCapacity:0];
    
    NSDictionary * dict1 = @{@"Img":@"server_1",
                             @"title":@"1.把握客户咨询，商机转化率提升30%",
                             @"titleArr":@[@"·桌面网站、移动网站、App、邮件、微信、微博、短信——七大渠道，全面覆盖，接待响应一站式",
                                           @"·精准用户画像，决策更有智慧",
                                           @"·主动营销服务，专注线上转化"]
                             };
    NSDictionary * dict2 = @{@"Img":@"server_2",
                             @"title":@"2.高效优质服务，成单率提升50%",
                             @"titleArr":@[@"·四种接待方式，匹配不同业务场景",
                                           @"·丰富的富媒体沟通手段，沟通效率翻倍",
                                           @"·机器人客服接待/辅助人工客服服务秒级响应"
                                           ]
                             };
    NSDictionary * dict3 = @{@"Img":@"server_3",
                             @"title":@"3.强大统计报表，业务数据完美升华",
                             @"titleArr":@[@"·工作量/服务质量/满意度等多种服务数据统计，为量化客服管理提供支持",
                                           @"·客户来源/关键词/着陆页/浏览轨迹/历史联络记录——客户全方位洞察，让服务更契合客户所需所想"
                                           ]
                             };
    NSDictionary * dict4 = @{@"Img":@"server_4",
                             @"title":@"4.多重技术保障，保障稳定不丢消息",
                             @"titleArr":@[@"·动态DNS持续重连直至到达/两地三中心备灾方案/业内最优SLA保障体系及赔付方案/大数据集群部署/长连接技术/更适合移动时代的复杂网络环境判断——全方位保障您的消息的稳定性"
                                           ]
                             };
    
    [arr addObject:dict1];
    [arr addObject:dict2];
    [arr addObject:dict3];
    [arr addObject:dict4];
    CGFloat  itemH = CGRectGetMaxY(self.detailLab.frame) + ZCNumber(40);
    
    for (int i = 0; i<arr.count; i++) {
        _robotView = [[ZCRobotIntroduceView alloc]initWithFrame:CGRectMake(0, itemH, ScreenWidth, 280) WithDict:arr[i] WithSuperView:self.scrollView];
        
        itemH = itemH + _robotView.frame.size.height;
    }
    self.scrollView.contentSize = CGSizeMake(ScreenWidth, itemH);
    
    
    //咨询客服
    [self layoutBtn];
}


#pragma mark -- 联系我们
-(void)layoutBtn{
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    CGFloat Y = ScreenHeight - 50;
    if (ZC_iPhoneX) {
        Y = ScreenHeight - 50 - 34;
    }
    btn.frame = CGRectMake(0, Y, ScreenWidth, 50);
    [btn setBackgroundColor:UIColorFromRGB(0x0DAEAF)];
    [btn setTitle:@" 咨询客服" forState:UIControlStateNormal];
    [btn setTitle:@" 咨询客服" forState:UIControlStateHighlighted];
    [btn setImage:[UIImage imageNamed:@"Online"] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:@"Online"] forState:UIControlStateHighlighted];
    [btn addTarget:self action:@selector(openSDK:) forControlEvents:UIControlEventTouchUpInside];
    
    //    btn.imageEdgeInsets = UIEdgeInsetsMake(5, btn.titleLabel.frame.origin.x - 3 - btn.imageView.frame.size.width, 5, btn.titleLabel.frame.origin.x -3);
    //    btn.type = 1;
    [self.view addSubview:btn];
}


-(void)openSDK:(UIButton*)sender{
    [ZCNSuserdefaultdManager shareUserdefaultd].type = 1;
    [[ZCNSuserdefaultdManager shareUserdefaultd] openSDKWith:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
