//
//  ZCKitInitInfo.h
//  SobotKit
//
//  Created by zhangxy on 15/11/13.
//  Copyright © 2015年 zhichi. All rights reserved.
//

#import "ZCProductInfo.h"
#import "ZCOrderGoodsModel.h"


/**
 *  配置初始化自定义类（UI配置相关）
 *  自定义字体（可选） 自定义背景、边框线颜色（可选）
 */
@interface ZCKitInfo : NSObject

/**
 *   调整行间距
 *  默认为 0
 */
@property (nonatomic,assign) NSInteger lineSpacing;


/**
 *  链接地址正则表达式
 *  默认为：
 *  @"((http[s]{0,1}|ftp)://[a-zA-Z0-9\\.\\-]+\\.([a-zA-Z0-9]{1,4})(:\\d+)?(/[a-zA-Z0-9\\.\\-~!@#$%^&*+?:_/=<>]*)?)|(([a-zA-Z0-9]{2,4}).[a-zA-Z0-9\\.\\-]+\\.([a-zA-Z]{2,4})(:\\d+)?(/[a-zA-Z0-9\\.\\-~!@#$%^&*+?:_/=<>]*)?)"
 */
@property (nonatomic,strong) NSString * urlRegular;

/**
*  电话号码正则表达式
 *  默认为@"0+\\d{2}-\\d{8}|0+\\d{2}-\\d{7}|0+\\d{3}-\\d{8}|0+\\d{3}-\\d{7}|1+[34578]+\\d{9}|\\+\\d{2}1+[34578]+\\d{9}|400\\d{7}|400-\\d{3}-\\d{4}|\\d{11}|\\d{10}|\\d{8}|\\d{7}"
 * 例如：82563452、01082563234、010-82543213、031182563234、0311-82563234
 、+8613691080322、4008881234、400-888-1234
 */
@property (nonatomic,strong) NSString * telRegular;

/**
 *   调整机器人引导语 行间距
 *  默认为 0
 */
@property (nonatomic,assign) NSInteger guideLineSpacing;

// 自定义 换业务文案
@property (nonatomic,strong) NSString *changeBusinessStr;

/**
 *  是否有返回提示
 *  默认为 NO
 */
@property (nonatomic,assign) BOOL isShowReturnTips;

/**
 *  push后隐藏 BottomBar
 *  默认为 YES
 */
@property (nonatomic,assign) BOOL ishidesBottomBarWhenPushed;

/**
 *  留言完成后，是否 显示 回复按钮
 *  默认为 yes  , 可以回复
 */
@property (nonatomic,assign) BOOL leaveCompleteCanReply;



/**
 *  已完成留言详情界面：返回时是否弹出服务评价窗口(只会第一次返回弹，下次返回不会再弹)
 *  默认为 NO   , 不主动提醒
 */
@property (nonatomic,assign) BOOL showLeaveDetailBackEvaluate;

/**
 *  仅支持竖屏
 *  默认为 NO
 */
@property (nonatomic,assign) BOOL isShowPortrait;

/**
 *
 *  SDK 页面中使用自定义的导航栏不在使用系统的导航栏（隐藏）
 *  默认 为NO 跟随集成项目
 **/
@property (nonatomic,assign) BOOL navcBarHidden;

/**
 *  接口域名,从2.6.5版本开始，本属性不起作用，请使用ZCLibInitInfo.apiHost
 *  @deprecated 2018-09-05: Use ZCLibInitInfo.h  instead
 */
@property(nonatomic,strong) NSString *apiHost;

/**
 *
 *   人工状态，是否可以发送位置
 【 注意：
 由于各家定位插件特别多，智齿没有实现选择位置功能，所以需要自行传递位置到SDK以及打开显示，步骤如下：
 1、实现messageLinkClick事件（ZCSobot startZCChatVC函数中）
 2、当收到link = sobot://sendlocation 调用智齿接口发送位置信息
 3、当收到link = sobot://openlocation?latitude=xx&longitude=xxx&address=xxx 可根据自己情况处理相关业务
】
 *
 **/
@property (nonatomic,assign) BOOL canSendLocation;


/// 聊天页面底部加号中功能：隐藏评价，默认NO(不隐藏)
@property (nonatomic,assign) BOOL hideMenuSatisfaction;


/// 聊天页面底部加号中功能：隐藏留言，默认NO(不隐藏)
@property (nonatomic,assign) BOOL hideMenuLeave;

/// 聊天页面底部加号中功能：隐藏图片，默认NO(不隐藏)
@property (nonatomic,assign) BOOL hideMenuPicture;

/// 聊天页面底部加号中功能：隐藏拍摄，默认NO(不隐藏)
@property (nonatomic,assign) BOOL hideMenuCamera;


/// 聊天页面底部加号中功能：隐藏文件，默认NO(不隐藏)
@property (nonatomic,assign) BOOL hideMenuFile;



/**
 *
 *   导航栏右上角 是否显示 评价按钮  默认不显示
 *
 **/
@property (nonatomic,assign) BOOL isShowEvaluation;


/**
 *
 *   是否关闭询前表单（默认为NO，使用系统默认配置）
 *
 **/
@property (nonatomic,assign) BOOL isCloseInquiryForm;

/**
 *
 *   针对关闭按钮，单独设置是否显示评价界面，默认不显示
 *
 **/
@property (nonatomic,assign) BOOL isShowCloseSatisfaction;

/**
 *
 *   导航栏右上角 是否显示 拨号按钮 默认不显示    注意：和isShowEvaluation 互斥 只能设置一个有效
 *
 **/
@property (nonatomic,assign) BOOL isShowTelIcon;


/**
 *
 *   导航栏左上角 是否显示 关闭按钮 默认不显示，关闭按钮，点击后无法监听后台消息
 *
 **/
@property (nonatomic,assign) BOOL isShowClose;

/**
 *  设置电话号码
 *  当导航栏右上角 显示 拨号按钮时  （和isShowTelIcon 一起设置有效）
 *
 **/
@property (nonatomic,copy) NSString * customTel;


////////////////////////////////////////////////////////////////
//   和UI相关的配置参数自定义可选项                                //
//                                                            //
////////////////////////////////////////////////////////////////


/**
 *  是否使用Images
 *  默认为NO 未开启
 *
 */
@property (nonatomic,assign) BOOL      isUseImagesxcassets;

/**
 *  评价完人工是否关闭会话（人工满意度评价后释放会话）
 *  默认为NO 未开启
 *
 */
@property (nonatomic,assign) BOOL      isCloseAfterEvaluation;

/**
 *  返回时是否开启满意度评价
 *  默认为NO 未开启
 *
 */
@property (nonatomic,assign) BOOL      isOpenEvaluation;

/**
 *  自定义关闭的时候是否推送满意度评价
 *  默认为N0;
 *
 */
//@property (nonatomic,assign) BOOL    isShowEvaluate;

/**
 *  机器人优先模式，是否直接显示转人工按钮(值为NO时，会在机器人无法回答时显示转人工按钮)，默认，YES
 */
@property (nonatomic,assign) BOOL    isShowTansfer;

/**
 *  机器人优先模式，通过记录机器人未知说辞的次数设置是否直接显示转人工按钮
 *  默认 0次。
 */
@property (nonatomic,strong) NSString *unWordsCount;



/**
 *  是否开启智能转人工,(如输入“转人工”，直接转接人工)
 * 需要隐藏转人工按钮，请参见isShowTansfer和unWordsCount属性
 */
@property (nonatomic,assign) BOOL  isOpenActiveUser;

/**
 智能转人工关键字，关键字作为key{@"转人工",@"1",@"R":@"1"}
 */
@property (nonatomic,strong) NSDictionary *activeKeywords;


/**
 *  自定义快捷入口
 *  填充内容为： NSDictionary
 *  url: 快捷入口链接(点击后会调用初始化linkBock)
 *  title: 按钮标题
 *  lableId: 自定义快捷入口的ID
 *
 **/
@property (nonatomic,strong) NSMutableArray * cusMenuArray;



/**
 * 自定义输入框下方更多(+号图标)按钮下面内容(不会替换原有内容，会在原有基础上追加)
 * 修改人工模式的按钮
 * 填充内容为：ZCLibCusMenu.h
 *  title:按钮名称
 *  url：点击链接(点击后会调用初始化linkBock)
 *  imgName:本地图片名称，如xxx@2x.png,icon=xxx
 */
@property (nonatomic,strong) NSMutableArray * cusMoreArray;

/**
 * 自定义输入框下方更多(+号图标)按钮下面内容(不会替换原有内容，会在原有基础上追加)
 * 修改机器人模式的按钮
 * 填充内容为：ZCLibCusMenu.h
 *  title:按钮名称
 *  url：点击链接(点击后会调用初始化linkBock)
 *  imgName:本地图片名称，如xxx@2x.png,icon=xxx
 */
@property (nonatomic,strong) NSMutableArray * cusRobotMoreArray;

/**
 *  是否开启语音功能
 *  默认开启
 */
@property (nonatomic,assign) BOOL    isOpenRecord;


/**
 是否开启机器人语音，（付费，否则语音无法识别）
 默认NO
 */
@property (nonatomic,assign) BOOL    isOpenRobotVoice;




////////////////////////////////////////////////////////////////
// 自定义咨询内容，在转接人工成功时，方便用户发送自己咨询的信息，（可选）
// 标题（必填）、页面地址url（必填）、摘要、标签、缩略图url
////////////////////////////////////////////////////////////////

/**
 *
 *   商品卡片信息是否自动发送（转人工成功时，自动发送商品卡片信息）
 *   默认不发送
 **/
@property (nonatomic,assign) BOOL isSendInfoCard;
/**
 *  产品信息
 */
@property(nonatomic,strong) ZCProductInfo *productInfo;



/*
 需要发送的订单信息
 */
@property(nonatomic,strong) ZCOrderGoodsModel *orderGoodsInfo;


/// 人工后，是否主动发送一条信息
@property(nonatomic,assign) BOOL autoSendOrderMessage;





////////////////////////////////////////////////////////////////
// 自定义字体，（可选）
////////////////////////////////////////////////////////////////

/**
 *  顶部标题颜色、评价标题
 */
@property (nonatomic,strong) UIFont    *titleFont;

/**
 *  副标题字体
 */
@property (nonatomic,strong) UIFont    *subTitleFont;

/**
 *  页面返回按钮，输入框，评价提交按钮、Toast提示语  2.8.0 已弃用
 */
@property (nonatomic,strong) UIFont    *listTitleFont;

/**
 *  各种按钮，网络提醒
 */
@property (nonatomic,strong) UIFont    *listDetailFont;

/**
 *  是否有以下情况 2.8.0 已弃用
 */
@property (nonatomic,strong) UIFont    *customlistDetailFont;

/**
 *  消息提醒(转人工、客服接待等)
 */
@property (nonatomic,strong) UIFont    *listTimeFont;

/**
 *  聊天气泡中文字
 */
@property (nonatomic,strong) UIFont    *chatFont;

/**
 *  录音按钮的文字
 */
@property (nonatomic,strong) UIFont    *voiceButtonFont;


/**
 *   商品详情cell 中title的文字
 *
 */
@property (nonatomic,strong) UIFont   *goodsTitleFont;

/**
 *   商品详情cell中 摘要的文字
 *
 */
@property (nonatomic,strong) UIFont   *goodsDetFont;

/**
 *    商品详情cell中 btn的背景色
 *
 */
@property (nonatomic,strong) UIColor    *goodSendBtnColor;


/**
 *
 * 网络状态中的背景色（连接中） （已弃用）
 *  @deprecated 2018-07-31: Use customBannerColor  instead
 *
 */
//@property (nonatomic,strong) UIColor    *socketStatusButtonBgColor;


/**
 *
 * 网络状态中的背景色（连接中） （已弃用）
 *  @deprecated 2018-07-31: Use customBannerColor  instead
 *
 */
//@property (nonatomic,strong) UIColor    *socketStatusButtonTitleColor;


/**
 *  满意度星级说明的文字颜色
 */
@property (nonatomic,strong) UIColor    *scoreExplainTextColor;


////////////////////////////////////////////////////////////////
// 自定义背景、边框线颜色，（可选）
////////////////////////////////////////////////////////////////

/**
 *  对话页面背景
 */
@property (nonatomic,strong) UIColor    *backgroundColor;




/**
 *  自定义风格颜色：导航
 */
@property (nonatomic,strong) UIColor    *customBannerColor;


/**
 *  机器人的问答中 提示转人工按钮的文字颜色
 *
 */
@property (nonatomic,strong) UIColor    *trunServerBtnColor;

/**
 *  相册导航栏的颜色
 *
 */
@property (nonatomic,strong) UIColor   *imagePickerColor;

/**
 *  相册导航栏的标题颜色
 *
 */
@property (nonatomic,strong) UIColor  *imagePickerTitleColor;


/**
 *  左边聊天气泡颜色
 */
@property (nonatomic,strong) UIColor    *leftChatColor;

/**
 *  右边聊天气泡颜色
 */
@property (nonatomic,strong) UIColor    *rightChatColor;

/**
 *  左边聊天气泡复制选中的背景颜色
 */
@property (nonatomic,strong) UIColor    *leftChatSelectedColor;

/**
 *  右边聊天气泡复制选中的背景颜色
 */
@property (nonatomic,strong) UIColor    *rightChatSelectedColor;



/**
 *  输入框字体颜色
 */
@property (nonatomic,strong) UIColor    *chatTextViewColor;


/**
 *  底部bottom的背景颜色
 */
@property (nonatomic,strong) UIColor    *backgroundBottomColor;


/**
 *  底部bottom框边框线颜色(输入框、录音按钮、分割线)
 */
@property (nonatomic,strong) UIColor    *bottomLineColor;

/**
 *  评价普通按钮选中背景颜色和边框(默认跟随主题色customBannerColor)  2.8.0 已移除
 */
@property (nonatomic,strong) UIColor    *commentOtherButtonBgColor;

/**
 *  评价(立即结束、取消)按钮文字颜色(默认跟随主题色customBannerColor)
 */
@property (nonatomic,strong) UIColor    *commentCommitButtonColor;

/**
 *  评价弹出页面 按钮文字颜色(默认跟随主题色customBannerColor)
 */
@property (nonatomic,strong) UIColor    *commentButtonTextColor;

/**
 *  评价弹出页面 按钮选中颜色(默认跟随主题色customBannerColor)
 */
@property (nonatomic,strong) UIColor    *commentButtonBgColor;


/**
 * 评价提交按钮背景颜色和边框(默认跟随主题色customBannerColor)
 */
@property (nonatomic,strong) UIColor    *commentCommitButtonBgColor;

/**
 *  评价提交按钮点击后背景色，默认0x089899, 0.95
 */
@property (nonatomic,strong) UIColor    *commentCommitButtonBgHighColor;


/**
 *  提示气泡的背景颜色
 */
@property (nonatomic,strong) UIColor    *BgTipAirBubblesColor;

/**
 * 语音cell选中的背景色  2.8.0 已移除
 *
 */
@property (nonatomic,strong) UIColor    *videoCellBgSelColor;

/**
 *
 *  富文本中的线条颜色 2.8.0 已移除
 *
 */
@property (nonatomic,strong) UIColor    *LineRichColor;

/**
 *
 *  通告栏的背景色
 *
 */
@property (nonatomic,strong) UIColor    *notificationTopViewBgColor;

/**
 *
 *  通告栏的文字颜色
 *
 */
@property (nonatomic,strong) UIColor    *notificationTopViewLabelColor;

/**
 *
 *  通告栏的字体设置
 *
 */
@property (nonatomic,strong) UIFont    *notificationTopViewLabelFont;





////////////////////////////////////////////////////////////////
// 自定义文字颜色，（可选）
////////////////////////////////////////////////////////////////

/**
 *  提价评价按钮的文字颜色
 */
@property (nonatomic,strong) UIColor    *submitEvaluationColor;

/**
 *  顶部文字颜色
 */
@property (nonatomic,strong) UIColor    *topViewTextColor;

/**
 *  左边气泡文字颜色
 */
@property (nonatomic,strong) UIColor    *leftChatTextColor;


/**
 *  右边气泡文字颜色
 */
@property (nonatomic,strong) UIColor    *rightChatTextColor;

/**
 *  时间文字的颜色
 */
@property (nonatomic,strong) UIColor    *timeTextColor;

/**
 *  提示气泡文字颜色
 */
@property (nonatomic,strong) UIColor    *tipLayerTextColor;

/**
 *  客服昵称颜色  2.8.0 弃用
 */
@property (nonatomic,strong) UIColor    *serviceNameTextColor;

/**
 *  提示cell中客服昵称的文字颜色 2.8.0 弃用
 */
@property (nonatomic,strong) UIColor    *nickNameTextColor;


/**
 *  左边气泡中的链接颜色
 */
@property (nonatomic,strong) UIColor   *chatLeftLinkColor;


/**
 *  右边气泡中的链接颜色
 */
@property(nonatomic,strong) UIColor    *chatRightLinkColor;


/**
 *  商品详情cell中title的文字颜色
 *
 */
@property (nonatomic, strong) UIColor   *goodsTitleTextColor;

/**
 *  商品详情cell中摘要的文字颜色
 *
 */
@property (nonatomic, strong) UIColor   *goodsDetTextColor;

/**
 *  商品详情cell中标签的文字颜色
 *
 */
@property (nonatomic ,strong) UIColor   *goodsTipTextColor;

/**
 *  商品详情cell中发送的文字颜色
 *
 */
@property (nonatomic, strong) UIColor   *goodsSendTextColor;

/**
 *  提交评价后将结束会话的文字颜色
 *
 */
@property (nonatomic, strong) UIColor   *satisfactionTextColor;


/**
 *  暂不评价文字颜色
 *
 */
@property (nonatomic, strong) UIColor   *noSatisfactionTextColor;


/**
 *  评价页面中 已解决 未解决  文字的高亮状态颜色
 *
 */
@property (nonatomic, strong) UIColor   *satisfactionTextSelectedColor;


/**
 *  评价页面中 已解决 未解决 按钮的选中的背景色
 *
 */
@property (nonatomic, strong) UIColor   *satisfactionSelectedBgColor;



/**
 *  是否设置相册背景图片
 */
@property (nonatomic ,assign) BOOL    isSetPhotoLibraryBgImage;


/**
 *  多轮会话模板四的超链颜色
 */
@property (nonatomic,strong) UIColor   *chatLeftMultColor;


/**
 *  多轮会话中 展开和收起的文字颜色
 */
@property (nonatomic,strong) UIColor * openMoreBtnTextColor;

/**
 *
 *  更多按钮默认图片
 *
 **/
@property (nonatomic,copy) NSString * moreBtnNolImg;

/**
 *
 *  更多按钮选中图片
 *
 **/
@property (nonatomic,copy) NSString * moreBtnSelImg;

/**
 *
 *  转人工按钮默认图片
 *
 **/
@property (nonatomic,copy) NSString * turnBtnNolImg;

/**
 *
 *  转人工按选中图片
 *
 **/
@property (nonatomic,copy) NSString * turnBtnSelImg;

/**
 *
 *  返回按钮默认图片
 *
 **/
@property (nonatomic,copy) NSString * topBackNolImg;

/**
 *
 *  返回按钮选中图片
 *
 **/
@property (nonatomic,copy) NSString * topBackSelImg;

/**
 *
 *  返回按钮的默认背景色 2.8.0 已移除
 *
 **/
@property (nonatomic,strong) UIColor * topBackNolColor;

/**
 *
 *  返回按钮的高亮背景色  2.8.0 已移除
 *
 **/
@property (nonatomic,strong) UIColor * topBackSelColor;

/**
 *
 *  导航栏背景色 （单独修改）
 *
 **/
@property (nonatomic,strong) UIColor * topViewBgColor;



/**
 *
 *  顶踩 文字 默认颜色
 *
 **/
@property (nonatomic,strong) UIColor * topBtnNolColor;

/**
 *
 *  顶踩 文字 选中颜色
 *
 **/
@property (nonatomic,strong) UIColor * topBtnSelColor;

/**
 *
 *  顶踩 文字 置灰颜色
 *
 **/
@property (nonatomic,strong) UIColor * topBtnGreyColor;

/**
 *
 *   聊天页面 左上角 返回按钮的文字 （默认 返回）
 *
 **/
@property (nonatomic,copy) NSString * topBackTitle;




/****************   2.7.4  新增  ****************/

/**
 *
 *  留言页面中 提交按钮的文字颜色
 *
 **/
@property (nonatomic,strong) UIColor * leaveSubmitBtnTextColor;



/**
 *
 *  留言页面中 提交按钮的背景颜色
 *
 **/
@property (nonatomic,strong) UIColor * leaveSubmitBtnImgColor;

//**********************     帮助中心       ***************/
/**
 *
 * 帮助中心 标题的文字颜色
 *
 **/
@property (nonatomic,strong) UIColor * scTopTextColor;

/**
 *
 *  帮助中心 标题font
 *
 **/
@property (nonatomic,strong) UIFont * scTopTextFont;


/**
 *
 *  帮助中心 导航条背景色
 *
 **/
@property (nonatomic,strong) UIColor * scTopBgColor;

/**
 *
 * 帮助中心 顶部返回的文字颜色
 *
 **/
@property (nonatomic,strong) UIColor * scTopBackTextColor;

/**
 *
 *  帮助中心 顶部返回按钮的文字字号
 *
 **/
@property (nonatomic,strong) UIFont * scTopBackTextFont;

//**********************     帮助中心    end   ***************/


// 2.8.0
/**
 *
 * 文件查看，ImgProgress 图片背景颜色
 *
 **/
@property (nonatomic,strong) UIColor * documentLookImgProgressColor;

/**
 *
 * 文件查看，按钮 背景颜色
 *
 **/
@property (nonatomic,strong) UIColor * documentBtnDownColor;

/**
 自定义留言内容预置文案，如果需要国际化，可自行在bundle文件中，以文案为key，翻译即可
 例如："请输入内容"="Please enter content";
 */
@property (nonatomic,strong) NSString *leaveContentPlaceholder;

/**
 自定义留言引导语，如果需要国际化，可自行在bundle文件中，以文案为key，翻译即可
 例如："无法解答你的问题，你可以留言"="Please leave";
 */
@property (nonatomic,strong) NSString *leaveMsgGuideContent;

/**
 *  直接进入留言自定义字段
 *  数组，可以以传递多个，临时方案，后期将废弃此字段
 *  id: 自定义字段的id
 *  value: 想传递的数据
 *  @{@"id":@"",@"value":@"我是数据"}
 *
 **/
@property (nonatomic,strong) NSMutableArray * leaveCusFieldArray;


/**
 留言技能组 id
 获取：设置 —>工单技能组设置
*/
@property (nonatomic,strong) NSString * leaveMsgGroupId;

@end
