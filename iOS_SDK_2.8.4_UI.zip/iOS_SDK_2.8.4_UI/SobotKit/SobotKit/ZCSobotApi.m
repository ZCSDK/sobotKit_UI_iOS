//
//  ZCSobotApi.m
//  SobotKit
//
//  Created by xuhan on 2020/1/17.
//  Copyright © 2020 zhichi. All rights reserved.
//

#import "ZCSobotApi.h"

//#import "ZCLibClient.h"
#import "ZCLogUtils.h"

#import "ZCPlatformTools.h"
#import "ZCUICore.h"

#import "ZCServiceCentreVC.h"
#import "ZCLocalStore.h"
#import "UIDeviceTools.h"
#import "ZCMsgDetailsVC.h"
#import "ZCIMChat.h"

@implementation ZCSobotApi

//  打开会话页面
+ (void)openZCChat:(ZCKitInfo *) info
            with:(UIViewController *) byController
          target:(id<ZCChatControllerDelegate>) delegate
       pageBlock:(void (^)(id object,ZCPageBlockType type))pageClick
    messageLinkClick:(BOOL (^)(NSString *link)) messagelinkBlock{
    
     if(byController==nil){
         
         return;
     }
     if(info == nil){
         return;
     }
     
     if ([@"" isEqualToString:zcLibConvertToString([ZCLibClient getZCLibClient].libInitInfo.app_key)] && [@"" isEqualToString:zcLibConvertToString([ZCLibClient getZCLibClient].libInitInfo.customer_code)]) {
         return;
     }
    
     if ([ZCUICore getUICore].LinkClickBlock == nil) {
         [[ZCUICore getUICore] setLinkClickBlock:messagelinkBlock];
     }
     
     [[ZCUICore getUICore] setPageLoadBlock:pageClick];
     
     ZCChatController *chat=[[ZCChatController alloc] initWithInitInfo:info];
     chat.chatdelegate = delegate;
     chat.hidesBottomBarWhenPushed = [ZCUICore getUICore].kitInfo.ishidesBottomBarWhenPushed;
     
     if(byController.navigationController==nil){
         chat.isPush = NO;
         UINavigationController * navc = [[UINavigationController alloc]initWithRootViewController: chat];
         navc.modalPresentationStyle = UIModalPresentationOverFullScreen;
         // 设置动画效果
         [byController presentViewController:navc animated:YES completion:^{

         }];
     }else{
         chat.isPush = YES;
         [byController.navigationController pushViewController:chat animated:YES];
     }
     
     //清理过期日志 v2.7.9
     [ZCLogUtils cleanCache];
    
}

+(void)setMessageLinkClick:(BOOL (^)(NSString * _Nonnull))messagelinkBlock{
    [[ZCUICore getUICore] setLinkClickBlock:messagelinkBlock];
}

// 打开客户中心页面
+ (void)openZCServiceCenter:(ZCKitInfo *) info
                         with:(UIViewController *) byController
                  onItemClick:(void (^)(ZCUIBaseController *object))itemClickBlock {
    
    if(byController==nil){
            return;
        }
        if(info == nil){
            return;
        }
        
        if ([@"" isEqualToString:zcLibConvertToString([ZCLibClient getZCLibClient].libInitInfo.app_key)] && [@"" isEqualToString:zcLibConvertToString([ZCLibClient getZCLibClient].libInitInfo.customer_code)]) {
            return;
        }
        
        ZCServiceCentreVC *chat=[[ZCServiceCentreVC alloc] initWithInitInfo:info];
        [chat setOpenApiZCSDKTypeBlock:itemClickBlock];
        chat.hidesBottomBarWhenPushed = [ZCUICore getUICore].kitInfo.ishidesBottomBarWhenPushed;
        chat.kitInfo = info;
        if(byController.navigationController==nil){
            chat.isPush = NO;
            UINavigationController * navc = [[UINavigationController alloc]initWithRootViewController: chat];
            navc.modalPresentationStyle = UIModalPresentationOverFullScreen;
            // 设置动画效果
            [byController presentViewController:navc animated:YES completion:^{
                
            }];
        }else{
            chat.isPush = YES;
            [byController.navigationController pushViewController:chat animated:YES];
        }
    
}

// 打开消息中心页面
+ (void)openZCChatListView:(ZCKitInfo *)info with:(UIViewController *)byController onItemClick:(void (^)(ZCUIChatListController *object,ZCPlatformInfo *info))itemClickBlock {
    
    if(byController==nil){
        return;
    }
    if(info == nil){
        return;
    }
    ZCUIChatListController *chat=[[ZCUIChatListController alloc] init];
    chat.hidesBottomBarWhenPushed = [ZCUICore getUICore].kitInfo.ishidesBottomBarWhenPushed;
    chat.kitInfo = info;
    [chat setOnItemClickBlock:itemClickBlock];
    chat.byController = byController;
    if(byController.navigationController==nil){
          UINavigationController * navc = [[UINavigationController alloc]initWithRootViewController:chat];
              // 设置动画效果
              navc.modalPresentationStyle = UIModalPresentationOverFullScreen;
        [byController presentViewController:chat animated:YES completion:^{
            
        }];
    }else{
        [byController.navigationController pushViewController:chat animated:YES];
    }
    
}

// 打开留言页面
+ (void)openLeave:(int ) showRecored kitinfo:(ZCKitInfo *)kitInfo with:(UIViewController *)byController onItemClick:(void (^)(NSString *msg,int code))CloseBlock {
    
    [ZCUICore getUICore].kitInfo = kitInfo;

    [ZCSobotApi checkConfig:^(NSString *msg, int code) {
        if(code == 0){

            ZCUILeaveMessageController *leaveMessageVC = [[ZCUILeaveMessageController alloc]init];
            leaveMessageVC.hidesBottomBarWhenPushed = YES;
            leaveMessageVC.exitType = 2;
        //    leaveMessageVC.isShowToat = isShow;
        //    leaveMessageVC.tipMsg = msg;
            leaveMessageVC.isNavOpen = (byController.navigationController!=nil ? YES: NO);
            leaveMessageVC.ticketShowFlag = 1;

            ZCLibConfig *config = [[ZCPlatformTools sharedInstance] getPlatformInfo].config;
            leaveMessageVC.enclosureShowFlag = config.enclosureShowFlag;
            leaveMessageVC.enclosureFlag = config.enclosureFlag;
            leaveMessageVC.telFlag = config.telFlag;
            leaveMessageVC.emailFlag = config.emailFlag;
            leaveMessageVC.telShowFlag = config.telShowFlag;
            leaveMessageVC.emailShowFlag =  config.emailShowFlag;
            leaveMessageVC.msgTmp =  config.msgTmp;
            leaveMessageVC.msgTxt = config.msgTxt;
            
            [leaveMessageVC setCloseBlock:^{
                if(CloseBlock){
                    CloseBlock(@"关闭留言页面",0);
                }
            }];

            if(showRecored > 0){
                // 直接跳转到 留言记录、
                leaveMessageVC.selectedType = 2;
                leaveMessageVC.ticketShowFlag  = (showRecored == 1)?0:1;
            }

            if(byController.navigationController==nil){
                UINavigationController * navc = [[UINavigationController alloc]initWithRootViewController: leaveMessageVC];
                // 设置动画效果
                navc.modalPresentationStyle = UIModalPresentationOverFullScreen;
                [byController presentViewController:navc animated:YES completion:^{

                }];
            }else{
                [byController.navigationController pushViewController:leaveMessageVC animated:YES];
            }
        }else{
            if(CloseBlock){
                CloseBlock(msg,code);
            }
        }
    }];
    
}

+(void)openRecordDetail:(NSString *)ticketId viewController:(UIViewController *) byController{
    ZCMsgDetailsVC * detailVC = [[ZCMsgDetailsVC alloc]init];
    detailVC.ticketId = zcLibConvertToString(ticketId);
    detailVC.companyId = [ZCSobotApi getCommanyId];
    if (byController.navigationController!= nil) {
        [byController.navigationController pushViewController:detailVC animated:YES];
    }else{

        UINavigationController * navc = [[UINavigationController alloc]initWithRootViewController: detailVC];
        // 设置动画效果
        navc.modalPresentationStyle = UIModalPresentationOverFullScreen;
        [byController presentViewController:navc animated:YES completion:^{
            
        }];
    }
}

+(NSString *)getCommanyId{
    return [ZCLocalStore getLocalParamter:@"ZCKEY_COMPANYID"];
}

// 发送位置
+ (void)sendLocation:(NSDictionary *) locations resultBlock:(nonnull void (^)(NSString * _Nonnull, int))ResultBlock{
    if([[ZCUICore getUICore] getLibConfig].isArtificial){
        [[ZCUICore getUICore] sendMessage:locations[@"file"] questionId:@"" type:ZCMessageTypeLocation duration:@"" dict:locations];
        if(ResultBlock){
            ResultBlock(@"执行了接口调用",0);
        }
    }else{
        if(ResultBlock){
            ResultBlock(@"当前是不是人工客服状态，不能给人工发送消息",1);
        }
    }
}

// 发送文字消息
+ (void)sendTextToUser:(NSString *)textMsg resultBlock:(nonnull void (^)(NSString * _Nonnull, int))ResultBlock{
    if([[ZCUICore getUICore] getLibConfig].isArtificial){
        [[ZCUICore getUICore] sendMessage:textMsg questionId:@"" type:ZCMessageTypeText duration:@"" dict:nil];
        if(ResultBlock){
            ResultBlock(@"执行了接口调用",0);
        }
    }else{
        if(ResultBlock){
               ResultBlock(@"当前是不是人工客服状态，不能给人工发送消息",1);
        }
    }
   
}

// 发送订单卡片
+ (void)sendOrderGoodsInfo:(ZCOrderGoodsModel *)orderGoodsInfo resultBlock:(nonnull void (^)(NSString * _Nonnull, int))ResultBlock{
    
    if(orderGoodsInfo){

        NSMutableDictionary * contentDic = [NSMutableDictionary dictionaryWithCapacity:5];
        NSString *contextStr = @"";
        [contentDic setObject:[NSString stringWithFormat:@"%d",orderGoodsInfo.orderStatus] forKey:@"orderStatus"];
        [contentDic setObject:zcLibConvertToString(orderGoodsInfo.createTime) forKey:@"createTime"];
        [contentDic setObject:zcLibConvertToString(orderGoodsInfo.orderCode) forKey:@"orderCode"];
        [contentDic setObject:zcLibConvertToString(orderGoodsInfo.createTime) forKey:@"createTime"];
        [contentDic setObject:orderGoodsInfo.goods forKey:@"goods"];
        [contentDic setObject:zcLibConvertToString(orderGoodsInfo.orderUrl) forKey:@"orderUrl"];
        [contentDic setObject:zcLibConvertToString(orderGoodsInfo.goodsCount) forKey:@"goodsCount"];
        [contentDic setObject:zcLibConvertToString(orderGoodsInfo.totalFee) forKey:@"totalFee"];
        // 转json
        contextStr = [ZCLocalStore DataTOjsonString:contentDic];
        
        // 仅人工时才可以发送
        if([[ZCUICore getUICore] getLibConfig].isArtificial){
            [[ZCUICore getUICore] sendMessage:contextStr questionId:@"" type:ZCMessageTypeOrder duration:@"" dict:nil];
            if(ResultBlock){
                ResultBlock(@"执行了接口调用",0);
            }
        }else{
            if(ResultBlock){
                   ResultBlock(@"当前是不是人工客服状态，不能给人工发送消息",1);
            }
        }
        
        
    }
    
}

// 发送商品卡片
+ (void)sendProductInfo:(ZCProductInfo *)productInfo resultBlock:(nonnull void (^)(NSString * _Nonnull, int))ResultBlock{
    
    if(productInfo){
        
        NSMutableDictionary * contentDic = [NSMutableDictionary dictionaryWithCapacity:5];
        NSString *contextStr = @"";
        [contentDic setObject:[NSString stringWithFormat:@"%@",zcLibConvertToString(productInfo.title)] forKey:@"title"];
        
        [contentDic setObject:[NSString stringWithFormat:@"%@",zcLibConvertToString(productInfo.desc)] forKey:@"description"];
        
        [contentDic setObject:[NSString stringWithFormat:@"%@",zcLibConvertToString(productInfo.label)] forKey:@"label"];
        
        [contentDic setObject:[NSString stringWithFormat:@"%@",zcLibConvertToString(productInfo.link)] forKey:@"url"];
        
        [contentDic setObject:[NSString stringWithFormat:@"%@",zcLibConvertToString(productInfo.thumbUrl)] forKey:@"thumbnail"];
        // 转json
        contextStr = [ZCLocalStore DataTOjsonString:contentDic];
        
        // 仅人工时才可以发送
        if([[ZCUICore getUICore] getLibConfig].isArtificial){
            [[ZCUICore getUICore] sendMessage:contextStr questionId:@"" type:ZCMessageTypeCard duration:@""];
            if(ResultBlock){
                ResultBlock(@"执行了接口调用",0);
            }
        }else{
            if(ResultBlock){
                   ResultBlock(@"当前是不是人工客服状态，不能给人工发送消息",1);
            }
        }
        
    }
    
}

// 给机器人发送消息
+ (void)sendTextToRobot:(NSString *)textMsg{
    [[ZCUICore getUICore]  sendMessage:textMsg questionId:@"" type:ZCMessageTypeText duration:@"" dict:nil];
}

// 同步用户信息
+ (void)synchronizationInitInfoToSDK:(void (^)(NSString *msg,int code))ResultBlock {
    if ([@"" isEqualToString:zcLibConvertToString([ZCLibClient getZCLibClient].libInitInfo.app_key)] && [@"" isEqualToString:zcLibConvertToString([ZCLibClient getZCLibClient].libInitInfo.customer_code)]) {
        if(ResultBlock){
            ResultBlock(@"appkey不能为空",1);
        }
        return;
    }
    ZCKitInfo *kitInfo = [ZCUICore getUICore].kitInfo;
    if (!kitInfo) {
        kitInfo = [ZCKitInfo new];
    }
    
    
    [[ZCUICore getUICore] openSDKWith:[ZCLibClient getZCLibClient].libInitInfo uiInfo:kitInfo Delegate:nil blcok:^(ZCInitStatus code, NSMutableArray *arr, NSString *result) {
        if(code == ZCInitStatusLoadSuc){
            if(ResultBlock){
                ResultBlock(@"Success",0);
            }
        }else{
            if(ResultBlock){
                ResultBlock(result,1);
            }
        }
    }];
    
}

// 转人工自定义
+ (void)connectCustomerService:(NSString *)groupId  Obj:(id)obj KitInfo:(ZCKitInfo*)uiInfo ZCTurnType:(NSInteger)turnType Keyword:(NSString*)keyword KeywordId:(NSString*)keywordId {
    [[ZCUICore getUICore] customTurnServiceWithGroupId:groupId Obj:obj KitInfo:uiInfo ZCTurnType:turnType Keyword:keyword KeywordId:keywordId];
}

+(void)getLastLeaveReplyMessage:(NSString *)partnerid resultBlock:(void (^)(NSDictionary * , NSMutableArray * , int))ResultBlock{
    if(zcLibConvertToString(partnerid).length == 0){
        partnerid = [ZCSobotApi getUserUUID];
    }
    NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
    [params setObject:zcLibConvertToString([ZCSobotApi getCommanyId]) forKey:@"companyId"];
    [params setObject:zcLibConvertToString(partnerid) forKey:@"partnerId"];
    [[[ZCUICore getUICore] getAPIServer] getLastReplyLeaveMessage:params start:^{
        
    } success:^(NSDictionary *dict, NSMutableArray *itemArray, ZCNetWorkCode sendCode) {
        ResultBlock(dict,itemArray,(int)sendCode);
        
    } failed:^(NSString *errorMessage, ZCNetWorkCode errorCode) {
        ResultBlock(nil,nil,(int)errorCode);
    }];
}

+(void)postLocalNotification:(NSString *)message dict:(NSDictionary *)userInfo{
    [[ZCIMChat getZCIMChat] postLocalNotification:message dict:userInfo];
}

// 获取 SDK 版本号
+ (NSString *)getVersion {
   return  zcGetSDKVersion();
}

// 获取渠道信息
+ (NSString *)getChannel {
   return zcGetAppChannel();
}

// 显示日志信息 默认不显示
+ (void)setShowDebug:(BOOL)isShowDebug {
    [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%d",isShowDebug] forKey:ZCKey_ISDEBUG];
}

//
+ (NSString *)getSystem {
   return zcGetSystemVersion();
}

// 获取当前app的版本号
+ (NSString *)getAppVersion {
   return zcGetAppVersion();
}

// 获取手机型号
+ (NSString *)getIPhoneType {
   return zcGetIphoneType();
}

// 获取当前集成的app名称
+ (NSString *)getAppName {
   return zcGetAppName();
}

// 获取用户的 UUID
+ (NSString *)getUserUUID {
    
    return [[UIDeviceTools shareDeviceTools] getIOSUUID];
}

// 添加异常统计
+ (void)setZCLibUncaughtExceptionHandler {
    [ZCLibClient setZCLibUncaughtExceptionHandler];
}

// 读取日志文件内容 保存最近的7天
+ (void)readLogFileDateString:(NSString *) dateString {
    [ZCLibClient readLogFileDateString:dateString];
}

+ (void)outCurrentUserZCLibInfo:(BOOL) isClosePush {
    [ZCLibClient closeAndoutZCServer:isClosePush];
}

+ (void)initSobotSDK:(NSString *) appkey result:(void (^)(id object))resultBlock {
    
    [[ZCLibClient getZCLibClient] initSobotSDK:appkey result:resultBlock];
}

// 获取最后一条消息
+ (NSString *)readLastMessage {
    return [[ZCLibClient getZCLibClient] getLastMessage];
}

// 检查当前消息通道是否建立，没有就重新建立
+ (void)checkIMConnected {
    [[ZCLibClient getZCLibClient] checkIMConnected];
}

// 关闭当前消息通道，使其不再接受消息
+ (void)closeIMConnection {
    [[ZCLibClient getZCLibClient] closeIMConnection];

}

// 清空用户下的所有未读消息(本地清空)
+ (void)clearUnReadNumber {
    [[ZCLibClient getZCLibClient] removeIMAllObserver];

}

// 获取未读消息数
+ (int)getUnReadMessage {
   return [[ZCLibClient getZCLibClient] getUnReadMessage];

}

#pragma mark - Private method
+(void)checkConfig:(void (^)(NSString *,int code))ResultBlock{
    if ([@"" isEqualToString:zcLibConvertToString([ZCLibClient getZCLibClient].libInitInfo.app_key)] && [@"" isEqualToString:zcLibConvertToString([ZCLibClient getZCLibClient].libInitInfo.customer_code)]) {
        if(ResultBlock){
            ResultBlock(@"appkey不能为空",1);
        }
        return;
    }
        
    if(([[ZCPlatformTools sharedInstance] getPlatformInfo].config == nil) || ![[ZCLibClient getZCLibClient].libInitInfo.partnerid isEqual:[[ZCPlatformTools sharedInstance] getPlatformInfo].config.zcinitInfo.partnerid]){
        [self backgroundInitSDK:ResultBlock];
    }else{
        if(ResultBlock){
            ResultBlock(@"Success",0);
        }
    }
    
}


+(void)backgroundInitSDK:(void (^)(NSString *,int code))ResultBlock{
    if ([@"" isEqualToString:zcLibConvertToString([ZCLibClient getZCLibClient].libInitInfo.app_key)] && [@"" isEqualToString:zcLibConvertToString([ZCLibClient getZCLibClient].libInitInfo.customer_code)]) {
        if(ResultBlock){
            ResultBlock(@"appkey不能为空",1);
        }
        return;
    }
    ZCKitInfo *kitInfo = [ZCUICore getUICore].kitInfo;
    if (!kitInfo) {
        kitInfo = [ZCKitInfo new];
    }
    
    
    [[ZCUICore getUICore] openSDKWith:[ZCLibClient getZCLibClient].libInitInfo uiInfo:kitInfo Delegate:nil blcok:^(ZCInitStatus code, NSMutableArray *arr, NSString *result) {
        if(code == ZCInitStatusLoadSuc){
            if(ResultBlock){
                ResultBlock(@"Success",0);
            }
        }else{
            if(ResultBlock){
                ResultBlock(result,1);
            }
        }
    }];
}



@end
