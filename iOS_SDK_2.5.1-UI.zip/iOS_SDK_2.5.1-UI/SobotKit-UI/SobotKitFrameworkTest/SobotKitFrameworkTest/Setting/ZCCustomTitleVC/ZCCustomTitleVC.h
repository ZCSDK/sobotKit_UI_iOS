//
//  ZCCustomTitleVC.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCCustomTitleVC : UIViewController


@property (weak, nonatomic) IBOutlet UISwitch *titleDefaultSwitch;

@property (weak, nonatomic) IBOutlet UISwitch *titleEnterpriseSwitch;

@property (weak, nonatomic) IBOutlet UISwitch *titleCustomSwitch;

@property (weak, nonatomic) IBOutlet UITextField *titleCustomTF;

@property (weak, nonatomic) IBOutlet UIScrollView *bgScrollView;
@property (weak, nonatomic) IBOutlet UIView *topLineView;

@property (weak, nonatomic) IBOutlet UIView *midLineView;
@property (weak, nonatomic) IBOutlet UIView *bottomLineView;


@end
