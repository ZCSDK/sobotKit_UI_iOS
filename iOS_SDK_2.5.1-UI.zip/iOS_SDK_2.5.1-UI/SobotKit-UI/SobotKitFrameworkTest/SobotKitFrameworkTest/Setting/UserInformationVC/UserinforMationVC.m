//
//  UserinforMationVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/22.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "UserinforMationVC.h"
#import "ZCSettingCell.h"
#import "ZCDetailVC.h"

#import "ZCDetailTextCell.h"

#define cellSettingIdentifier  @"ZCDetailTextCell"


@interface UserinforMationVC ()<UITableViewDelegate,UITableViewDataSource,ZCDetailTextCellDelegate>{
    NSString * userId ;
    NSString * phone;
    NSString * qqNumber;
    NSString * userSex;
    NSString * email;
    NSString * realName;
    NSString * nickName;
    NSString * weiBo;
    NSString * weChat;
    NSString * userBirthday;
    NSString * userRemark ;
    NSString * avatarUrl;
    
    CGPoint        contentoffset;// 记录cell的相对坐标
}

@property (nonatomic,strong) NSMutableArray * listArray;

@property (nonatomic,strong) UITableView * listTable;

@end

@implementation UserinforMationVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColorFromRGB(0xEFF3FA);
    self.title = @"用户资料";
    _listArray = [NSMutableArray arrayWithCapacity:0];
    
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    [leftBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 0);
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    _listArray = [NSMutableArray arrayWithCapacity:0];
    [self createTabelView];
    [self loadData];
    
}



-(void)backAction:(UIButton*)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)createTabelView{
    _listTable = [[UITableView alloc]initWithFrame:CGRectMake(0, NavBarHeight, ScreenWidth, ScreenHeight - NavBarHeight) style:UITableViewStylePlain];
    _listTable.backgroundColor = [UIColor clearColor];
    _listTable.delegate = self;
    _listTable.dataSource = self;
    [self.view addSubview:_listTable];
    
    [_listTable registerNib:[UINib nibWithNibName:cellSettingIdentifier bundle:nil] forCellReuseIdentifier:cellSettingIdentifier];

    UIView * footView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 100)];
    _listTable.tableFooterView = footView;
    
    UITapGestureRecognizer  * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dismissKeyboard)];
    [footView addGestureRecognizer:tap];
}

-(void)loadData{
    [_listArray removeAllObjects];
  
     userId  = @"";
     phone = @"";
     qqNumber = @"";
     userSex = @"";
     email = @"";
     realName = @"";
     nickName = @"";
     weiBo = @"";
     weChat = @"";
     userBirthday = @"";
     userRemark = @"";
     avatarUrl = @"";
    NSDictionary * customInfo = @{
                                  @"标题1":@"自定义1",
                                  @"内容1":@"我是一个自定义字段。",
                                  @"标题2":@"自定义字段2",
                                  @"内容2":@"我是一个自定义字段，我是一个自定义字段，我是一个自定义字段，我是一个自定义字段。",
                                  @"标题3":@"自定义字段字段3",
                                  @"内容3":@"<a href=\"www.baidu.com\" target=\"_blank\">www.baidu.com</a>",
                                  @"标题4":@"自定义4",
                                  @"内容4":@"我是一个自定义字段 https://www.sobot.com/chat/pc/index.html?sysNum=9379837c87d2475dadd953940f0c3bc8&partnerId=112"
                                  };
    NSDictionary * customerFields = @{@"customField22":@"我是自定义的分校",
                                      @"userSex":@"保密",
                                      @"weixin":@"微信号",
                                      @"weibo":@"微博账号",
                                      @"birthday":@"2017-06-08"};
    
    // 添加默认值
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    if (user != nil) {
        userId = [user valueForKey:@"userID"];
        phone   = [user valueForKey:@"phone"];
        qqNumber       = [user valueForKey:@"qqNumber"];
        userSex     = [user valueForKey:@"userSex"];
        email  = [user valueForKey:@"email"];
        realName     = [user valueForKey:@"realName"];
        nickName     = [user valueForKey:@"nickName"];
        weiBo    = [user valueForKey:@"weiBo"];
        weChat  = [user valueForKey:@"weChat"];
        userBirthday = [user valueForKey:@"userBirthday"];
        avatarUrl   = [user valueForKey:@"avatarUrl"];
        userRemark = [user valueForKey:@"userRemark"];
//        customInfo = [user valueForKey:@"userRemark"];
//        customerFields = [user valueForKey:@"userRemark"];
    }
    
    [_listArray addObject:@{@"code":@"131",
                            @"dictName":@"用户ID:",
                            @"dictDesc":@"userID",
                      @"placeholder":@"请输入用户id",
                      @"dictValue":ConvertToString(userId) ,
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    

    [_listArray addObject:@{@"code":@"132",
                            @"dictName":@"电话:",
                            @"dictDesc":@"phone",
                      @"placeholder":@"请输入用户电话",
                      @"dictValue":ConvertToString(phone),
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    [_listArray addObject:@{@"code":@"133",
                            @"dictName":@"昵称:",
                      @"dictDesc":@"nickName",
                      @"placeholder":@"请输入用户昵称",
                      @"dictValue":ConvertToString(nickName) ,
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    [_listArray addObject:@{@"code":@"134",
                            @"dictName":@"邮箱:",
                      @"dictDesc":@"email",
                      @"placeholder":@"请输入用户邮箱",
                      @"dictValue":ConvertToString(email) ,
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    
    [_listArray addObject:@{@"code":@"135",
                            @"dictName":@"姓名:",
                      @"dictDesc":@"realName",
                      @"placeholder":@"请输入用户姓名",
                      @"dictValue":ConvertToString(realName) ,
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    [_listArray addObject:@{@"code":@"136",
                            @"dictName":@"QQ:",
                      @"dictDesc":@"qqNumber",
                      @"placeholder":@"请输入用户QQ号",
                      @"dictValue":ConvertToString(qqNumber),
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    [_listArray addObject:@{@"code":@"137",
                            @"dictName":@"微信:",
                      @"dictDesc":@"weChat",
                      @"placeholder":@"请输入微信号",
                      @"dictValue":ConvertToString(weChat),
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    [_listArray addObject:@{@"code":@"138",
                            @"dictName":@"微博:",
                      @"dictDesc":@"weiBo",
                      @"placeholder":@"请输入微博号",
                      @"dictValue":ConvertToString(weiBo),
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    [_listArray addObject:@{@"code":@"139",
                            @"dictName":@"用户性别:",
                      @"dictDesc":@"userSex",
                      @"placeholder":@"请输入性别",
                      @"dictValue":ConvertToString(userSex),
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    [_listArray addObject:@{@"code":@"1310",
                            @"dictName":@"用户生日:",
                      @"dictDesc":@"userBirthday",
                      @"placeholder":@"请输入生日",
                      @"dictValue":ConvertToString(userBirthday),
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    [_listArray addObject:@{@"code":@"1311",
                            @"dictName":@"备注:",
                      @"dictDesc":@"userRemark",
                      @"placeholder":@"请填写备注",
                      @"dictValue":ConvertToString(userRemark),
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    [_listArray addObject:@{@"code":@"1312",
                            @"dictName":@"自定义头像:",
                      @"dictDesc":@"avatarUrl",
                      @"placeholder":@"请输入自定义头像URL",
                      @"dictValue":ConvertToString(avatarUrl),
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    
//    [_listArray addObject:@{@"code":@"1313",
//                            @"dictName":@"自定义字段:",
//                      @"dictDesc":@"customInfo",
//                      @"placeholder":@"",
//                      @"dictValue":customInfo,
//                      @"cellType":@"0",
//                      @"propertyType":@"0",
//                      @"contentDict":@{}
//                      }];
//
//    [_listArray addObject:@{@"code":@"1314",
//                            @"dictName":@"自定义字段（固定key）:",
//                      @"dictDesc":@"customerFields",
//                      @"placeholder":@"",
//                      @"dictValue":customerFields,
//                      @"cellType":@"0",
//                      @"propertyType":@"0",
//                      @"contentDict":@{}
//                      }];
    
    [_listTable reloadData];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _listArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ZCDetailTextCell * cell = (ZCDetailTextCell*)[tableView dequeueReusableCellWithIdentifier:cellSettingIdentifier];
    if (cell == nil) {
        cell = [[ZCDetailTextCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellSettingIdentifier];
    }
    NSDictionary * dict = _listArray[indexPath.row];
    cell.delegate = self;
    [cell initWithDict:dict];
//    cell.textValueBlock = ^(NSString *textValue) {
//        NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
//        [user setValue:textValue forKey:dict[@"dictDesc"]];
//    };
    return cell;
}

-(void)textValueChange:(UITextField *)textValue WithDict:(NSDictionary *)dict{
    ZCZCUserDefaultsSetValue(textValue.text, dict[@"dictDesc"]);
    
    // 添加中间变量，处理cell 重用时的 还原问题
    switch ([dict[@"code"] intValue]) {
        case 131:{
            userId = textValue.text;
        }
            
            break;
        case 132:{
            phone = textValue.text;
        }
            
            break;
        case 133:{
            nickName = textValue.text;
        }
            
            break;
        case 134:{
            email = textValue.text;
        }
            
            break;
        case 135:{
            realName = textValue.text;
        }
            
            break;
        case 136:{
            qqNumber = textValue.text;
        }
            
            break;
        case 137:{
            weChat = textValue.text;
        }
            
            break;
        case 138:{
            weiBo = textValue.text;
        }
            
            break;
        case 139:{
            userSex = textValue.text;
        }
            
            break;
        case 1310:{
            userBirthday = textValue.text;
        }
            
            break;
        case 1311:{
            userRemark = textValue.text;
        }
            
            break;
        case 1312:{
            avatarUrl = textValue.text;
        }
            break;
        default:
            break;
    }
    if ([dict[@"code"] intValue]< 140) {
        NSMutableDictionary * Dict  = _listArray[[dict[@"code"] intValue]-131];
        Dict = [NSMutableDictionary dictionaryWithDictionary:dict];
        _listArray[[dict[@"code"] intValue]-131] = Dict;
    }else{
        NSMutableDictionary * Dict  = _listArray[[dict[@"code"] intValue] - 1310 + 9];
        Dict = [NSMutableDictionary dictionaryWithDictionary:dict];
        _listArray[[dict[@"code"] intValue]-1310 +9] = Dict;
    }
    
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];// 取消选中
    
//    NSDictionary * dict = _listArray[indexPath.row];
//    ZCDetailVC * detailVC = [[ZCDetailVC alloc]init];
//    detailVC.titleName = dict[@"dictName"];
//    detailVC.code = dict[@"code"];
//    [self.navigationController pushViewController:detailVC animated:YES];
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [self tableView:tableView cellForRowAtIndexPath:indexPath];
    return cell.frame.size.height;
}



// 处理键盘的代理事件
- (void) markPiontActionWithTextField:(UITextField *)textField{
    
    NSIndexPath *indexpath=[_listTable indexPathForCell:((ZCDetailTextCell *)textField.superview.superview) ];
    
    //获取当前cell在tableview中的位置
    CGRect rectintableview=[_listTable rectForRowAtIndexPath:indexpath];
    
    //获取当前cell在屏幕中的位置
    CGRect rectinsuperview = [_listTable convertRect:rectintableview fromView:[_listTable superview]];
    
    contentoffset.x = _listTable.contentOffset.x;
    
    contentoffset.y = _listTable.contentOffset.y;
    
    if ((rectinsuperview.origin.y+50 - _listTable.contentOffset.y)>200) {
        
        [_listTable setContentOffset:CGPointMake(_listTable.contentOffset.x,((rectintableview.origin.y-_listTable.contentOffset.y)-150)+  _listTable.contentOffset.y) animated:YES];
        
    }
    
}

- (void)changePiontAction:(UITextField*)textField{
    [_listTable setContentOffset:CGPointMake(contentoffset.x,contentoffset.y) animated:YES];
}


NSString *ConvertToString(id object){
    if ([object isKindOfClass:[NSNull class]]) {
        return @"";
    }else if(!object){
        return @"";
    }else if([object isKindOfClass:[NSNumber class]]) {
        return [object stringValue];
    }else{
        return [NSString stringWithFormat:@"%@",object];
    }
}

-(void)dismissKeyboard{
    [_listTable setContentOffset:CGPointMake(contentoffset.x,contentoffset.y) animated:YES];
    [self hideKeyBoard];
}
#pragma mark -- 全局回收键盘
- (void)hideKeyBoard
{
    for (UIWindow* window in [UIApplication sharedApplication].windows)
    {
        for (UIView* view in window.subviews)
        {
            [self dismissAllKeyBoardInView:view];
        }
    }
}

-(BOOL) dismissAllKeyBoardInView:(UIView *)view
{
    if([view isFirstResponder])
    {
        [view resignFirstResponder];
        return YES;
    }
    for(UIView *subView in view.subviews)
    {
        if([self dismissAllKeyBoardInView:subView])
        {
            return YES;
        }
    }
    return NO;
}

@end
