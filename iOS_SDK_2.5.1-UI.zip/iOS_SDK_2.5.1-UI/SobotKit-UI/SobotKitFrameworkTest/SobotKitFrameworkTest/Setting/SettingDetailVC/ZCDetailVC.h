//
//  ZCDetailVC.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/21.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^ZCDetailVCValueTextBlock)();

@interface ZCDetailVC : UIViewController

@property (nonatomic,copy) NSString * code;

@property (nonatomic,copy) NSString * titleName;

@property (nonatomic,strong) ZCKitInfo * kitInfo;

@property (nonatomic,copy) NSString * dictDesc;

@property (nonatomic,copy) NSString * placeholder;

@property (nonatomic,copy) ZCDetailVCValueTextBlock  valueTextBlock;

@end
