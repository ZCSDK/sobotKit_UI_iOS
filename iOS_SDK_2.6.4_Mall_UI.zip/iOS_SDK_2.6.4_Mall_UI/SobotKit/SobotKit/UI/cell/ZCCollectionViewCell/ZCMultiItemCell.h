//
//  ZCMultiItemCell.h
//  SobotKit
//
//  Created by lizhihui on 2017/11/13.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZCChatBaseCell.h"

// 机器人回复的标签类cell 
@interface ZCMultiItemCell : ZCChatBaseCell

@end
