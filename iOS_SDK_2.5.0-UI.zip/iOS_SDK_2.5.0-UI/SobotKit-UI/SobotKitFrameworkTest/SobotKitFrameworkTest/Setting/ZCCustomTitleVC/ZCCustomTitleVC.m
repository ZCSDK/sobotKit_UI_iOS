//
//  ZCCustomTitleVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCCustomTitleVC.h"

@interface ZCCustomTitleVC (){
    NSString * titleType;
}



@end

@implementation ZCCustomTitleVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    titleType = @"0";
    self.bgScrollView.backgroundColor = UIColorFromRGB(0xEFF3FA);
    
    self.topLineView.backgroundColor = UIColorFromRGB(0xdadada);
    self.midLineView.backgroundColor = UIColorFromRGB(0xdadada);
    self.bottomLineView.backgroundColor = UIColorFromRGB(0xdadada);
    
    CGRect topLineViewF = self.topLineView.frame;
    topLineViewF.size.height = 0.5f;
    self.topLineView.frame = topLineViewF;
    
    CGRect midLineF = self.midLineView.frame;
    midLineF.size.height = 0.5f;
    self.midLineView.frame = midLineF;
    
    CGRect bottomLineF = self.bottomLineView.frame;
    bottomLineF.size.height = 0.5f;
    self.bottomLineView.frame = bottomLineF;
    
     [self createNavc];
    [self layoutSubviews];
}

-(void)createNavc{
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"自定义标题";

    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    [leftBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 0);
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    
    UIButton * rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(ScreenWidth - 60, NavBarHeight - 40, 50, 40);
    rightBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [rightBtn setTitle:@"保存" forState:UIControlStateNormal];
    [rightBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    [rightBtn addTarget:self action:@selector(saveAction:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem * rightItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    
    self.navigationItem.rightBarButtonItem = rightItem;
}

-(void)backAction:(UIButton*)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)saveAction:(UIButton *)sender{
    if (_titleCustomSwitch.on && !_titleCustomTF.text.length) {
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"请输入自定义标题" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alertView show];
        return;
    }
//    if (_titleCustomSwitch.on && _titleCustomTF.text.length) {
//        [ZCLibClient getZCLibClient].libInitInfo.customTitle = _titleCustomTF.text;
//    }
    
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setValue:titleType forKey:@"titleType"];
    [userDefaults setValue:_titleCustomTF.text forKey:@"customTitle"];
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)layoutSubviews{
    _titleDefaultSwitch.tag = 201;
    _titleEnterpriseSwitch.tag = 202;
    _titleCustomSwitch.tag = 203;
    [_titleDefaultSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [_titleEnterpriseSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [_titleCustomSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
   // 聊天页顶部标题 的自定义方式 0.默认  1.企业名称  2.自定义字段
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    _titleCustomTF.text = [userDefaults  valueForKey:@"customTitle"];
    if ([userDefaults valueForKey:@"titleType"] ==nil) {
        [userDefaults setValue:@"0" forKey:@"titleType"];
    }

    switch ([[userDefaults valueForKey:@"titleType"] intValue]) {
        case 0:
            _titleDefaultSwitch.on = YES;
            _titleEnterpriseSwitch.on = NO;
            _titleCustomSwitch.on = NO;
            _titleCustomTF.hidden = YES;
            break;
        case 1:
            _titleDefaultSwitch.on = NO;
            _titleEnterpriseSwitch.on = YES;
            _titleCustomSwitch.on = NO;
            _titleCustomTF.hidden = YES;
            break;
        case 2:
            _titleDefaultSwitch.on = NO;
            _titleEnterpriseSwitch.on = NO;
            _titleCustomSwitch.on = YES;
            _titleCustomTF.hidden = NO;
            _titleCustomTF.text = [ZCLibClient getZCLibClient].libInitInfo.customTitle;
            break;
        default:
            break;
    }
    
    if ([[ZCLibClient getZCLibClient].libInitInfo.titleType intValue]  == 2) {
        _titleCustomTF.text = [ZCLibClient getZCLibClient].libInitInfo.customTitle;
    }
    
    
}

-(void)switchValueChanged:(UISwitch *)sender{
    switch (sender.tag) {
        case 201:
            if (sender.on) {
                _titleEnterpriseSwitch.on = NO;
                _titleCustomSwitch.on  = NO;
                _titleCustomTF.hidden = YES;
                titleType = @"0";
            }else{
                _titleEnterpriseSwitch.on = NO;
                _titleCustomSwitch.on  = NO;
                _titleCustomTF.hidden = YES;
                titleType = @"0";
            }
            break;
        case 202:
            if (sender.on) {
                _titleDefaultSwitch.on = NO;
                _titleCustomTF.hidden = NO;
                _titleCustomSwitch.on = NO;
                _titleCustomTF.hidden = YES;
//                _titleEnterpriseSwitch.on = NO;
                titleType = @"1";
            }else{
                _titleDefaultSwitch.on = NO;
                _titleCustomTF.hidden = YES;
                _titleCustomSwitch.on = NO;
//                _titleEnterpriseSwitch.on = NO;
                titleType = @"0";
            }
            break;
        case 203:
            if (sender.on) {
                _titleDefaultSwitch.on = NO;
                _titleCustomTF.hidden = NO;
//                _titleCustomSwitch.on = NO;
                 _titleEnterpriseSwitch.on = NO;
                titleType = @"2";
            }else{
                _titleDefaultSwitch.on = NO;
                _titleCustomTF.hidden = YES;
                 _titleEnterpriseSwitch.on = NO;
//                _titleCustomSwitch.on = NO;
                titleType = @"0";
            }
            break;
        default:
            break;
    }
    [[NSUserDefaults standardUserDefaults] setValue:titleType forKey:@"titleType"];
    
}

NSString *zcConvertToString(id object){
    if ([object isKindOfClass:[NSNull class]]) {
        return @"";
    }else if(!object){
        return @"";
    }else if([object isKindOfClass:[NSNumber class]]) {
        return [object stringValue];
    }else{
        return [NSString stringWithFormat:@"%@",object];
    }
}

@end
