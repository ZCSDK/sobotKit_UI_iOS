//
//  ZCSettingAidVC.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCSettingAidVC : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *aidTF;
@property (weak, nonatomic) IBOutlet UISwitch *aidTurnSwitch;
@property (weak, nonatomic) IBOutlet UIScrollView *bgScrollView;
@property (weak, nonatomic) IBOutlet UIView *lineView;

@end
