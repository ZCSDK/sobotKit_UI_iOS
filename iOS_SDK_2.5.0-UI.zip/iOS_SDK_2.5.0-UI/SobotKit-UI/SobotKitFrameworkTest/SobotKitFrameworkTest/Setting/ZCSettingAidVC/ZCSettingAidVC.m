//
//  ZCSettingAidVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCSettingAidVC.h"

@interface ZCSettingAidVC ()

@end

@implementation ZCSettingAidVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self createNavc];
    [self layoutSubviews];
    self.bgScrollView.backgroundColor = UIColorFromRGB(0xEFF3FA);
    self.lineView.backgroundColor = UIColorFromRGB(0xdadada);
    CGRect lineF = self.lineView.frame;
    lineF.size.height = 0.5f;
    self.lineView.frame = lineF;
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hideKeyBoard)];
    [self.bgScrollView addGestureRecognizer:tap];
}

-(void)createNavc{
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"对接客服";
    
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    [leftBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 0);
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    
    UIButton * rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(ScreenWidth - 60, NavBarHeight - 40, 50, 40);
    [rightBtn setTitle:@"保存" forState:UIControlStateNormal];
    rightBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [rightBtn addTarget:self action:@selector(saveAction:) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    UIBarButtonItem * rightItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    
    self.navigationItem.rightBarButtonItem = rightItem;
}

-(void)backAction:(UIButton*)sender{
    [self hideKeyBoard];
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)saveAction:(UIButton *)sender{
    [self hideKeyBoard];
//    if (_aidTF.text.length>0) {
//        [ZCLibClient getZCLibClient].libInitInfo.receptionistId = _aidTF.text;
        
//    }else{
//        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"请输入客服ID" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
//        [alertView show];
//        return;
//    }
//    
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setValue:_aidTF.text forKey:@"receptionistId"];
    [userDefaults setBool:_aidTurnSwitch.on forKey:@"tranReceptionistFlag"];
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)layoutSubviews{
    
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
    if ([userDefaults valueForKey:@"receptionistId"]) {
//        _aidTF.text = [ZCLibClient getZCLibClient].libInitInfo.receptionistId;
        _aidTF.text = [userDefaults valueForKey:@"receptionistId"];
    }
   
    _aidTurnSwitch.on = NO;
    _aidTurnSwitch.tag = 501;
    if ([userDefaults boolForKey:@"tranReceptionistFlag"]) {
        _aidTurnSwitch.on = [userDefaults boolForKey:@"tranReceptionistFlag"];
    }
    
    [_aidTurnSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    
}

-(void)switchValueChanged:(UISwitch *)sender{
     NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
    switch (sender.tag) {
        case 501:
            if (sender.on) {
//                [ZCLibClient getZCLibClient].libInitInfo.tranReceptionistFlag = 1;
                [userDefaults setBool:YES forKey:@"tranReceptionistFlag"];
            }else{
//                [ZCLibClient getZCLibClient].libInitInfo.tranReceptionistFlag = 0;
                [userDefaults setBool:NO forKey:@"tranReceptionistFlag"];
            }
            
            break;
            
        default:
            break;
    }
}


#pragma mark -- 全局回收键盘
- (void)hideKeyBoard
{
    for (UIWindow* window in [UIApplication sharedApplication].windows)
    {
        for (UIView* view in window.subviews)
        {
            [self dismissAllKeyBoardInView:view];
        }
    }
}

-(BOOL) dismissAllKeyBoardInView:(UIView *)view
{
    if([view isFirstResponder])
    {
        [view resignFirstResponder];
        return YES;
    }
    for(UIView *subView in view.subviews)
    {
        if([self dismissAllKeyBoardInView:subView])
        {
            return YES;
        }
    }
    return NO;
}

@end
