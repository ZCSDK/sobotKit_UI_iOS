//
//  ZCOrderVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/12/11.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCOrderVC.h"
#import "ZCRobotIntroduceView.h"
#import "ZCNSuserdefaultdManager.h"
@interface ZCOrderVC (){
    
}

@property (nonatomic,strong) UIScrollView * scrollView;

@property (nonatomic ,strong) UILabel * titleLab;

@property (nonatomic,strong) UILabel * detailLab;

@property (nonatomic,strong) ZCRobotIntroduceView *robotView;

@end

@implementation ZCOrderVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"工单系统";
    [self.navigationController setToolbarHidden:YES animated:NO];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
//    [leftBtn setTitleColor:UIColorFromRGB(0x39B9C2) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
//    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
//    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    [self setupUI];
}

-(void)backAction:(UIButton *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)setupUI{
    
    CGFloat itemH = 0;
    if (ZC_iPhoneX) {
        itemH = 34;
    }
    
    self.scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, NavBarHeight, ScreenWidth, ScreenHeight - NavBarHeight - 50 - itemH)];
    self.scrollView.backgroundColor = [UIColor clearColor];
    self.scrollView.scrollEnabled = YES;
    self.scrollView.alwaysBounceVertical = YES;
    self.scrollView.alwaysBounceHorizontal = NO;
    self.scrollView.showsVerticalScrollIndicator = NO;
    self.scrollView.bounces = NO;
    self.scrollView.userInteractionEnabled = YES;
    [self.view addSubview:self.scrollView];
    
    
    self.titleLab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), ZCNumber(21), ScreenWidth - ZCNumber(40), 50)];
    self.titleLab.textAlignment = NSTextAlignmentLeft;
    self.titleLab.text = @"多重自定义字段+自由流转，满足企业个性化工单需求";
    self.titleLab.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:18];
    self.titleLab.numberOfLines = 0;
    [self.scrollView addSubview:self.titleLab];
    
    self.detailLab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(self.titleLab.frame) + 6, ScreenWidth - ZCNumber(40), 17)];
    self.detailLab.text = @"智齿客服工单系统，让企业内部沟通协作更顺畅";
    self.detailLab.textColor = UIColorFromRGB(0xBDC3D1);
    self.detailLab.font = [UIFont systemFontOfSize:12];
    [self.scrollView addSubview:_detailLab];
    
    // order_1
    UIImageView * order_1 = [[UIImageView alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(self.detailLab.frame)+ ZCNumber(40), ScreenWidth - ZCNumber(40), ZCNumber(195))];
    order_1.image = [UIImage imageNamed:@"order_1"];
    order_1.contentMode = UIViewContentModeScaleAspectFit;
    [self.scrollView addSubview:order_1];
    
    // title_1
    UILabel * title_1 = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(order_1.frame)+ ZCNumber(20), ScreenWidth - ZCNumber(40), 20)];
    title_1.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:14];
    title_1.textAlignment = NSTextAlignmentLeft;
    title_1.text = @"1.工单能满足那些需求？";
    [self.scrollView addSubview:title_1];

    NSArray * arr11 = @[@"·客户-提供更好体验",
                        @"全渠道工单发起",
                        @"实时提醒，随时获取工单进度反馈",
                        @"邮件沟通，参与问题解决"
                        ];
    
    CGFloat heigh1 = [self createTitleArr:arr11 WithView:self.scrollView Height:CGRectGetMaxY(title_1.frame) + ZCNumber(20)];
    
    
    NSArray * arr12 = @[@"·一线客服-快速处理解决",
                        @"发起工单，问题升级协调处理",
                        @"工单推进灵活流转，对接关键人",
                        @"查看工单历史，随时提醒工单进度"
                        ];
    
    CGFloat heigh2 = [self createTitleArr:arr12 WithView:self.scrollView Height:heigh1 + ZCNumber(20)];
    
    NSArray * arr13 = @[@"·业务部门-及时获取反馈，协助问题解决",
                        @"准确获取用户反馈，参与工单协作",
                        @"及时与用户沟通，保证问题解决"
                        ];
    
    CGFloat heigh3 = [self createTitleArr:arr13 WithView:self.scrollView Height:heigh2 + ZCNumber(20)];
    
    
    NSArray * arr14 = @[@"·客服管理-提升管理效率，优化服务体系",
                        @"多个自定义字段，满足企业个性化流程",
                        @"自定义SLA协议，提供等级服务，保证服务质量",
                        @"全面的统计报表，帮助管理者优化服务流程",
                        @"客服问题处理流程标准化，各部门工作效率一目了然"
                        ];
    
    CGFloat heigh4 = [self createTitleArr:arr14 WithView:self.scrollView Height:heigh3 + ZCNumber(20)];
    
    
    // order_2
    UIImageView * order_2 = [[UIImageView alloc]initWithFrame:CGRectMake(ZCNumber(38), heigh4 + ZCNumber(50), ScreenWidth - ZCNumber(38*2), ZCNumber(60))];
    order_2.image = [UIImage imageNamed:@"order_2"];
    order_2.contentMode = UIViewContentModeScaleAspectFit;
    [self.scrollView addSubview:order_2];
    
    
    // title_2
    UILabel * title_2 = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(order_2.frame)+ ZCNumber(30), ScreenWidth - ZCNumber(40), 20)];
    title_2.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:14];
    title_2.textAlignment = NSTextAlignmentLeft;
    title_2.text = @"2.智齿客服工单系统的优势";
    [self.scrollView addSubview:title_2];
    
    NSArray * arr21 = @[@"·手机处理工单",
                        @"智齿客服App可以接收工单、查看工单、分配工单、处理工单，客户问题随时随地快速解决。"
                        ];
    
    CGFloat heigh21 = [self createTitleArr:arr21 WithView:self.scrollView Height:CGRectGetMaxY(title_2.frame) + ZCNumber(20)];
    
    
    NSArray * arr22 = @[@"·连接云客服中心",
                        @"与云客户中心实时连接，客户以往的浏览轨迹、聊天信息、通话记录、工单历史一目了然。"
                        ];
    
    CGFloat heigh22 = [self createTitleArr:arr22 WithView:self.scrollView Height:heigh21 + ZCNumber(20)];
    
    
    NSArray * arr23 = @[@"·连接智齿客服其他产品模块",
                        @"配合智齿云呼叫中心/机器人客服/人工在线客服，售前售中售后问题一次性解决，保证留住每个客户。"
                        ];
    
    CGFloat heigh23 = [self createTitleArr:arr23 WithView:self.scrollView Height:heigh22 + ZCNumber(20)];
    
    
    self.scrollView.contentSize = CGSizeMake(ScreenWidth, heigh23 + ZCNumber(50));
    
    //咨询客服
    [self layoutBtn];
}


#pragma mark -- 联系我们
-(void)layoutBtn{
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    CGFloat Y = ScreenHeight - 50;
    if (ZC_iPhoneX) {
        Y = ScreenHeight - 50 - 34;
    }
    btn.frame = CGRectMake(0, Y, ScreenWidth, 50);
    [btn setBackgroundColor:UIColorFromRGB(0x0DAEAF)];
    [btn setTitle:@" 咨询客服" forState:UIControlStateNormal];
    [btn setTitle:@" 咨询客服" forState:UIControlStateHighlighted];
    [btn setImage:[UIImage imageNamed:@"Online"] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:@"Online"] forState:UIControlStateHighlighted];
    [btn addTarget:self action:@selector(openSDK:) forControlEvents:UIControlEventTouchUpInside];
    
    //    btn.imageEdgeInsets = UIEdgeInsetsMake(5, btn.titleLabel.frame.origin.x - 3 - btn.imageView.frame.size.width, 5, btn.titleLabel.frame.origin.x -3);
    //    btn.type = 1;
    [self.view addSubview:btn];
}


// 循环创建 label
-(CGFloat)createTitleArr:(NSArray *)arr WithView:(UIView *)view Height:(CGFloat)height{
    
    CGFloat itemH = height;
    for (int i = 0; i<arr.count; i++) {
        UILabel * listLab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), itemH, ScreenWidth - ZCNumber(40), 20)];
        listLab.textAlignment = NSTextAlignmentLeft;
        listLab.text = arr[i];
        listLab.textColor = UIColorFromRGB(0x8B98AD);
        if ([listLab.text hasPrefix:@"·"]) {
            listLab.textColor = UIColorFromRGB(0x001F2A);
        }
        listLab.numberOfLines = 0;
        listLab.font = [UIFont systemFontOfSize:14];
        [view addSubview:listLab];
        // 重新计算label的高度
        [self getTextRectWith:arr[i] WithMaxWidth:ScreenWidth - ZCNumber(40) WithlineSpacing:5 AddLabel:listLab];
        itemH  = itemH + CGRectGetHeight(listLab.frame) + 10;
    }
    
    return itemH;
    
}

-(CGRect)getTextRectWith:(NSString *)str WithMaxWidth:(CGFloat)width  WithlineSpacing:(CGFloat)LineSpacing AddLabel:(UILabel *)label{
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc]initWithString:str];
    
    if ([str hasPrefix:@"·"]) {
        // 文字颜色
        NSUInteger firstloc = [[attributedString string]rangeOfString:@"·"].location ;
        NSRange range = NSMakeRange(firstloc, 1);
        [attributedString addAttribute:NSForegroundColorAttributeName value:UIColorFromRGB(0x0DAEAF) range:range];
    }
    
    NSMutableParagraphStyle * parageraphStyle = [[NSMutableParagraphStyle alloc]init];
    [parageraphStyle setLineSpacing:LineSpacing];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:parageraphStyle range:NSMakeRange(0, [str length])];
    [attributedString addAttribute:NSFontAttributeName value:label.font range:NSMakeRange(0, str.length)];
    
    label.attributedText = attributedString;
    
    // 这里的高度的计算，不能在按 attributedString的属性去计算了，需要拿到label中的
    CGSize size = [self autoHeightOfLabel:label with:width];
    CGRect labelF = label.frame;
    labelF.size.height = size.height;
    label.frame = labelF;
    
    return labelF;
}


/**
 计算Label高度
 
 @param label 要计算的label，设置了值
 @param width label的最大宽度
 @param type 是否从新设置宽，1设置，0不设置
 */
- (CGSize )autoHeightOfLabel:(UILabel *)label with:(CGFloat )width{
    //Calculate the expected size based on the font and linebreak mode of your label
    // FLT_MAX here simply means no constraint in height
    CGSize maximumLabelSize = CGSizeMake(width, FLT_MAX);
    
    CGSize expectedLabelSize = [label sizeThatFits:maximumLabelSize];
    
    //adjust the label the the new height.
    CGRect newFrame = label.frame;
    newFrame.size.height = expectedLabelSize.height;
    label.frame = newFrame;
    [label updateConstraintsIfNeeded];
    
    return expectedLabelSize;
}


-(void)openSDK:(UIButton*)sender{
    NSLog(@"启动");
    [ZCNSuserdefaultdManager shareUserdefaultd].type = 1;
    [[ZCNSuserdefaultdManager shareUserdefaultd] openSDKWith:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
