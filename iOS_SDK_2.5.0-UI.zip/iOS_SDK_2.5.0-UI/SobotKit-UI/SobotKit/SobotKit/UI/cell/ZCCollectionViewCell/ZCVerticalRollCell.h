//
//  ZCVerticalRollCell.h
//  SobotKit
//
//  Created by lizhihui on 2017/11/13.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZCChatBaseCell.h"

@interface ZCVerticalRollCell : ZCChatBaseCell

@property (nonatomic,assign) BOOL isOpenMore;// 展开更多
@property (nonatomic,assign) BOOL isShowOpenBtn; // 显示更多
@property (nonatomic,assign) int  moreCount ; // 当前展开的个数
@property (nonatomic,assign) int  allMoreCount;// 实际个数

//@property (nonatomic,strong) ZCLibMessage  * model;//model

@end
