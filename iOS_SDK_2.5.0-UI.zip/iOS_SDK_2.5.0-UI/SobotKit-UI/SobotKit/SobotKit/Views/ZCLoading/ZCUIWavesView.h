//
//  ZCUIWavesView.h
//  SobotKit
//
//  Created by lizhihui on 15/11/11.
//  Copyright © 2015年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *
 *  loading 波纹
 *
 */
@interface ZCUIWavesView : UIView

@end
