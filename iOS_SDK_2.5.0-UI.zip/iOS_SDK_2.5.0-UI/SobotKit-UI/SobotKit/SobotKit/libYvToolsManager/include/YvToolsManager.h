//
//  YvToolsManager.h
//  YvToolsManager
//
//  Created by lifayu on 2017/11/3.
//  Copyright © 2017年 com.yunva.yaya. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YvToolsManager : NSObject

/**
 单例

 @return YvToolsManager唯一实例
 */
+ (instancetype)sharedInstance;

/**
 初始化SDK

 @param appId 应用编号
 */
- (void)initToolsManagerWithAppId:(NSString *)appId;

@end
