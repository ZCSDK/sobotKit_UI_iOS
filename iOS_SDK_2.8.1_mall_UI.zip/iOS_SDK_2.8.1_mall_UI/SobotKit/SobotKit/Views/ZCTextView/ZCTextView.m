//
//  ZCTextView.m
//  SobotKit
//
//  Created by xuhan on 2019/9/24.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import "ZCTextView.h"

@implementation ZCTextView
{
    UIColor * _placeholderColor;
    
    UIColor *writeColor;
}

-(void)setPlaceholder:(NSString *)str and:(UIColor *)color{
    
    _placeholderColor = color;
    _placeholder = str;
    
    writeColor = self.textColor;
    
    self.text = str;
    self.textColor = _placeholderColor?_placeholderColor:[UIColor grayColor];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidBegin) name:UITextViewTextDidBeginEditingNotification object:self];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidEnd) name:UITextViewTextDidEndEditingNotification object:self];
    
}
-(void)textDidBegin{
    if ([self.text isEqualToString:_placeholder]) {
        self.text = @"";
        self.textColor = [ZCUITools zcgetChatTextViewColor];
    }
}

-(void)textDidEnd{
    if([self.text isEqualToString:@""]){
        self.text = _placeholder;
        self.textColor = _placeholderColor?_placeholderColor:[UIColor blueColor];
    }
    
}
@end
