//
//  ZCMsgDetailsVC.m
//  SobotKit
//
//  Created by lizhihui on 2019/2/20.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import "ZCMsgDetailsVC.h"
#import "ZCUIColorsDefine.h"
#import "ZCLIbGlobalDefine.h"
#import "ZCUIImageTools.h"
#import "ZCUICore.h"
#import "ZCMsgDetailCell.h"
#import "ZCButton.h"
#import "ZCHtmlCore.h"

#import "ZCUIConfigManager.h"
#import "ZCPlatformTools.h"
#import "ZCUIConfigManager.h"
#import "ZCRecordListModel.h"
#import "ZCLeaveDetailCell.h"
#define cellmsgDetailIdentifier @"ZCLeaveDetailCell"
#import "ZCUICustomActionSheet.h"
#import "ZCUIWebController.h"
#import "ZCUIRatingView.h"
#import "ZCHtmlFilter.h"


@interface ZCMsgDetailsVC ()<UITableViewDelegate,UITableViewDataSource,ZCUIBackActionSheetDelegate,RatingViewDelegate>{
    // 屏幕宽高
    CGFloat                     viewWidth;
    CGFloat                     viewHeigth;
    
    BOOL     isShowHeard;
    BOOL     isAddShowBtn;// 添加展开按钮
    
}
@property(nonatomic,strong)UITableView      *listTable;

@property (nonatomic,strong) NSMutableArray * listArray;

@property (nonatomic,strong) ZCButton * showBtn;

@property (nonatomic,strong) UIView * headerView;
@property (nonatomic,strong) UIView * footView;

@property (nonatomic,strong) UIView * commitFootView;


/***  评价页面 **/
@property (nonatomic,strong) ZCUICustomActionSheet *sheet;

@end

@implementation ZCMsgDetailsVC

// 横竖屏切换
-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    
    if (toInterfaceOrientation == UIInterfaceOrientationPortrait ||toInterfaceOrientation == UIInterfaceOrientationPortraitUpsideDown) {
        
        CGFloat c = viewWidth;
        if(viewWidth > viewHeigth){
            viewWidth = viewHeigth;
            viewHeigth = c;
        }
    }else{
        CGFloat c = viewHeigth;
        if(viewWidth < viewHeigth){
            viewHeigth = viewWidth;
            viewWidth = c;
        }
    }
    // 切换的方法必须调用
    [self viewDidLayoutSubviews];
}

//**************************项目中的导航栏一部分是自定义的View,一部分是系统自带的NavigationBar*********************************
- (void)setNavigationBarStyle{
    self.navigationController.navigationBar.translucent = NO;
    NSString * img ;
    NSString * selImg;
    if (zcLibConvertToString([ZCUICore getUICore].kitInfo.topBackNolImg).length >0) {
        img = zcLibConvertToString([ZCUICore getUICore].kitInfo.topBackNolImg);
    }
    if (zcLibConvertToString([ZCUICore getUICore].kitInfo.topBackSelImg).length >0) {
        selImg = zcLibConvertToString([ZCUICore getUICore].kitInfo.topBackSelImg);
    }
    
    [self createLeftBarItemSelect:@selector(goBack) norImageName:img  highImageName:selImg];
}

- (void)createLeftBarItemSelect:(SEL)select norImageName:(NSString *)imageName highImageName:(NSString *)heightImageName{
    //12 * 19
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn.titleLabel setFont:[ZCUITools zcgetListKitTitleFont]];
    //    [btn addTarget:self action:select forControlEvents:UIControlEventTouchUpInside];
    btn.frame = CGRectMake(0, 0, 44,44) ;
    if (imageName) {
        [btn setImage:[ZCUITools zcuiGetBundleImage:imageName] forState:UIControlStateNormal];
    }else{
        btn.frame = CGRectMake(0, 0, 44, 44);
        [btn setImage:[ZCUITools zcuiGetBundleImage:@"zcicon_titlebar_back_normal"] forState:UIControlStateNormal];
    }
    if (heightImageName) {
        [btn setImage:[ZCUITools zcuiGetBundleImage:heightImageName] forState:UIControlStateHighlighted];
    }else{
        [btn setImage:[ZCUITools zcuiGetBundleImage:@"zcicon_titlebar_back_normal"] forState:UIControlStateHighlighted];
    }
    
    if ([ZCUICore getUICore].kitInfo.topBackNolColor != nil) {
        [btn setBackgroundImage:[ZCUIImageTools zcimageWithColor:[ZCUICore getUICore].kitInfo.topBackNolColor] forState:UIControlStateNormal];
    }
    if ([ZCUICore getUICore].kitInfo.topBackSelColor != nil) {
        [btn setBackgroundImage:[ZCUIImageTools zcimageWithColor:[ZCUICore getUICore].kitInfo.topBackSelColor] forState:UIControlStateHighlighted];
    }
    [btn setTitleColor:[ZCUITools zcgetTopViewTextColor] forState:UIControlStateNormal];
    [btn setTitleColor:[ZCUITools zcgetTopViewTextColor] forState:UIControlStateHighlighted];
    [btn setTitleColor:[ZCUITools zcgetTopViewTextColor] forState:UIControlStateDisabled];
    [btn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    btn.tag = BUTTON_BACK;
    [btn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    
    CGRect lf = btn.frame;
    lf.size.width=60;
    [btn setFrame:lf];
    [btn setTitle:ZCSTLocalString(@"返回") forState:UIControlStateNormal];
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithCustomView:btn];
    
    //    self.navigationItem.leftBarButtonItem = item;
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc]   initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace   target:nil action:nil];
    
    /**
     width为负数时，相当于btn向右移动width数值个像素，由于按钮本身和  边界间距为5pix，所以width设为-5时，间距正好调整为0；width为正数 时，正好相反，相当于往左移动width数值个像素
     */
    negativeSpacer.width = -5;
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer, item, nil];
    
    [self.navigationController.navigationBar setBarTintColor:[ZCUITools zcgetDynamicColor]];
//    if ([ZCUICore getUICore].kitInfo.topViewBgColor != nil) {
//        [self.navigationController.navigationBar setBarTintColor:[ZCUICore getUICore].kitInfo.topViewBgColor];
//    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(actionSheetItemClick:) name:@"actionSheetClick:" object:nil];
    if ([ZCUICore getUICore].kitInfo.navcBarHidden) {
        self.navigationController.navigationBarHidden = YES;
//        [self.navigationController setNavigationBarHidden:YES];
        self.navigationController.navigationBar.translucent = NO;
    }
    
    if (self.navigationController.navigationBarHidden) {
        self.navigationController.navigationBar.translucent = NO;
    }
    
    
    viewHeigth = self.view.frame.size.height;
    viewWidth = self.view.frame.size.width;
    
    if(!self.navigationController.navigationBarHidden){
        viewHeigth = ScreenHeight - NavBarHeight;
        
        [self setNavigationBarStyle];
        self.title = ZCSTLocalString(@"留言详情");
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[ZCUITools zcgetTitleFont],NSForegroundColorAttributeName:[ZCUITools zcgetTopViewTextColor]}];
    }else{
        [self createTitleView];
        self.titleLabel.text = ZCSTLocalString(@"留言详情");
        [self.backButton.imageView setContentMode:UIViewContentModeScaleAspectFit];
        [self.backButton setTitle:ZCSTLocalString(@"返回") forState:UIControlStateNormal];
        [self.moreButton setHidden:YES];
        
    }
    
    
    isShowHeard = NO;
    _listArray = [NSMutableArray arrayWithCapacity:0];
    [self.view setBackgroundColor:UIColorFromRGB(0xF8F9FA)];
    [self createTableView];
    [self loadData];
}
-(ZCLibConfig *)getCurConfig{
    return [[ZCPlatformTools sharedInstance] getPlatformInfo].config;
}
// 加载数据
-(void)loadData{
    [[ZCUIToastTools shareToast] showProgress:@"" with:self.view];
    __weak ZCMsgDetailsVC * weakSelf = self;
    [[[ZCUIConfigManager getInstance] getZCAPIServer] postUserDealTicketinfoListWith:[self getCurConfig] ticketld:_ticketId start:^{
        
    } success:^(NSDictionary *dict, NSMutableArray *itemArray, ZCNetWorkCode sendCode) {
        [[ZCUIToastTools shareToast] dismisProgress];
        if (itemArray.count > 0) {
            [_listArray removeAllObjects];
            // flag ==2 时是 还需要处理
            for (ZCRecordListModel * model in itemArray) {
                
                if (model.flag == 2 && model.replayList.count > 0) {
                    for (ZCRecordListModel * item in model.replayList) {
                        item.flag = 2;
                        item.content = model.content;
                        item.timeStr = model.timeStr;
                        item.time = model.time;
                        [self.listArray addObject:item];
                    }
                }else{
                    [self.listArray addObject:model];
                }
                    
            }
    
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self createStarView];
            
            //这里进行UI更新
            [weakSelf.listTable reloadData];
            [weakSelf.listTable layoutIfNeeded];
//            NSLog(@"刷新了");
        });
        
  
        
    } failed:^(NSString *errorMessage, ZCNetWorkCode errorCode) {
        [[ZCUIToastTools shareToast] dismisProgress];
    } ];
    
}

-(void)buttonClick:(UIButton *)sender{
    
    if (self.navigationController) {
      [self.navigationController popViewControllerAnimated:YES];
    }else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}


-(void)createTableView{
    // 计算Y值
    CGFloat Y = 0;
    if (self.navigationController.navigationBarHidden) {
        Y = NavBarHeight;
    }
    
//    线条
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(0, Y, self.view.frame.size.width, 0.5)];
    lineView.backgroundColor = UIColorFromRGB(lineGrayColor);
    [self.view addSubview:lineView];
    
    _listTable = [[UITableView alloc]initWithFrame:CGRectMake(0, Y+1, viewWidth, viewHeigth - Y - 1) style:UITableViewStylePlain];
    _listTable.delegate = self;
    _listTable.dataSource = self;
    _listTable.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleBottomMargin;
    _listTable.autoresizesSubviews = YES;
    [self.view addSubview:_listTable];
    
    [_listTable registerClass:[ZCLeaveDetailCell class] forCellReuseIdentifier:cellmsgDetailIdentifier];
    
    if (iOS7) {
        _listTable.backgroundView = nil;
    }
    
    [_listTable setSeparatorColor:UIColorFromRGB(0xdce0e5)];
    [_listTable setSeparatorStyle:UITableViewCellSeparatorStyleNone];
//    [_listTable setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [_listTable setBackgroundColor:UIColorFromRGB(TextRecordBgColor)];
    [self setTableSeparatorInset];
    
    
    
    
}

-(void)commitScore{
    if(_sheet){
        [_sheet tappedCancel];
    }
    
     ZCRecordListModel *model = self.listArray.firstObject;
    // 去评价
    _sheet = [[ZCUICustomActionSheet alloc] initActionSheet:ServerSatisfcationOrderType Name:@"" Cofig:[ZCUICore getUICore].getLibConfig cView:self.view IsBack:NO isInvitation:1 WithUid:[ZCUICore getUICore].getLibConfig.uid   IsCloseAfterEvaluation:NO Rating:5 IsResolved:YES IsAddServerSatifaction:NO txtFlag:model.txtFlag ticketld:_ticketId ticketScoreInfooList:model.ticketScoreInfooList];
    _sheet.delegate = self;
//        _sheet.textFlag = model.txtFlag;
//        _sheet.ticketld = _ticketId;/Users/shiyao/Documents/newProjects/ZCNavBar/ZCNavBar/ZCNavBar/ZCNavBar.m
//        _sheet.ticketScoreInfooList = model.ticketScoreInfooList;
    [_sheet showInView:self.view];
}


-(void)createStarView{
    ZCRecordListModel *first = self.listArray.firstObject;
    if(first.isOpen && first.isEvalution == 0)
    {
        UIView * bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 64 + XBottomBarHeight)];
        bgView.backgroundColor = UIColorFromRGB(0xF8F9FA);
        _listTable.tableFooterView = bgView;
        
        
        _commitFootView = [[UIView alloc]initWithFrame:CGRectMake(0, ScreenHeight - 84 - XBottomBarHeight - NavBarHeight, ScreenWidth, 84 + XBottomBarHeight)];
        _commitFootView.backgroundColor = [UIColor whiteColor];

        
        _commitFootView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleTopMargin;
        _commitFootView.autoresizesSubviews = YES;
        [self.view addSubview:_commitFootView];
        
        // 区尾添加提交按钮 2.7.1改版
        UIButton * commitBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [commitBtn setTitle:ZCSTLocalString(@"服务评价") forState:UIControlStateNormal];
        
        [commitBtn setTitleColor:UIColorFromRGB(TextWhiteColor) forState:UIControlStateNormal];
        [commitBtn setTitleColor:UIColorFromRGB(TextWhiteColor) forState:UIControlStateHighlighted];
        UIImage * img = [ZCUIImageTools zcimageWithColor:[ZCUITools zcgetLeaveSubmitImgColor]];// UIColorFromRGB(BgTitleColor)
        [commitBtn setBackgroundImage:img forState:UIControlStateNormal];
        [commitBtn setBackgroundImage:img forState:UIControlStateSelected];
        commitBtn.frame = CGRectMake(ZCNumber(20), 20, ScreenWidth- ZCNumber(40), ZCNumber(44));
        commitBtn.tag = BUTTON_MORE;
        [commitBtn addTarget:self action:@selector(commitScore) forControlEvents:UIControlEventTouchUpInside];
        commitBtn.layer.masksToBounds = YES;
        commitBtn.layer.cornerRadius = 22.f;
        commitBtn.titleLabel.font = ZCUIFont17;
        commitBtn.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleTopMargin;
        commitBtn.autoresizesSubviews = YES;
        [_commitFootView addSubview:commitBtn];
    }else{
        UIView * bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 0, 0)];
        bgView.backgroundColor = UIColorFromRGB(0xEFF3FA);
        _listTable.tableFooterView = bgView;
        
        if(self.commitFootView){
            [self.commitFootView removeFromSuperview];
        }
    }
}


#pragma mark UITableView delegate Start
// 返回section数
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if(self.listArray.count > 0){
        ZCRecordListModel *first = self.listArray.firstObject;
        if(first.isOpen && first.isEvalution == 1)
        {
            return 2;
        }
    }
    return 1;
}

// 返回section高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if(section == 0){
        UIView *bgView = [self getHeaderViewHeight];
        return bgView.frame.size.height;
    }else{
        return 114;
    }
    
}

// 返回section 的View
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if(section == 0){
        NSString * str = @"";
        if (self.listArray.count > 0) {
            ZCRecordListModel * model = [_listArray lastObject];
            
            str = zcLibConvertToString(model.content);
        }
        return [self getHeaderViewHeight];
    }else{
        return [self getHeaderStarViewHeight];
    }
    
 
}

-(void)showMoreAction:(UIButton *)sender{
    if (sender.tag == 1001) {
        isShowHeard = YES;
    }else{
        isShowHeard = NO;
    }
    [self.listTable reloadData];
}

// 返回section下得行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
//    if(_listArray==nil){
//        return 0;
//    }
    if(section == 0){
        return _listArray.count;
    }
    return 0;
}

// cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ZCLeaveDetailCell *cell = (ZCLeaveDetailCell*)[tableView dequeueReusableCellWithIdentifier:cellmsgDetailIdentifier];
    if (cell == nil) {
        cell = [[ZCLeaveDetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellmsgDetailIdentifier];
    }
    if(indexPath.row==_listArray.count-1){
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
            [cell setSeparatorInset:UIEdgeInsetsZero];
        }
        
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:UIEdgeInsetsZero];
        }
        
        if([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]){
            [cell setPreservesSuperviewLayoutMargins:NO];
        }
    }
    if ( indexPath.row > _listArray.count -1) {
        return cell;
    }
    
    [cell setBackgroundColor:UIColor.whiteColor];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    ZCRecordListModel * model = _listArray[indexPath.row];
    
    __weak ZCMsgDetailsVC * saveSelf = self;
    
    [cell initWithData:model IndexPath:indexPath.row count:(int)self.listArray.count btnClick:^(ZCRecordListModel * _Nonnull model) {
        
    }];
//    [cell initWithData:model IndexPath:indexPath.row btnClick:^(ZCRecordListModel * _Nonnull model) {
//        if(_sheet){
//            [_sheet tappedCancel];
//        }
//        // 去评价
//        _sheet = [[ZCUICustomActionSheet alloc] initActionSheet:ServerSatisfcationOrderType Name:@"" Cofig:[ZCUICore getUICore].getLibConfig cView:saveSelf.view IsBack:NO isInvitation:1 WithUid:[ZCUICore getUICore].getLibConfig.uid   IsCloseAfterEvaluation:NO Rating:5 IsResolved:YES IsAddServerSatifaction:NO txtFlag:model.txtFlag ticketld:_ticketId ticketScoreInfooList:model.ticketScoreInfooList];
//        _sheet.delegate = saveSelf;
////        _sheet.textFlag = model.txtFlag;
////        _sheet.ticketld = _ticketId;/Users/shiyao/Documents/newProjects/ZCNavBar/ZCNavBar/ZCNavBar/ZCNavBar.m
////        _sheet.ticketScoreInfooList = model.ticketScoreInfooList;
//        [_sheet showInView:saveSelf.view];
//    }];
//
    [cell setShowDetailClickCallback:^(ZCRecordListModel * _Nonnull model,NSString *urlStr) {
        if (urlStr) {
            ZCUIWebController *webVC = [[ZCUIWebController alloc] initWithURL:urlStr];
            [saveSelf.navigationController pushViewController:webVC animated:YES];
            return;
        }

        NSString *htmlString = model.replyContent;
        if (model.flag == 3) {
            htmlString = model.content;
        }
        ZCUIWebController *webVC = [[ZCUIWebController alloc] initWithURL:htmlString];

        [saveSelf.navigationController pushViewController:webVC animated:YES];
    }];

    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    cell.selected = NO;

    return cell;
}

//-(void)dimissCustomActionSheetPage{
//    _sheet = nil;
//    [ZCUICore getUICore].isDismissSheetPage = YES;
    // 刷新数据
//    [self loadData];
//}


// table 行的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
        UITableViewCell *cell = [self tableView:tableView cellForRowAtIndexPath:indexPath];
        return cell.frame.size.height;
}

// table 行的点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

//设置分割线间距
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    if((indexPath.row+1) < _listArray.count){
        UIEdgeInsets inset = UIEdgeInsetsMake(0, 39, 0, 0);
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
            [cell setSeparatorInset:inset];
        }

        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:inset];
        }
    }
}

-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    [self setTableSeparatorInset];
    
    CGFloat Y = 0;
    if (self.navigationController.navigationBarHidden) {
        Y = NavBarHeight;
    }
    
    _listTable.frame = CGRectMake(0, Y+1, viewWidth, viewHeigth - Y - 1);
    //    [self.listTable setFrame:CGRectMake(0, NavBarHeight, viewWidth, viewHeigth - NavBarHeight)];
    [self.listTable reloadData];
}

#pragma mark UITableView delegate end

/**
 *  设置UITableView分割线空隙
 */
-(void)setTableSeparatorInset{
    UIEdgeInsets inset = UIEdgeInsetsMake(0, 39, 0, 0);
    if ([_listTable respondsToSelector:@selector(setSeparatorInset:)]) {
        [_listTable setSeparatorInset:inset];
    }
    
    if ([_listTable respondsToSelector:@selector(setLayoutMargins:)]) {
        [_listTable setLayoutMargins:inset];
    }
}


#pragma mark -- 计算文本高度
-(CGRect)getTextRectWith:(NSString *)str WithMaxWidth:(CGFloat)width  WithlineSpacing:(CGFloat)LineSpacing AddLabel:(UILabel *)label {

//    CGRect labelF = label.frame;
    
//    label.text = [self filterHtmlImage:str];
//
//    CGSize size = [self autoHeightOfLabel:label with:width IsSetFrame:YES];
//
//    labelF.size.height = size.height;
//    label.frame = labelF;
    
    [ZCHtmlCore filterHtml:[self filterHtmlImage:str] result:^(NSString * _Nonnull text1, NSMutableArray * _Nonnull arr, NSMutableArray * _Nonnull links) {
        if (text1.length > 0 && text1 != nil) {
            label.attributedText =   [ZCHtmlFilter setHtml:text1 attrs:arr view:label textColor:UIColorFromRGB(TextWordOrderListTextColor) textFont:label.font linkColor:[ZCUITools zcgetChatLeftLinkColor]];
        }else{
            label.attributedText =   [[NSAttributedString alloc] initWithString:@""];
        }
        
        CGRect labelF = label.frame;
        label.text = text1;
        CGSize size = [self autoHeightOfLabel:label with:width IsSetFrame:YES];
        
        labelF.size.height = size.height;
        label.frame = labelF;

    }];
    
    
    return label.frame;
}

/**
 计算Label高度
 
 @param label 要计算的label，设置了值
 @param width label的最大宽度
 @param type 是否从新设置宽，1设置，0不设置
 */
- (CGSize )autoHeightOfLabel:(UILabel *)label with:(CGFloat )width IsSetFrame:(BOOL)isSet{
    //Calculate the expected size based on the font and linebreak mode of your label
    // FLT_MAX here simply means no constraint in height
    CGSize maximumLabelSize = CGSizeMake(width, FLT_MAX);
    
    CGSize expectedLabelSize = [label sizeThatFits:maximumLabelSize];// 返回最佳的视图大小
    
    //adjust the label the the new height.
    if (isSet) {
        CGRect newFrame = label.frame;
        newFrame.size.height = expectedLabelSize.height;
        label.frame = newFrame;
        [label updateConstraintsIfNeeded];
    }
    return expectedLabelSize;
}


-(UIView*)getHeaderViewHeight{
    if (_headerView != nil) {
        [_headerView removeFromSuperview];
        _headerView = nil;
    }
    
    _headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ZCNumber(140))];
    _headerView.backgroundColor = [UIColor whiteColor];
    UILabel *titleLab = [[UILabel alloc] initWithFrame:CGRectMake(20,27, 170, ZCNumber(22))];
    [titleLab setFont:ZCUIFontBold17];
    [titleLab setTextAlignment:NSTextAlignmentLeft];
    [titleLab setTextColor:UIColorFromRGB(0x515A7C)];
    [_headerView addSubview:titleLab];
    
    UILabel *labState = [[UILabel alloc] initWithFrame:CGRectMake(ScreenWidth - 70, 30,50, 20)];
    [labState setBackgroundColor:UIColorFromRGB(0x0DAEAF)];
    [labState setFont:ZCUIFont12];
    labState.layer.cornerRadius = 10.0f;
    [labState setTextColor:UIColorFromRGB(TextWhiteColor)];
    [labState setTextAlignment:NSTextAlignmentCenter];
    labState.layer.masksToBounds = YES;

    labState.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    labState.autoresizesSubviews = YES;
    [_headerView addSubview:labState];
    
    
    NSString * str = @"";
    if(_listArray.count > 0){
        ZCRecordListModel * model = [_listArray lastObject];
        titleLab.text = zcLibConvertToString(model.timeStr);
        str = zcLibConvertToString(model.content);
        
        ZCRecordListModel *firstFlag = [_listArray firstObject];
        
        
        switch (firstFlag.flag) {
            case 1:
                labState.text =  ZCSTLocalString(@"已创建");
                labState.backgroundColor = UIColorFromRGB(0xE4EAF2);
                break;
            case 2:
                labState.text =  ZCSTLocalString(@"受理中");
                labState.backgroundColor = UIColorFromRGB(0xF6AF38);
                break;
            case 3:
                labState.text =  ZCSTLocalString(@"已完成");
                labState.backgroundColor = UIColorFromRGB(BgTitleColor);
                break;
            default:
                break;
        }
    }
//    str = @"jkdlfj按时间拉开点附近绿卡交了多少客服建立刺啦地方呢个电动阀SDK静安寺老地方金额卢卡斯";
   
    
    UILabel * conlab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(titleLab.frame) + ZCNumber(8), ScreenWidth - ZCNumber(40), ZCNumber(50))];
    conlab.numberOfLines = 0;
    conlab.textColor = UIColorFromRGB(0xacb5c4);
    conlab.font = ZCUIFont14;
    [self getTextRectWith:str WithMaxWidth:ScreenWidth - ZCNumber(40) WithlineSpacing:6 AddLabel:conlab];
//    conlab.text = ;
    [_headerView addSubview:conlab];
    
    CGSize conlabSize = [self autoHeightOfLabel:conlab with:ScreenWidth - ZCNumber(30) IsSetFrame:NO];
    
    _showBtn = [ZCButton buttonWithType:UIButtonTypeCustom];
    [_showBtn addTarget:self action:@selector(showMoreAction:) forControlEvents:UIControlEventTouchUpInside];
    _showBtn.tag = 1001;
    _showBtn.type = 2;
    _showBtn.space = ZCNumber(18);
    _showBtn.titleLabel.font = ZCUIFont12;
    [_showBtn setTitle: ZCSTLocalString(@"全部展开") forState:UIControlStateNormal];
    [_showBtn setImage:[ZCUITools zcuiGetBundleImage:@"zciocn_arrow_down"] forState:UIControlStateNormal];


//    _showBtn.backgroundColor = [UIColor redColor];
    [_headerView addSubview: _showBtn];
    _showBtn.frame = CGRectMake(ScreenWidth/2- ZCNumber(120/2), CGRectGetMaxY(conlab.frame) + ZCNumber(8), 120, ZCNumber(0));
    _showBtn.hidden = YES;
    [_showBtn setTitleColor:UIColorFromRGB(BgTitleColor) forState:UIControlStateNormal];
    if (conlabSize.height > 40) {
        // 添加 展开全文btn
        _showBtn.hidden = NO;
    }
    
    if (!_showBtn.hidden) {
        if (isShowHeard) {
            // 显示全部
            _showBtn.frame = CGRectMake(ScreenWidth/2- ZCNumber(120/2), CGRectGetMaxY(conlab.frame) + ZCNumber(8), 120, ZCNumber(20));
            [self getTextRectWith:str WithMaxWidth:ScreenWidth - ZCNumber(40) WithlineSpacing:6 AddLabel:conlab];
            _showBtn.tag = 1002;
            [_showBtn setTitle:ZCSTLocalString(@"点击收起") forState:UIControlStateNormal];
            [_showBtn setImage:[ZCUITools zcuiGetBundleImage:@"zciocn_arrow_up"] forState:UIControlStateNormal];
            CGRect sf = _showBtn.frame;
            sf.origin.y = CGRectGetMaxY(conlab.frame) + ZCNumber(20);
            _showBtn.frame = sf;
        }else{
            // 收起之后
            conlab.frame = CGRectMake(ZCNumber(20), CGRectGetMaxY(titleLab.frame) + ZCNumber(8), ScreenWidth - ZCNumber(40), ZCNumber(50));
            
            _showBtn.frame = CGRectMake(ScreenWidth/2- ZCNumber(120/2), CGRectGetMaxY(conlab.frame) + ZCNumber(8), ZCNumber(120), ZCNumber(20));
            _showBtn.tag = 1001;
            [_showBtn setTitle:ZCSTLocalString(@"全部展开") forState:UIControlStateNormal];
            [_showBtn setImage:[ZCUITools zcuiGetBundleImage:@"zciocn_arrow_down"] forState:UIControlStateNormal];
        }
    }
    
    // 线条
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(0,0, ScreenWidth, 10)];
    lineView.backgroundColor = UIColorFromRGB(0xF8F9FA);
    [_headerView addSubview:lineView];
    
    CGFloat y = CGRectGetMaxY(_showBtn.frame)+17;
    if(_showBtn.isHidden){
        y = CGRectGetMaxY(conlab.frame)+17;
    }
    
    // 线条
    UIView *lineView1 = [[UIView alloc]initWithFrame:CGRectMake(0,y, ScreenWidth, 10)];
    lineView1.backgroundColor = UIColorFromRGB(0xF8F9FA);
    [_headerView addSubview:lineView1];
    
    CGRect hf = _headerView.frame;
    hf.size.height = y + 10;
    _headerView.frame = hf;
    
    UIView *lineView_0 = [[UIView alloc]initWithFrame:CGRectMake(0, 10, ScreenWidth, 0.5)];
    lineView_0.backgroundColor = UIColorFromRGB(lineGrayColor);
    
    [_headerView addSubview:lineView_0];
    
    UIView *lineView_1 = [[UIView alloc]initWithFrame:CGRectMake(0, y, ScreenWidth, 0.5)];
    lineView_1.backgroundColor = UIColorFromRGB(lineGrayColor);
    
    [_headerView addSubview:lineView_1];
    
    
    return _headerView;
}


-(UIView*)getHeaderStarViewHeight{
    if (_footView != nil) {
        [_footView removeFromSuperview];
        _footView = nil;
    }
    if(_listArray.count == 0){
        return nil;
    }

    [self createStarView];
    
    
    ZCRecordListModel * model = _listArray[0];
    
    _footView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ZCNumber(114))];
    _footView.backgroundColor = [UIColor whiteColor];
    
    UILabel *titleLab = [[UILabel alloc] initWithFrame:CGRectMake(ZCNumber(20), ZCNumber(26), ScreenWidth- ZCNumber(40), ZCNumber(24))];
    [titleLab setFont:ZCUIFontBold14];
    titleLab.text =ZCSTLocalString(@"我的服务评价");
    [titleLab setTextAlignment:NSTextAlignmentLeft];
    [titleLab setTextColor:UIColorFromRGB(0x455C73)];
    [_footView addSubview:titleLab];
    
    UILabel * labScore = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(titleLab.frame) + ZCNumber(5), 36, ZCNumber(18))];
    labScore.numberOfLines = 0;
    labScore.textColor = UIColorFromRGB(0xACB5C4);
    labScore.font = ZCUIFont12;
    labScore.text = ZCSTLocalString(@"评分：");
    [_footView addSubview:labScore];
    
    
    ZCUIRatingView *startView = [[ZCUIRatingView alloc] initWithFrame:CGRectMake(54, CGRectGetMaxY(titleLab.frame)+5, 140, 18)];
    [startView setImagesDeselected:@"zcicon_star_unsatisfied" partlySelected:@"zcicon_star_satisfied" fullSelected:@"zcicon_star_satisfied" andDelegate:self];
    
    [startView displayRating:[model.score floatValue]];
    startView.backgroundColor = [UIColor clearColor];
    startView.userInteractionEnabled = NO;
    [_footView addSubview:startView];
    
    
    UILabel * conlab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(labScore.frame) + ZCNumber(7), ScreenWidth - ZCNumber(40), ZCNumber(18))];
    conlab.numberOfLines = 1;
    conlab.textColor = UIColorFromRGB(0xACB5C4);
    conlab.font = ZCUIFont12;
    NSString *sting = @"--";
    if(zcLibConvertToString(model.remark).length > 0){
        sting = zcLibConvertToString(model.remark);
    }
    
    NSString *lanStr = ZCSTLocalString(@"评语");
    
    conlab.text = [NSString stringWithFormat:@"lanStr：%@",lanStr,sting];
    
    [_footView addSubview:conlab];
    
    // 线条
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(ZCNumber(0), 0, ScreenWidth, 10)];
    lineView.backgroundColor = UIColorFromRGB(0xF8F9FA);
    [_footView addSubview:lineView];
    
    
    return _footView;
}




-(NSString *)filterHtmlImage:(NSString *)tmp{
    
    NSString *picStr = [NSString stringWithFormat:@"[%@]",ZCSTLocalString(@"图片")];
    
    NSRegularExpression *regularExpression = [NSRegularExpression regularExpressionWithPattern:@"<img.*?/>" options:0 error:nil];
    tmp  = [regularExpression stringByReplacingMatchesInString:tmp options:0 range:NSMakeRange(0, tmp.length) withTemplate:picStr];
    
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<br />" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<br/>" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<br>" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<BR/>" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<BR />" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<p>" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"</p>" withString:@" "];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"&nbsp;" withString:@" "];
    while ([tmp hasPrefix:@"\n"]) {
        tmp=[tmp substringWithRange:NSMakeRange(1, tmp.length-1)];
    }
    return tmp;
    
}
//-(void) actionSheetItemClick:(NSNotification *)sender{
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            NSLog(@"指定刷新页面");
//            [self loadData];
//        });
//}
-(void) actionSheetClick:(int) isCommentType{
    [[ZCUIToastTools shareToast] showProgress:@"" with:self.view];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"指定刷新页面");
        [self loadData];
    });
}

#pragma delegate
// 赋值的时候，不执行
-(void)ratingChanged:(float)newRating{

}

-(void)ratingChangedWithTap:(float)newRating{
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
