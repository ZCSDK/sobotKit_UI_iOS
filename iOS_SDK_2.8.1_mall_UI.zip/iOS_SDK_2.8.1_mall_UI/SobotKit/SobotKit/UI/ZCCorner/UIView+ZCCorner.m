//
//  UIView+zcCorner.m
//  zcCorner
//
//  Created by 秦琦 on 2018/10/24.
//  Copyright © 2018 QinQi. All rights reserved.
//

#import "UIView+ZCCorner.h"
#import "CALayer+ZCCorner.h"
#import "ZCCornerModel.h"

@implementation UIView (ZCCorner)

- (void)updateCornerRadius:(void (^)(ZCCorner *))handler {
    if (handler) {
        handler(self.layer.zc_corner);
    }
    if (!self.layer.zc_corner.fillColor || CGColorEqualToColor(self.layer.zc_corner.fillColor.CGColor, [UIColor clearColor].CGColor)) {
        if (CGColorEqualToColor(self.backgroundColor.CGColor, [UIColor clearColor].CGColor)) {
            if (!self.layer.zc_corner.borderColor || CGColorEqualToColor(self.layer.zc_corner.borderColor.CGColor, [UIColor clearColor].CGColor)) {
                return;
            }
        }
        
    }
    [self.layer updateCornerRadius:handler];
}

-  (void)setInsideColor:(UIColor *)insideColor{
    self.layer.zc_corner.fillColor = insideColor?insideColor:self.backgroundColor;
}

@end
