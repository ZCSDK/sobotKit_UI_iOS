

#import <Foundation/Foundation.h>

struct ZCRadius {
    CGFloat upLeft; //The radius of upLeft. 左上半径
    CGFloat upRight;    //The radius of upRight.    右上半径
    CGFloat downLeft;   //The radius of downLeft.   左下半径
    CGFloat downRight;  //The radius of downRight.  右下半径
};
typedef struct ZCRadius ZCRadius;

static ZCRadius const ZCRadiusZero = (ZCRadius){0, 0, 0, 0};

NS_INLINE bool ZCRadiusIsEqual(ZCRadius radius1, ZCRadius radius2) {
    return radius1.upLeft == radius2.upLeft && radius1.upRight == radius2.upRight && radius1.downLeft == radius2.downLeft && radius1.downRight == radius2.downRight;
}

NS_INLINE ZCRadius ZCRadiusMake(CGFloat upLeft, CGFloat upRight, CGFloat downLeft, CGFloat downRight) {
    ZCRadius radius;
    radius.upLeft = upLeft;
    radius.upRight = upRight;
    radius.downLeft = downLeft;
    radius.downRight = downRight;
    return radius;
}

NS_INLINE ZCRadius ZCRadiusMakeSame(CGFloat radius) {
    ZCRadius result;
    result.upLeft = radius;
    result.upRight = radius;
    result.downLeft = radius;
    result.downRight = radius;
    return result;
}


typedef NS_ENUM(NSUInteger, ZCGradualChangeType) {
    ZCGradualChangeTypeUpLeftToDownRight = 0,
    ZCGradualChangeTypeUpToDown,
    ZCGradualChangeTypeLeftToRight,
    ZCGradualChangeTypeUpRightToDownLeft
};


@interface ZCGradualChangingColor : NSObject

@property (nonatomic, strong) UIColor *fromColor;
@property (nonatomic, strong) UIColor *toColor;
@property (nonatomic, assign) ZCGradualChangeType type;

@end


@interface ZCCorner : NSObject

/**The radiuses of 4 corners.   4个圆角的半径*/
@property (nonatomic, assign) ZCRadius radius;
/**The color that will fill the layer/view. 将要填充layer/view的颜色*/
@property (nonatomic, strong) UIColor *fillColor;
/**The color of the border. 边框颜色*/
@property (nonatomic, strong) UIColor *borderColor;
/**The lineWidth of the border. 边框宽度*/
@property (nonatomic, assign) CGFloat borderWidth;

@end
