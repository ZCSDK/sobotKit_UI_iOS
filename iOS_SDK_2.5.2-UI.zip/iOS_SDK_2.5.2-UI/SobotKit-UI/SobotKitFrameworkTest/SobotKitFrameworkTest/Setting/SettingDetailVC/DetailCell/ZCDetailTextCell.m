//
//  ZCDetailTextCell.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/21.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCDetailTextCell.h"

@interface ZCDetailTextCell()<UITextFieldDelegate>{
    
}

@property (nonatomic,strong) NSMutableDictionary * dict;

@end

@implementation ZCDetailTextCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
 
    
    CGRect textF = _textField.frame;
    textF.size.width = ScreenWidth - 20;
    textF.origin.x = 10;
    _titleLab.numberOfLines = 1;
    _textField.frame = textF;
    _textField.layer.borderColor = [UIColor clearColor].CGColor;
    [_textField addTarget:self action:@selector(textValueChange:) forControlEvents:UIControlEventEditingChanged];
    _textField.layer.borderColor = [UIColor clearColor].CGColor;
    _textField.delegate = self;
}

-(void)initWithDict:(NSDictionary *)dict{
//    _textField.text = dict[@"dictValue"];
    [_textField setText:dict[@"dictValue"]];
    _titleLab.text = dict[@"dictName"];
    _textField.placeholder = dict[@"placeholder"];
    // 重新计算cell的高度
    _dict  = [NSMutableDictionary dictionaryWithDictionary:dict];
    [self getTextRectWith:dict[@"dictName"] WithMaxWidth:130 WithlineSpacing:6 AddLabel:_titleLab];
//    _titleLab.backgroundColor = UIColorFromRGB(0x666666);
    CGRect textFieldF = _textField.frame;
    textFieldF.origin.x = 160;
    textFieldF.size.width = ScreenWidth - 170;
    ;
    _textField.frame = textFieldF;
    self.frame = CGRectMake(0, 0, ScreenWidth, CGRectGetHeight(_titleLab.frame) + 20);
}

-(void)textValueChange:(UITextField *)textfield{
//    if (_textValueBlock) {
//        _textValueBlock(textfield.text);
//    }
    _dict[@"dictValue"] = textfield.text;
    if (_delegate && [_delegate respondsToSelector:@selector(textValueChange:WithDict:)]) {
        [_delegate textValueChange:textfield WithDict:_dict];
    }
    
}


#pragma mark -- textfield delegate


- (void)textFieldDidBeginEditing:(UITextField *)textField{
    
    if (_delegate && [_delegate respondsToSelector:@selector(markPiontActionWithTextField:)]) {
        [_delegate markPiontActionWithTextField:textField];
    }
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    if (_delegate && [_delegate respondsToSelector:@selector(changePiontAction:)]) {
        [_delegate changePiontAction:textField];
    }
    [textField resignFirstResponder];
    return YES;
}



-(BOOL)textFieldShouldClear:(UITextField *)textField{
    
    return YES;
}


-(CGRect)getTextRectWith:(NSString *)str WithMaxWidth:(CGFloat)width  WithlineSpacing:(CGFloat)LineSpacing AddLabel:(UILabel *)label{
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc]initWithString:str];
    NSMutableParagraphStyle * parageraphStyle = [[NSMutableParagraphStyle alloc]init];
    [parageraphStyle setLineSpacing:LineSpacing];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:parageraphStyle range:NSMakeRange(0, [str length])];
    [attributedString addAttribute:NSFontAttributeName value:label.font range:NSMakeRange(0, str.length)];
    
    label.attributedText = attributedString;
    
    CGSize size = [self autoHeightOfLabel:label with:width];
    
    CGRect labelF = label.frame;
    labelF.size.height = size.height;
    label.frame = labelF;
    
    
    return labelF;
}

/**
 计算Label高度
 
 @param label 要计算的label，设置了值
 @param width label的最大宽度
 @param type 是否从新设置宽，1设置，0不设置
 */
- (CGSize )autoHeightOfLabel:(UILabel *)label with:(CGFloat )width{
    //Calculate the expected size based on the font and linebreak mode of your label
    // FLT_MAX here simply means no constraint in height
    CGSize maximumLabelSize = CGSizeMake(width, FLT_MAX);
    
    CGSize expectedLabelSize = [label sizeThatFits:maximumLabelSize];// 返回最佳的视图大小
    
    //adjust the label the the new height.
    CGRect newFrame = label.frame;
    newFrame.size.height = expectedLabelSize.height;
    label.frame = newFrame;
    [label updateConstraintsIfNeeded];
    
    return expectedLabelSize;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
