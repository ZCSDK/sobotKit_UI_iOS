//
//  ZCSettingGoodVC.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/22.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SobotKit/SobotKit.h>

@interface ZCSettingGoodVC : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *goodsTitleTF;
@property (weak, nonatomic) IBOutlet UITextField *goodsSummaryTF;
@property (weak, nonatomic) IBOutlet UITextField *goodTagTF;
@property (weak, nonatomic) IBOutlet UITextField *thumbUrl;
@property (weak, nonatomic) IBOutlet UITextField *link;

@property (nonatomic,strong) ZCKitInfo *uiInfo;
@property (weak, nonatomic) IBOutlet UIScrollView *bgScrollView;

@end
