//
//  ZCSettingGoodVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/22.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCSettingGoodVC.h"
#import "ZCDetailTextCell.h"
#define cellSetIdentifier @"ZCDetailTextCell"
@interface ZCSettingGoodVC ()<UITableViewDelegate,UITableViewDataSource,ZCDetailTextCellDelegate>{
    CGPoint        contentoffset;// 记录cell的相对坐标
    NSString *gimg_Text;
    NSString *gimg_TitleText;
    NSString *gsend_Text;
    NSString *glabel_Text;
    NSString *gPageUrl_Text;
}

@property (nonatomic,strong) NSMutableArray * listArray;

@property (nonatomic,strong) UITableView * listTable;


@end

@implementation ZCSettingGoodVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.bgScrollView.backgroundColor = UIColorFromRGB(0xEFF3FA);
    [self createNavc];
//    [self addProductInfo];
    _listArray = [NSMutableArray arrayWithCapacity:0];
    [self createTableView];
    [self loadData];
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hideKeyBoard)];
    [self.view addGestureRecognizer:tap];
}

-(void)createTableView{
    _listTable = [[UITableView alloc]initWithFrame:CGRectMake(0, NavBarHeight, ScreenHeight, ScreenHeight - NavBarHeight) style:UITableViewStylePlain];
    _listTable.delegate = self;
    _listTable.dataSource = self;
    [self.view addSubview:_listTable];
    
    // 注册cell
    [_listTable registerNib:[UINib nibWithNibName:cellSetIdentifier bundle:nil] forCellReuseIdentifier:cellSetIdentifier];
    
    UIView * footView = [[UIView alloc]initWithFrame:CGRectMake(0, 1, ScreenWidth, ScreenHeight - NavBarHeight - 44*5)];
    footView.backgroundColor = UIColorFromRGB(0xEFF3FA);
    _listTable.tableFooterView = footView;
    
    [_listTable setSeparatorColor:UIColorFromRGB(0xdadada)];
    [_listTable setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    [self setTableSeparatorInset];
}

-(void)loadData{
    // @"cellType"   0 默认状态  1，右边添加选中的箭头   2单选样式
    [_listArray removeAllObjects];
    
    if(ZCUserDefaultsGetValue(@"goods_IMG") != nil){
        gimg_Text = ZCUserDefaultsGetValue(@"goods_IMG");
    }else{
        // 设置默认值
        gimg_Text = @"http://gtb.baidu.com/HttpService/get?p=dHlwZT1pbWFnZS9qcGVnJm49dmlzJnQ9YWRpbWcmYz10YjppZyZyPTM2MzI4MTA4MCw0MjcwMDE0NjkAa38";
        ZCZCUserDefaultsSetValue(gimg_Text, @"goods_IMG");
    }
    if(ZCUserDefaultsGetValue(@"goods_Title") != nil){
        gimg_TitleText = ZCUserDefaultsGetValue(@"goods_Title");
    }else{
        // 设置默认值
        gimg_TitleText = @"我是要显示饿标题我是要显示饿标题我是要显示饿标题我是要最多显示三行";
         ZCZCUserDefaultsSetValue(gimg_TitleText, @"goods_Title");
    }
    if(ZCUserDefaultsGetValue(@"goods_SENDMGS")!= nil){
        gsend_Text = ZCUserDefaultsGetValue(@"goods_SENDMGS");
    }else{
        // 设置默认值
        gsend_Text = @"摘要描述内容 http://www.baidu.com 你好";
        ZCZCUserDefaultsSetValue(gsend_Text, @"goods_SENDMGS");
    }
    
    if (ZCUserDefaultsGetValue(@"glabel_Text") !=nil) {
        glabel_Text = ZCUserDefaultsGetValue(@"glabel_Text");
    }else{
        glabel_Text = @"300元";
         ZCZCUserDefaultsSetValue(glabel_Text, @"glabel_Text");
    }
    
    if (ZCUserDefaultsGetValue(@"gPageUrl_Text") !=nil) {
        gPageUrl_Text = ZCUserDefaultsGetValue(@"gPageUrl_Text");
    }else{
        gPageUrl_Text = @"https://api.sobot.com";
        ZCZCUserDefaultsSetValue(gPageUrl_Text, @"gPageUrl_Text");
    }
    
    [_listArray addObject:@{@"code":@"221",
                            @"dictName":@"标题",
                            @"dictDesc":@"goods_Title",
                            @"placeholder":@"请输入商品标题",
                            @"dictValue":gimg_TitleText,
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}
                            }];
    
    [_listArray addObject:@{@"code":@"222",
                            @"dictName":@"摘要",
                            @"dictDesc":@"goods_SENDMGS",
                            @"placeholder":@"请输入摘要",
                            @"dictValue":gsend_Text,
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}
                            }];
    [_listArray addObject:@{@"code":@"223",
                            @"dictName":@"发送链接",
                            @"dictDesc":@"gPageUrl_Text",
                            @"placeholder":@"请输入发送链接",
                            @"dictValue":gPageUrl_Text,
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}
                            }];
    [_listArray addObject:@{@"code":@"224",
                            @"dictName":@"标签",
                            @"dictDesc":@"glabel_Text",
                            @"placeholder":@"请输入标签",
                            @"dictValue":glabel_Text,
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}
                            }];
    [_listArray addObject:@{@"code":@"225",
                            @"dictName":@"图片链接",
                            @"dictDesc":@"goods_IMG",
                            @"placeholder":@"请输入图片链接",
                            @"dictValue":gimg_Text,
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}
                            }];
    [_listTable reloadData];
}



-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _listArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ZCDetailTextCell * cell = (ZCDetailTextCell*)[tableView dequeueReusableCellWithIdentifier:cellSetIdentifier];
    if (cell == nil) {
        cell =[[ZCDetailTextCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellSetIdentifier];
    }
    
    NSDictionary * dic = _listArray[indexPath.row];
    cell.delegate = self;
    [cell initWithDict:dic];
//    cell.textValueBlock = ^(NSString *textValue) {
//        ZCZCUserDefaultsSetValue(textValue,dic[@"dictDesc"]);
//    };
    return cell;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    return nil;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    return  nil;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}


-(void)textValueChange:(UITextField *)textValue WithDict:(NSDictionary *)dict{
    ZCZCUserDefaultsSetValue(textValue.text, dict[@"dictDesc"]);
    NSMutableDictionary * Dict  = _listArray[[dict[@"code"] intValue]-221];
    Dict = [NSMutableDictionary dictionaryWithDictionary:dict];
    _listArray[[dict[@"code"] intValue]-221] = Dict;
    // 添加中间变量，处理cell 重用时的 还原问题
    switch ([dict[@"code"] intValue]) {
        case 221:{
            gimg_TitleText = textValue.text;
        }
            
            break;
        case 222:{
            gsend_Text = textValue.text;
        }
            
            break;
        case 223:{
            gPageUrl_Text = textValue.text;
        }
            
            break;
        case 224:{
            glabel_Text = textValue.text;
        }
            
            break;
        case 225:{
            gimg_Text = textValue.text;
        }
            break;
       
        default:
            break;
    }
}


-(void)createNavc{
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"商品信息";

//    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:19],NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    [leftBtn setTitleColor:UIColorFromRGB(0x39B9C2) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 0);
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    
    UIButton * rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(ScreenWidth - 60, NavBarHeight - 40, 50, 40);
    [rightBtn setTitle:@"保存" forState:UIControlStateNormal];
    rightBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [rightBtn addTarget:self action:@selector(saveAction:) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setTitleColor:UIColorFromRGB(0x39B9C2) forState:UIControlStateNormal];
    UIBarButtonItem * rightItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    
    self.navigationItem.rightBarButtonItem = rightItem;
}

-(void)backAction:(UIButton*)sender{
    [self hideKeyBoard];
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)saveAction:(UIButton *)sender{
    [self hideKeyBoard];
    [self.navigationController popViewControllerAnimated:YES];
}

// 处理键盘的代理事件
- (void) markPiontActionWithTextField:(UITextField *)textField{
    
    NSIndexPath *indexpath=[_listTable indexPathForCell:((ZCDetailTextCell *)textField.superview.superview) ];
    
    //获取当前cell在tableview中的位置
    CGRect rectintableview=[_listTable rectForRowAtIndexPath:indexpath];
    
    //获取当前cell在屏幕中的位置
    CGRect rectinsuperview = [_listTable convertRect:rectintableview fromView:[_listTable superview]];
    
    contentoffset.x = _listTable.contentOffset.x;
    
    contentoffset.y = _listTable.contentOffset.y;
    
    if ((rectinsuperview.origin.y+50 - _listTable.contentOffset.y)>200) {
        
        [_listTable setContentOffset:CGPointMake(_listTable.contentOffset.x,((rectintableview.origin.y-_listTable.contentOffset.y)-150)+  _listTable.contentOffset.y) animated:YES];
        
    }
    
}

- (void)changePiontAction:(UITextField*)textField{
    [_listTable setContentOffset:CGPointMake(contentoffset.x,contentoffset.y) animated:YES];
}

/**
 *  设置UITableView分割线空隙
 */
-(void)setTableSeparatorInset{
    UIEdgeInsets inset = UIEdgeInsetsMake(0, 10, 0, 0);
    if ([_listTable respondsToSelector:@selector(setSeparatorInset:)]) {
        [_listTable setSeparatorInset:inset];
    }
    
    if ([_listTable respondsToSelector:@selector(setLayoutMargins:)]) {
        [_listTable setLayoutMargins:inset];
    }
}


//设置分割线间距
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    if((indexPath.row+1) < _listArray.count){
        UIEdgeInsets inset = UIEdgeInsetsMake(0, 10, 0, 0);
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
            [cell setSeparatorInset:inset];
        }
        
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:inset];
        }
    }
}


//去掉UItableview headerview黏性
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == self.listTable)
    {
        CGFloat sectionHeaderHeight = 50;
        if (scrollView.contentOffset.y<=sectionHeaderHeight&&scrollView.contentOffset.y>=0) {
            scrollView.contentInset = UIEdgeInsetsMake(-scrollView.contentOffset.y, 0, 0, 0);
        } else if (scrollView.contentOffset.y>=sectionHeaderHeight) {
            scrollView.contentInset = UIEdgeInsetsMake(-sectionHeaderHeight, 0, 0, 0);
        }
    }
}

#pragma mark -- 全局回收键盘
- (void)hideKeyBoard
{
    for (UIWindow* window in [UIApplication sharedApplication].windows)
    {
        for (UIView* view in window.subviews)
        {
            [self dismissAllKeyBoardInView:view];
        }
    }
}

-(BOOL) dismissAllKeyBoardInView:(UIView *)view
{
    if([view isFirstResponder])
    {
        [view resignFirstResponder];
        return YES;
    }
    for(UIView *subView in view.subviews)
    {
        if([self dismissAllKeyBoardInView:subView])
        {
            return YES;
        }
    }
    return NO;
}
@end
