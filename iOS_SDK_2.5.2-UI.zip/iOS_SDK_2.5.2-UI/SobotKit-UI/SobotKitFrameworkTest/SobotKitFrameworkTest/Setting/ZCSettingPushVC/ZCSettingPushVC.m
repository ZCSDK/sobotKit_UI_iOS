//
//  ZCSettingPushVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCSettingPushVC.h"

@interface ZCSettingPushVC ()<UIAlertViewDelegate>

@end

@implementation ZCSettingPushVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setNavc];
    [self addlayoutSubviews];
    self.bgScrollView.backgroundColor = UIColorFromRGB(0xEFF3FA);
    self.toplineView.backgroundColor = UIColorFromRGB(0xdadada);
    self.bottomLineView.backgroundColor = UIColorFromRGB(0xdadada);
    CGRect toplineF = self.toplineView.frame;
    toplineF.size.height = 0.5f;
    self.toplineView.frame = toplineF;
    
    CGRect botLineF = self.bottomLineView.frame;
    botLineF.size.height = 0.5f;
    self.bottomLineView.frame = botLineF;
}


-(void)setNavc{
    self.title = @"推送";
    
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    
    
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    [leftBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 0);
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
}

-(void)addlayoutSubviews{
    _isAutoTipSwitch.on = NO;
    _isOpenOffLineMsg.on = NO;
//    if ([ZCLibClient getZCLibClient].autoNotification) {
//        _isAutoTipSwitch.on = YES;
//    }
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"autoNotification"]) {
        _isAutoTipSwitch.on = [[NSUserDefaults standardUserDefaults] boolForKey:@"autoNotification"];
    }
//    [[ZCLibClient getZCLibClient] setAutoNotification:_isAutoTipSwitch.on];
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"isopenLineMsg"]) {
        _isOpenOffLineMsg.on = [[NSUserDefaults standardUserDefaults] boolForKey:@"isopenLineMsg"];
    }
    
    
    
    _isAutoTipSwitch.tag = 301;
    _isOpenOffLineMsg.tag = 302;
    [_isAutoTipSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [_isOpenOffLineMsg addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    
}

-(void)switchValueChanged:(UISwitch*)sender{
    switch (sender.tag) {
        case 301:
            if (sender.on) {
//                [[ZCLibClient getZCLibClient] setAutoNotification:YES];
                [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"autoNotification"];
            }else{
//                [[ZCLibClient getZCLibClient] setAutoNotification:NO];
                [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"autoNotification"];
            }
            break;
        case 302:
            if (sender.on) {
                [ZCLibClient getZCLibClient].receivedBlock=^(id obj,int unRead,NSDictionary *object){
                    NSLog(@"未读消息数量：\n%d,%@",unRead,obj);
                };
                [[NSUserDefaults standardUserDefaults]setBool:YES forKey:@"isopenLineMsg"];
            }else{
               [ZCLibClient  closeAndoutZCServer:YES];
                [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"isopenLineMsg"];
            }
            break;
        default:
            break;
    }
}


-(void)backAction:(UIButton*)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonClickAction:(id)sender {
     [ZCLibClient closeAndoutZCServer:YES];
    UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"已关闭推送" message:@"" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    alertView.delegate = self;
    [alertView show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    _isAutoTipSwitch.on = NO;
    _isOpenOffLineMsg.on = NO;
}

@end
