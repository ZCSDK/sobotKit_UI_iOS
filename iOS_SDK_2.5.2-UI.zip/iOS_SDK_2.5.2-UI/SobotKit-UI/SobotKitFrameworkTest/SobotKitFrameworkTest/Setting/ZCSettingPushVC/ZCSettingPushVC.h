//
//  ZCSettingPushVC.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCSettingPushVC : UIViewController
@property (weak, nonatomic) IBOutlet UISwitch *isAutoTipSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *isOpenOffLineMsg;

@property (weak, nonatomic) IBOutlet UIScrollView *bgScrollView;

@property (weak, nonatomic) IBOutlet UIView *toplineView;

@property (weak, nonatomic) IBOutlet UIView *bottomLineView;

@end
