//
//  ZCSkillSetVC.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCSkillSetVC : UIViewController
//@property (weak, nonatomic) IBOutlet UITextField *skillSetId;
//
//@property (weak, nonatomic) IBOutlet UITextField *skillSetName;
@property (weak, nonatomic) IBOutlet UIScrollView *bgScrollView;

@end
