//
//  ZCSettingGuideVC.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/22.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^PassWordBlock)(ZCLibInitInfo *libInitInfo);

@interface ZCSettingGuideVC : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *customRobotHelloWord;



@property (weak, nonatomic) IBOutlet UITextField *customAdminHelloWord;

@property (weak, nonatomic) IBOutlet UITextField *customAdminNonelineTitle;

@property (weak, nonatomic) IBOutlet UITextField *customUserTipWord;

@property (weak, nonatomic) IBOutlet UITextField *customUserOutWord;

@property (weak, nonatomic) IBOutlet UITextField *customAdminTipWord;

@property (weak, nonatomic) IBOutlet UITextField *hotGuideWord;

@property (nonatomic,copy)PassWordBlock passWorkBlock;
@property (weak, nonatomic) IBOutlet UIScrollView *bgScrollView;

@end
