//
//  ZCSetServiceTypeVC.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/22.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^RefreshValueBlock)();

@interface ZCSetServiceTypeVC : UIViewController
@property (weak, nonatomic) IBOutlet UISwitch *robotPreferredSwitch;

@property (weak, nonatomic) IBOutlet UISwitch *artificialPrioritySwitch;

@property (weak, nonatomic) IBOutlet UISwitch *onlyServiceSwitch;

@property (weak, nonatomic) IBOutlet UISwitch *onlyRobotSwitch;

@property (nonatomic,assign) int type;

@property (nonatomic,copy) RefreshValueBlock  refreshValueBlock;
@property (weak, nonatomic) IBOutlet UIScrollView *bgScrollView;

@property (weak, nonatomic) IBOutlet UIView *topLineView;

@property (weak, nonatomic) IBOutlet UIView *midLineView;
@property (weak, nonatomic) IBOutlet UIView *bottomLineView;


@end
