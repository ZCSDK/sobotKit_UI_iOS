//
//  PlatformTestController.m
//  SobotKitFrameworkTest
//
//  Created by zhangxy on 2017/9/5.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "PlatformTestController.h"
#import <SobotKit/SobotKit.h>
#import "ViewController.h"

@interface PlatformTestController (){
    BOOL  isPlatformUnion;
}

@end

@implementation PlatformTestController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //     [self hideTabBar:YES];
    self.navigationController.toolbarHidden = YES;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
#pragma mark 设置默认APPKEY
    NSString *appKey_Text = [[NSUserDefaults standardUserDefaults] valueForKey:@"appKey_Text"];

   
    _textAppkey.text = appKey_Text;
    
    _textUserId.text=@"";
    
    _switView.on = NO;
//    _textApiHost.text = @"http://test.sobot.com";
    
    
    self.title = @"智齿SDK平台版本";
    
    
    
    UIGestureRecognizer *tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapAnywhere1:)];
    [self.view addGestureRecognizer:tap];
    
}


//屏幕点击事件
- (void)didTapAnywhere1:(UITapGestureRecognizer *)recognizer {
    [_textAppkey resignFirstResponder];
    [_textUserId resignFirstResponder];
    [_textApiHost resignFirstResponder];
    
    
}


-(IBAction)startPlatformServer:(id)sender{
    
    [ZCLibClient getZCLibClient].platformUnionCode = @"1234";
    [[ZCLibClient getZCLibClient] initSobotSDK:@"1ff3e4ff91314f5ca308e19570ba24bb"];
    
    //  初始化配置信息
    ZCLibInitInfo *initInfo = [ZCLibInitInfo new];
    initInfo.appKey = @"1ff3e4ff91314f5ca308e19570ba24bb";
//    initInfo.userId = @"111111";
    // 获取AppKey
//    initInfo.appKey = _textAppkey.text;
//    initInfo.userId = _textUserId.text;
//    initInfo.userId = @"569";
    
    [[ZCLibClient getZCLibClient] setLibInitInfo:initInfo];
    
    
    ZCKitInfo *uiInfo=[ZCKitInfo new];
//    uiInfo.apiHost =_textApiHost.text;
    
    uiInfo.topViewTextColor = [UIColor redColor];
    // 测试模式
    [ZCSobot setShowDebug:YES];
    
    
    // 启动
//    [ZCSobot startZCChatView:uiInfo with:self target:nil pageBlock:^(ZCUIChatController *object, ZCPageBlockType type) {
//        // 点击返回
//        if(type==ZCPageBlockGoBack){
//            NSLog(@"点击了关闭按钮");
//            // 显示导航栏
//        }
//
//        // 页面UI初始化完成，可以获取UIView，自定义UI
//        if(type==ZCPageBlockLoadFinish){
//        }
//
//    } messageLinkClick:nil];
    
    [ZCSobot startZCChatVC:uiInfo with:self target:nil pageBlock:^(ZCChatController *object, ZCPageBlockType type) {
        
    } messageLinkClick:nil];
    
}


-(IBAction)startListServer:(id)sender{
    ZCLibInitInfo *info = [ZCLibClient getZCLibClient].libInitInfo;
    if(!info){
        info = [ZCLibInitInfo new];
    }
//    info.userId = _textUserId.text;
    [[ZCLibClient getZCLibClient] setLibInitInfo:info];
    
    ZCKitInfo *uiInfo=[ZCKitInfo new];
//    uiInfo.apiHost =//_textApiHost.text;
//    uiInfo.socketStatusButtonBgColor = [UIColor redColor];
    uiInfo.customBannerColor = [UIColor redColor];
    
    [ZCSobot startZCChatListView:uiInfo with:self];
}

-(IBAction)swValueChange:(UISwitch *)sender{
    if(sender.on){
        _textApiHost.text = @"https://api.sobot.com";
    }else{
        _textApiHost.text = @"http://test.sobot.com";
    }
}

-(IBAction)cloaseAPP:(id)sender{
    [ZCLibClient closeAndoutZCServer:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
