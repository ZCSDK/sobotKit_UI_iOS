//
//  ZCTextGuideCell.h
//  SobotKit
//
//  Created by lizhihui on 2018/6/28.
//  Copyright © 2018年 zhichi. All rights reserved.
//

#import "ZCChatBaseCell.h"

@interface ZCTextGuideCell : ZCChatBaseCell

@end
