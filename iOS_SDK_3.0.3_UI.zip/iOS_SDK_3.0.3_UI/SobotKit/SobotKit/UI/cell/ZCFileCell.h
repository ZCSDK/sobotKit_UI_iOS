//
//  ZCFileCell.h
//  SobotKit
//
//  Created by zhangxy on 2018/11/13.
//  Copyright © 2018年 zhichi. All rights reserved.
//

#import "ZCChatBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZCFileCell : ZCChatBaseCell

-(void)setProgress:(CGFloat) progress;

@end

NS_ASSUME_NONNULL_END
