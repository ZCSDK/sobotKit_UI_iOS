//
//  ZCCallIntroduceVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/12/8.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCCallIntroduceVC.h"
#import "ZCRobotIntroduceView.h"
#import "ZCNSuserdefaultdManager.h"

@interface ZCCallIntroduceVC (){
    
}

@property (nonatomic,strong) UIScrollView * scrollView;

@property (nonatomic ,strong) UILabel * titleLab;

@property (nonatomic,strong) UILabel * detailLab;

@property (nonatomic,strong) ZCRobotIntroduceView *robotView;

@end

@implementation ZCCallIntroduceVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"云呼叫中心";
    [self.navigationController setToolbarHidden:YES animated:NO];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    //    [leftBtn setTitleColor:UIColorFromRGB(0x39B9C2) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    //    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    
    [self setupUI];
}
-(void)backAction:(UIButton *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)setupUI{
    
    CGFloat itemH = 0;
    if (ZC_iPhoneX) {
        itemH = 34;
    }
    self.scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, NavBarHeight, ScreenWidth, ScreenHeight - NavBarHeight - 50 -itemH)];
    self.scrollView.backgroundColor = [UIColor clearColor];
    self.scrollView.scrollEnabled = YES;
    self.scrollView.alwaysBounceVertical = YES;
    self.scrollView.alwaysBounceHorizontal = NO;
    self.scrollView.showsVerticalScrollIndicator = NO;
    self.scrollView.bounces = NO;
    self.scrollView.userInteractionEnabled = YES;
    [self.view addSubview:self.scrollView];
    
    
    self.titleLab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), ZCNumber(21), ScreenWidth - ZCNumber(40), 25)];
    self.titleLab.textAlignment = NSTextAlignmentLeft;
    self.titleLab.text = @"稳定、强大的云呼叫中心";
    self.titleLab.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:18];
    //    self.titleLab.textColor = UIColorFromRGB(0x3D4966);
    [self.scrollView addSubview:self.titleLab];
    
    self.detailLab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(self.titleLab.frame) + 6, ScreenWidth - ZCNumber(40), 17)];
    self.detailLab.text = @"三大运营商深度合作、线路直连，海量号码，音质清晰";
    self.detailLab.textColor = UIColorFromRGB(0xBDC3D1);
    self.detailLab.font = [UIFont systemFontOfSize:12];
    [self.scrollView addSubview:_detailLab];
    
    // call_1
    UIImageView * call_1 = [[UIImageView alloc]initWithFrame:CGRectMake(ZCNumber(38), CGRectGetMaxY(self.detailLab.frame ) + ZCNumber(37), ScreenWidth - ZCNumber(38*2), ZCNumber(57))];
    call_1.image = [UIImage imageNamed:@"call_1"];
    call_1.contentMode = UIViewContentModeScaleAspectFit;
    [self.scrollView addSubview:call_1];
    
    // title1
    UILabel * title_1 = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(call_1.frame)+ ZCNumber(20), ScreenWidth - ZCNumber(40), 24)];
    title_1.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:14];
    //        self.titleLab.textColor = UIColorFromRGB(0x3D4966);
    title_1.textAlignment = NSTextAlignmentLeft;
    title_1.text = @"1.四大产品优势";
    [self.scrollView addSubview:title_1];
    
    
    NSArray * arr1 = @[@"·丰富的线路接入，快速便捷部署，上手即用0培训",
                       @"·三大运营商战略合作",
                       @"·业内最详尽的监测体系+智能管理+数据报表，全面提升管理效率",
                       @"·与智能机器人客服/人工在线客服/工单系统完美地融合，共享云客户中心，一站式解决客服问题"];
    
    CGFloat  height  = [self createTitleArr:arr1 WithView:self.scrollView Height:CGRectGetMaxY(title_1.frame) + 10];
    
    
    // call_2
    UIImageView * call_2 = [[UIImageView alloc]initWithFrame:CGRectMake(ZCNumber(20), height+ZCNumber(58), ScreenWidth - ZCNumber(40), ZCNumber(160))];
    call_2.image = [UIImage imageNamed:@"call_2"];
    call_2.contentMode = UIViewContentModeScaleAspectFit;
    [self.scrollView addSubview:call_2];
    
    
    // title_2
    UILabel * title_2 = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), CGRectGetMaxY(call_2.frame)+ ZCNumber(20), ScreenWidth - ZCNumber(40), 20)];
    title_2.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:14];
    title_2.textAlignment = NSTextAlignmentLeft;
    title_2.text = @"2.服务/电销双管齐下，为呼叫中心量身打造";
    [self.scrollView addSubview:title_2];
    
    NSArray * arr2 = @[@"·云客服，提升客户满意度"];
    
    CGFloat height2 = [self createTitleArr:arr2 WithView:self.scrollView Height:CGRectGetMaxY(title_2.frame) + 10];
    
    
    // call_3
    UIImageView * call_3 = [[UIImageView alloc]initWithFrame:CGRectMake(ZCNumber(20), height2+ZCNumber(10), ScreenWidth - ZCNumber(40), ZCNumber(360))];
    call_3.image = [UIImage imageNamed:@"call_3"];
    call_3.contentMode = UIViewContentModeScaleAspectFit;
    [self.scrollView addSubview:call_3];
    
    NSArray * arr3 = @[@"·云客服，提升客户满意度"];
    CGFloat height3 = [self createTitleArr:arr3 WithView:self.scrollView Height:CGRectGetMaxY(call_3.frame) + 20];
    
    
    // call_4
    
    UIImageView * call_4 = [[UIImageView alloc]initWithFrame:CGRectMake(ZCNumber(20), height3, ScreenWidth - ZCNumber(40), ZCNumber(316))];
    call_4.image = [UIImage imageNamed:@"call_4"];
    call_4.contentMode = UIViewContentModeScaleAspectFit;
    [self.scrollView addSubview:call_4];
    
    self.scrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(call_4.frame) + 60);
    
    
    //咨询客服
    [self layoutBtn];
}


#pragma mark -- 联系我们
-(void)layoutBtn{
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    CGFloat Y = ScreenHeight - 50;
    if (ZC_iPhoneX) {
        Y = ScreenHeight - 50 - 34;
    }
    btn.frame = CGRectMake(0, Y, ScreenWidth, 50);
    [btn setBackgroundColor:UIColorFromRGB(0x0DAEAF)];
    [btn setTitle:@" 咨询客服" forState:UIControlStateNormal];
    [btn setTitle:@" 咨询客服" forState:UIControlStateHighlighted];
    [btn setImage:[UIImage imageNamed:@"Online"] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:@"Online"] forState:UIControlStateHighlighted];
    [btn addTarget:self action:@selector(openSDK:) forControlEvents:UIControlEventTouchUpInside];
    
    //    btn.imageEdgeInsets = UIEdgeInsetsMake(5, btn.titleLabel.frame.origin.x - 3 - btn.imageView.frame.size.width, 5, btn.titleLabel.frame.origin.x -3);
    //    btn.type = 1;
    [self.view addSubview:btn];
}



// 循环创建 label
-(CGFloat)createTitleArr:(NSArray *)arr WithView:(UIView *)view Height:(CGFloat)height{
    
    CGFloat itemH = height;
    for (int i = 0; i<arr.count; i++) {
        UILabel * listLab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(20), itemH, ScreenWidth - ZCNumber(40), 20)];
        listLab.textAlignment = NSTextAlignmentLeft;
        listLab.text = arr[i];
        listLab.textColor = UIColorFromRGB(0x001F2A);
        listLab.numberOfLines = 0;
        listLab.font = [UIFont systemFontOfSize:14];
        [view addSubview:listLab];
        // 重新计算label的高度
        [self getTextRectWith:arr[i] WithMaxWidth:ScreenWidth - ZCNumber(40) WithlineSpacing:5 AddLabel:listLab];
        itemH  = itemH + CGRectGetHeight(listLab.frame) + 10;
    }
    
    return itemH;
    
}

-(CGRect)getTextRectWith:(NSString *)str WithMaxWidth:(CGFloat)width  WithlineSpacing:(CGFloat)LineSpacing AddLabel:(UILabel *)label{
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc]initWithString:str];
    // 文字颜色
    NSUInteger firstloc = [[attributedString string]rangeOfString:@"·"].location ;
    NSRange range = NSMakeRange(firstloc, 1);
    [attributedString addAttribute:NSForegroundColorAttributeName value:UIColorFromRGB(0x0DAEAF) range:range];
    NSMutableParagraphStyle * parageraphStyle = [[NSMutableParagraphStyle alloc]init];
    [parageraphStyle setLineSpacing:LineSpacing];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:parageraphStyle range:NSMakeRange(0, [str length])];
    [attributedString addAttribute:NSFontAttributeName value:label.font range:NSMakeRange(0, str.length)];
    
    label.attributedText = attributedString;
    
    // 这里的高度的计算，不能在按 attributedString的属性去计算了，需要拿到label中的
    CGSize size = [self autoHeightOfLabel:label with:width];
    
    CGRect labelF = label.frame;
    labelF.size.height = size.height;
    label.frame = labelF;
    
    
    return labelF;
}


/**
 计算Label高度
 
 @param label 要计算的label，设置了值
 @param width label的最大宽度
 @param type 是否从新设置宽，1设置，0不设置
 */
- (CGSize )autoHeightOfLabel:(UILabel *)label with:(CGFloat )width{
    //Calculate the expected size based on the font and linebreak mode of your label
    // FLT_MAX here simply means no constraint in height
    CGSize maximumLabelSize = CGSizeMake(width, FLT_MAX);
    
    CGSize expectedLabelSize = [label sizeThatFits:maximumLabelSize];
    
    //adjust the label the the new height.
    CGRect newFrame = label.frame;
    newFrame.size.height = expectedLabelSize.height;
    label.frame = newFrame;
    [label updateConstraintsIfNeeded];
    
    return expectedLabelSize;
}



-(void)openSDK:(UIButton*)sender{
    [ZCNSuserdefaultdManager shareUserdefaultd].type = 1;
    [[ZCNSuserdefaultdManager shareUserdefaultd] openSDKWith:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
