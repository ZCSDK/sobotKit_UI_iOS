//
//  ZCTurnServicesVC.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^PassWordkitInfoBlock)(ZCKitInfo * kitInfo);

@interface ZCTurnServicesVC : UIViewController

@property (weak, nonatomic) IBOutlet UISwitch *turnServerSwitch;

@property (weak, nonatomic) IBOutlet UITextField *robotCountLab;

@property (weak, nonatomic) IBOutlet UISwitch *isOpenTurnSwitch;

@property (weak, nonatomic) IBOutlet UITextField *turnKeyWordLab;


@property (weak, nonatomic) IBOutlet UISwitch *isOpenVideoSwitch;

@property (nonatomic,strong) ZCKitInfo * kitInfo;

@property (nonatomic,copy) PassWordkitInfoBlock passWordkitInfoBlock;
@property (weak, nonatomic) IBOutlet UIScrollView *bgScrollView;

@property (weak, nonatomic) IBOutlet UIView *toplineView;

@property (weak, nonatomic) IBOutlet UIView *rotboLineView;

@property (weak, nonatomic) IBOutlet UIView *midLineView;

@property (weak, nonatomic) IBOutlet UIView *bottomLineView;

@end
