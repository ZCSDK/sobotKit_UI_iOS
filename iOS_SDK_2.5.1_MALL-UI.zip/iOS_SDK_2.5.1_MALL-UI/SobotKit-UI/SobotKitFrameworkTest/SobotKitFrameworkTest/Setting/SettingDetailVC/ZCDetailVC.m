//
//  ZCDetailVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/21.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCDetailVC.h"
#import "ZCDetailTextCell.h"

#define  detailcellIdentifier   @"ZCDetailTextCell"


@interface ZCDetailVC ()<UITableViewDelegate,UITableViewDataSource,ZCDetailTextCellDelegate>{
    NSString  * value;
}

@property (nonatomic,strong) NSMutableArray * listArray;

@property (nonatomic,strong) UITableView * listTable;


@end

@implementation ZCDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = _titleName;
    _listArray = [NSMutableArray arrayWithCapacity:0];
     [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    
    
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    [leftBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [leftBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 0);
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    
    UIButton * rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(ScreenWidth - 60, NavBarHeight - 40, 50, 40);
    [rightBtn setTitle:@"保存" forState:UIControlStateNormal];
    rightBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [rightBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    [rightBtn addTarget:self action:@selector(saveAction:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem * rightItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    
    self.navigationItem.rightBarButtonItem = rightItem;
    
    [self createTabelView];
    [self loadData];
    
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hideKeyBoard)];
    [self.view addGestureRecognizer:tap];
}

-(void)backAction:(UIButton*)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)saveAction:(UIButton *)sender{
    
    if (_valueTextBlock) {
        _valueTextBlock();
    }
    
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)createTabelView{
    _listTable = [[UITableView alloc]initWithFrame:CGRectMake(0, NavBarHeight, ScreenWidth, ScreenHeight - NavBarHeight) style:UITableViewStylePlain];
    _listTable.backgroundColor = [UIColor clearColor];
    _listTable.delegate = self;
    _listTable.dataSource = self;
    [self.view addSubview:_listTable];
    
    [_listTable registerNib:[UINib nibWithNibName:detailcellIdentifier bundle:nil] forCellReuseIdentifier:detailcellIdentifier];
    
    UIView * footView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    footView.backgroundColor = UIColorFromRGB(0xEFF3FA);
    _listTable.tableFooterView = footView;
    
}

-(void)loadData{
    [_listArray removeAllObjects];
    value = @"";
    NSString * appkey = @"";
    NSString * apiHost = @"";
    NSString * scopeTime = @"";
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    if ([userDefaults valueForKey:@"appkey"] != nil) {
        appkey = [userDefaults valueForKey:@"appkey"];
    }
    
    if ([userDefaults valueForKey:@"apiHost"]) {
        apiHost = [userDefaults valueForKey:@"apiHost"];
    }
    
    if ([userDefaults valueForKey:@"scopeTime"]) {
        scopeTime = [userDefaults valueForKey:@"scopeTime"];
    }
    
    if ([self.code intValue] == 11) {
        value = appkey;
    }else if ([self.code intValue] == 12){
        value = apiHost;
    }else if ([self.code intValue] == 25){
        value = scopeTime;
    }
    
    [_listArray addObject:@{@"code":self.code,
                      @"dictName":self.titleName,
                      @"dictDesc":self.dictDesc,
                      @"placeholder":_placeholder,
                      @"dictValue":value,
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];

    [_listTable reloadData];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _listArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ZCDetailTextCell * cell = (ZCDetailTextCell*)[tableView dequeueReusableCellWithIdentifier:detailcellIdentifier];
    if (cell == nil) {
        cell = [[ZCDetailTextCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:detailcellIdentifier];
    }
    NSDictionary * dict = _listArray[indexPath.row];
    cell.delegate = self;
    [cell initWithDict:dict];
    
//    cell.textValueBlock = ^(NSString *textValue) {
//        NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
//        [userDefaults setValue:textValue forKey:dict[@"dictDesc"]];
//    };
    
    return cell;
}

-(void)textValueChange:(UITextField *)textValue WithDict:(NSDictionary *)dict{
    ZCZCUserDefaultsSetValue(textValue.text, dict[@"dictDesc"]);
    NSMutableDictionary * Dict  = _listArray.lastObject;
    Dict = [NSMutableDictionary dictionaryWithDictionary:dict];
    _listArray[0] = Dict;
    value = textValue.text;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [self tableView:tableView cellForRowAtIndexPath:indexPath];
    return cell.frame.size.height;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];// 取消选中
}


#pragma mark -- 全局回收键盘
- (void)hideKeyBoard
{
    for (UIWindow* window in [UIApplication sharedApplication].windows)
    {
        for (UIView* view in window.subviews)
        {
            [self dismissAllKeyBoardInView:view];
        }
    }
}

-(BOOL) dismissAllKeyBoardInView:(UIView *)view
{
    if([view isFirstResponder])
    {
        [view resignFirstResponder];
        return YES;
    }
    for(UIView *subView in view.subviews)
    {
        if([self dismissAllKeyBoardInView:subView])
        {
            return YES;
        }
    }
    return NO;
}

@end


