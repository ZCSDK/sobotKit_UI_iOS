//
//  ZCUserSettingVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCUserSettingVC.h"
#import "ZCSettingCell.h"
#import "ZCDetailVC.h"

#define cellSetIdentifier @"ZCSettingCell"
#import "UserinforMationVC.h"
@interface ZCUserSettingVC ()<UITableViewDelegate,UITableViewDataSource>{
    
}

@property (nonatomic,strong) NSMutableArray * listArray;

@property (nonatomic,strong) UITableView * listTable;

@end

@implementation ZCUserSettingVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (_listArray == nil) {
        _listArray = [NSMutableArray arrayWithCapacity:0];
    }
    [self createNavc];
    [self createTableView];
    [self loadData];
}

-(void)createNavc{
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"基本信息";
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    [leftBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 0);
    
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    
    self.navigationItem.leftBarButtonItem = leftItem;
}

-(void)backAction:(UIButton*)sender{
    [self.navigationController popViewControllerAnimated:YES];
}



-(void)createTableView{
    _listTable = [[UITableView alloc]initWithFrame:CGRectMake(0, NavBarHeight, ScreenHeight, ScreenHeight - NavBarHeight) style:UITableViewStylePlain];
    _listTable.delegate = self;
    _listTable.dataSource = self;
    [self.view addSubview:_listTable];
    
    // 注册cell
    [_listTable registerNib:[UINib nibWithNibName:cellSetIdentifier bundle:nil] forCellReuseIdentifier:cellSetIdentifier];
    
    UIView * footView = [[UIView alloc]initWithFrame:CGRectMake(0, 1, ScreenWidth, ScreenHeight)];
    footView.backgroundColor =UIColorFromRGB(0xEFF3FA);
    _listTable.tableFooterView = footView;
    
    [_listTable setSeparatorColor:UIColorFromRGB(0xdadada)];
    [_listTable setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    [self setTableSeparatorInset];
}


-(void)loadData{
    
    // @"cellType"   0 默认状态  1，右边添加选中的箭头   2单选样式
    
    [_listArray removeAllObjects];
    NSString * appkey = @"";
    NSString * api = @"";
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
    if ([userDefaults valueForKey:@"appkey"] != nil) {
        appkey = [userDefaults valueForKey:@"appkey"];
    }
    if ([userDefaults valueForKey:@"apiHost"]!= nil) {
        api = [userDefaults valueForKey:@"apiHost"];
    }
 
    
    [_listArray addObject:@{@"code":@"11",
                            @"dictName":@"appkey(必填)",
                            @"dictDesc":@"appkey",
                            @"placeholder":@"请输入appkey",
                            @"dictValue":appkey,
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}
                            }];
    
    [_listArray addObject:@{@"code":@"12",
                            @"dictName":@"服务器域名",
                            @"dictDesc":@"apiHost",
                            @"placeholder":@"请添加服务器域名，默认已设置",
                            @"dictValue":api,
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}
                            }];
    
    [_listArray addObject:@{@"code":@"13",
                            @"dictName":@"用户资料",
                            @"dictDesc":@"用户资料",
                            @"placeholder":@"",
                            @"dictValue":@"",
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}}];
    
    [_listTable reloadData];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _listArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ZCSettingCell * cell = (ZCSettingCell*)[tableView dequeueReusableCellWithIdentifier:cellSetIdentifier];
    if (cell == nil) {
        cell =[[ZCSettingCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellSetIdentifier];
    }
    
    NSDictionary * dic = _listArray[indexPath.row];
    [cell initWithNSDictionary:dic];
    
    return cell;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    return nil;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    return  nil;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [self tableView:tableView cellForRowAtIndexPath:indexPath];
    return cell.frame.size.height;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];// 取消选中
    __weak  ZCUserSettingVC  * safeVC = self;
    NSDictionary * dic =_listArray[indexPath.row];
    switch ([dic[@"code"] intValue]) {
        case 11:{
            ZCDetailVC * detailVC = [[ZCDetailVC alloc]init];
            detailVC.code = dic[@"code"];
            detailVC.titleName = dic[@"dictName"];
            detailVC.dictDesc = dic[@"dictDesc"];
            detailVC.placeholder = dic[@"placeholder"];
            detailVC.valueTextBlock = ^{
                [safeVC loadData];
            };
           
            [self.navigationController pushViewController:detailVC animated:YES];
        }
            break;
        case 12:{
            ZCDetailVC * detailVC = [[ZCDetailVC alloc]init];
            detailVC.code = dic[@"code"];
            detailVC.dictDesc = dic[@"dictDesc"];
            detailVC.titleName = dic[@"dictName"];
            detailVC.placeholder = dic[@"placeholder"];
            detailVC.valueTextBlock = ^{
                [safeVC loadData];
            };
            [self.navigationController pushViewController:detailVC animated:YES];
        }
            break;
        case 13:{
            UserinforMationVC * userVC = [[UserinforMationVC alloc]init];
            [self.navigationController pushViewController:userVC animated:YES];
        }
            break;

        default:
            break;
    }
}


/**
 *  设置UITableView分割线空隙
 */
-(void)setTableSeparatorInset{
    UIEdgeInsets inset = UIEdgeInsetsMake(0, 10, 0, 0);
    if ([_listTable respondsToSelector:@selector(setSeparatorInset:)]) {
        [_listTable setSeparatorInset:inset];
    }
    
    if ([_listTable respondsToSelector:@selector(setLayoutMargins:)]) {
        [_listTable setLayoutMargins:inset];
    }
}


//设置分割线间距
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    if((indexPath.row+1) < _listArray.count){
        UIEdgeInsets inset = UIEdgeInsetsMake(0, 10, 0, 0);
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
            [cell setSeparatorInset:inset];
        }
        
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:inset];
        }
    }
}


//去掉UItableview headerview黏性
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == self.listTable)
    {
        CGFloat sectionHeaderHeight = 50;
        if (scrollView.contentOffset.y<=sectionHeaderHeight&&scrollView.contentOffset.y>=0) {
            scrollView.contentInset = UIEdgeInsetsMake(-scrollView.contentOffset.y, 0, 0, 0);
        } else if (scrollView.contentOffset.y>=sectionHeaderHeight) {
            scrollView.contentInset = UIEdgeInsetsMake(-sectionHeaderHeight, 0, 0, 0);
        }
    }
}



@end
