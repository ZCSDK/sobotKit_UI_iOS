//
//  ZCObjButton.h
//  SobotKit
//
//  Created by zhangxy on 2018/7/31.
//  Copyright © 2018年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCObjButton : UIButton


@property(nonatomic,strong) id objTag;



@end
