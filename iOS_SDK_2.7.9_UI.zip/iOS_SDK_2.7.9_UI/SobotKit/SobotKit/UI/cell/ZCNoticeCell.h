//
//  ZCNoticeCell.h
//  SobotKit
//
//  Created by lizhihui on 2019/3/26.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import "ZCChatBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZCNoticeCell : ZCChatBaseCell

@end

NS_ASSUME_NONNULL_END
