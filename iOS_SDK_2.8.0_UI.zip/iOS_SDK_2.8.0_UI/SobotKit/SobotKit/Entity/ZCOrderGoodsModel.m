//
//  ZCOrderGoodsModel.m
//  SobotKit
//
//  Created by 张新耀 on 2019/9/29.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import "ZCOrderGoodsModel.h"

@implementation ZCOrderGoodsModel

+(NSString *)getOrderStatusMsg:(int)status{
    NSString *str = @"其它";
    switch (status) {
        case 1:
        str = @"待付款";
        break;
      case 2:
        str = @"待发货";
        break;
        case 3:
        str = @"运输中";
        break;
        case 4:
        str = @"派送中";
        break;
        case 5:
        str = @"已完成";
        break;
        case 6:
        str = @"待评价";
            break;
        case 7:
        str = @"已取消";
            break;
        default:
            break;
    }
    return str;
}

@end
