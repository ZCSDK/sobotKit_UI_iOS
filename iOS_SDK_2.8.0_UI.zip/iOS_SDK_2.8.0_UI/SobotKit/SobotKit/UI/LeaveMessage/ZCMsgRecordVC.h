//
//  ZCMsgRecordVC.h
//  SobotKit
//
//  Created by lizhihui on 2019/2/19.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import <SobotKit/SobotKit.h>
#import "ZCRecordListModel.h"

typedef void(^JumpMsgDetailVCBlock)(ZCRecordListModel* model);

NS_ASSUME_NONNULL_BEGIN

@interface ZCMsgRecordVC : ZCUIBaseController

@property (nonatomic,copy) JumpMsgDetailVCBlock  jumpMsgDetailBlock;

//-(void)updataWithArray:(NSMutableArray *)array;
-(void)updataWithHeight:(CGFloat)height;

-(void)loadData;// 刷新数据

@end

NS_ASSUME_NONNULL_END
