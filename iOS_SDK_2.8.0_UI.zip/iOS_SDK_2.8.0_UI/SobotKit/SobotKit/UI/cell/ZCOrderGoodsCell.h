//
//  ZCOrderGoodsCell.h
//  SobotKit
//
//  Created by 张新耀 on 2019/9/29.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import "ZCChatBaseCell.h"
#import "ZCOrderGoodsModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZCOrderGoodsCell : ZCChatBaseCell

@end

NS_ASSUME_NONNULL_END
