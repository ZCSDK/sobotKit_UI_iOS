//
//  CALayer+QQCorner.m
//  QQCorner
//
//  Created by 秦琦 on 2018/10/24.
//  Copyright © 2018 QinQi. All rights reserved.
//

#import "CALayer+ZCCorner.h"
#import "ZCCornerModel.h"
#import <objc/runtime.h>

@implementation CALayer (ZCCorner)

static const char *zc_layer_key = "zc_layer_key";
static const char *zc_corner_key = "zc_corner_key";

- (CAShapeLayer *)zc_layer {
    CAShapeLayer *layer = objc_getAssociatedObject(self, &zc_layer_key);
    if (!layer) {
        layer = [CAShapeLayer layer];
        layer.frame = self.bounds;
        [self insertSublayer:layer atIndex:0];
        self.zc_layer = layer;
    }
    return layer;
}

- (void)setZc_layer:(CAShapeLayer *)zc_layer {
    objc_setAssociatedObject(self, &zc_layer_key, zc_layer, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (ZCCorner *)zc_corner {
    ZCCorner *corner = objc_getAssociatedObject(self, &zc_corner_key);
    if (!corner) {
        corner = [[ZCCorner alloc] init];
        self.zc_corner = corner;
    }
    return corner;
}

- (void)setZc_corner:(ZCCorner *)zc_corner {
    objc_setAssociatedObject(self, &zc_corner_key, zc_corner, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)updateCornerRadius:(void (^)(ZCCorner *))handler {
    if (handler) {
        handler(self.zc_corner);
    }
    CGColorRef fill = self.zc_corner.fillColor.CGColor;
    if (!fill || CGColorEqualToColor(fill, [UIColor clearColor].CGColor)) {
        if (!self.backgroundColor || CGColorEqualToColor(self.backgroundColor, [UIColor clearColor].CGColor)) {
            if (!self.zc_corner.borderColor || CGColorEqualToColor(self.zc_corner.borderColor.CGColor, [UIColor clearColor].CGColor)) {
                return;
            }
        }
        fill = self.backgroundColor;
        self.backgroundColor = [UIColor clearColor].CGColor;
    }
    
    ZCRadius radius = self.zc_corner.radius;
    if (radius.upLeft < 0) {
        radius.upLeft = 0;
    }
    if (radius.upRight < 0) {
        radius.upRight = 0;
    }
    if (radius.downLeft < 0) {
        radius.downLeft = 0;
    }
    if (radius.downRight < 0) {
        radius.downRight = 0;
    }
    if (self.zc_corner.borderWidth <= 0) {
        self.zc_corner.borderWidth = 1;
    }
    UIBezierPath *path = [UIBezierPath bezierPath];
    CGFloat height = self.bounds.size.height;
    CGFloat width = self.bounds.size.width;
    //左下
    [path moveToPoint:CGPointMake(radius.upLeft, 0)];
    [path addQuadCurveToPoint:CGPointMake(0, radius.upLeft) controlPoint:CGPointZero];
    //左上
    [path addLineToPoint:CGPointMake(0, height - radius.downLeft)];
    [path addQuadCurveToPoint:CGPointMake(radius.downLeft, height) controlPoint:CGPointMake(0, height)];
    //右上
    [path addLineToPoint:CGPointMake(width - radius.downRight, height)];
    [path addQuadCurveToPoint:CGPointMake(width, height - radius.downRight) controlPoint:CGPointMake(width, height)];
    //右下
    [path addLineToPoint:CGPointMake(width, radius.upRight)];
    [path addQuadCurveToPoint:CGPointMake(width - radius.upRight, 0) controlPoint:CGPointMake(width, 0)];
    [path closePath];
    [path addClip];
    
    self.zc_layer.fillColor = fill;
    self.zc_layer.strokeColor = self.zc_corner.borderColor.CGColor;
    self.zc_layer.lineWidth = self.zc_corner.borderWidth;
    self.zc_layer.path = path.CGPath;
}

@end
