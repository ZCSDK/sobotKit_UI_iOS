//
//  ZCOrderContentCell.m
//  SobotApp
//
//  Created by zhangxy on 2017/7/12.
//  Copyright © 2017年 com.sobot.chat.app. All rights reserved.
//

#import "ZCOrderContentCell.h"
//#import "ZCUploadImageModel.h"
#import "ZCUIColorsDefine.h"
#import "ZCLIbGlobalDefine.h"
#import "ZCUIImageView.h"
#import "ZCLibConfig.h"
#import "ZCIMChat.h"
#import "ZCPlatformTools.h"

#import "ZCHtmlFilter.h"
#import "ZCHtmlCore.h"

@interface ZCOrderContentCell()<UITextViewDelegate,UITextFieldDelegate>{
    ZCUIImageView * imageView;
}
@end

@implementation ZCOrderContentCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]){
//        _viewContent = [[UIView alloc]init];
//        _viewContent.backgroundColor = [UIColor whiteColor];
//        [self.contentView addSubview:_viewContent];
        
        _textDesc = [[ZCUIPlaceHolderTextView alloc]init];
        _textDesc.placeholder = @"";
        [_textDesc setPlaceholderColor:UIColorFromRGB(TextPlaceHolderColor)];
        [_textDesc setFont:ZCUIFont14];
        [_textDesc setTextColor:UIColorFromRGB(TextUnPlaceHolderColor)];
        _textDesc.delegate = self;
        _textDesc.placeholederFont = ZCUIFont14;
        _textDesc.layer.cornerRadius = 4.0f;
        _textDesc.layer.masksToBounds = YES;
        [_textDesc setBackgroundColor:UIColorFromRGB(0xF2F5F7)];
        _textDesc.textContainerInset = UIEdgeInsetsMake(10, 10, 0, 10);
//        _textDesc.backgroundColor = [UIColor blueColor];
        [self.contentView addSubview:_textDesc];
        
        _fileScrollView = [[UIScrollView alloc]init];
        _fileScrollView.scrollEnabled = YES;
        _fileScrollView.userInteractionEnabled = YES;
        _fileScrollView.pagingEnabled = NO;
        _fileScrollView.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_fileScrollView];
        
        _tipLab = [[UILabel  alloc]init];
        _tipLab.textColor = UIColorFromRGB(TextWordOrderListTextColor);
         [_tipLab setFont:ZCUIFont14];
        _tipLab.text = @"";
        [self.contentView addSubview:_tipLab];
        self.backgroundColor = [UIColor whiteColor];

    }
    
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


- (NSMutableArray *)imageArr{
    if (!_imageArr) {
        _imageArr = [NSMutableArray arrayWithCapacity:0];
    }
    return _imageArr;
}


-(ZCLibConfig *)getCurConfig{
    return [[ZCPlatformTools sharedInstance] getPlatformInfo].config;
}

-(void)initDataToView:(NSDictionary *)dict{
    
    self.frame = CGRectMake(0, 0, self.tableWidth, 0 );
    _tipLab.frame = CGRectMake(15, 12, self.tableWidth - 30, 0);
   
    
    //    enclosureShowFlag 附件是否显示
    //    enclosureFlag 附件是否必填
    if (!_enclosureShowFlag) {
       self.frame = CGRectMake(0, 0, self.tableWidth, 194);
    }else{
        
        _fileScrollView.frame = CGRectMake(20, 194, self.tableWidth - 40, 70);
        [self reloadScrollView];
        self.frame = CGRectMake(0, 0, self.tableWidth,  194 + 80);

    }
    CGRect tf = self.frame;
    _textDesc.text   = @"";
//    _textDesc.placeholder = dict[@"placeholder"];
    _textDesc.frame = CGRectMake(20, 20, self.tableWidth-40, 154);
    
    UILabel * detailLab = [[UILabel alloc]initWithFrame:CGRectMake(20, CGRectGetMaxY(_tipLab.frame) + 10, self.tableWidth-40, 102)];
    
   
    
    detailLab.numberOfLines = 0;
//    [self autoHeightOfLabel:detailLab with: self.tableWidth-20 -16];
//    [self getTextRectWith:dict[@"placeholder"] WithMaxWidth:self.tableWidth WithlineSpacing:0 AddLabel:detailLab];
    
    [ZCHtmlCore filterHtml:dict[@"placeholder"] result:^(NSString * _Nonnull text1, NSMutableArray * _Nonnull arr, NSMutableArray * _Nonnull links) {
        _textDesc.placeholder = text1;
       [self getTextRectWith:text1 WithMaxWidth:self.tableWidth WithlineSpacing:0 AddLabel:detailLab];
           
       }];
    
    CGFloat DH = CGRectGetHeight(detailLab.frame);
    
    
    if (DH > 102) {
        _textDesc.frame = CGRectMake(20, 20, self.tableWidth-40, DH);
        tf.size.height = tf.size.height + (DH - 102);
        if (_enclosureShowFlag) {
            _fileScrollView.frame = CGRectMake(20, CGRectGetMaxY(_textDesc.frame) +10, self.tableWidth-40, 80);
            self.frame = CGRectMake(0, 0, self.tableWidth, CGRectGetMaxY(_fileScrollView.frame));
        }else{
            self.frame = CGRectMake(0, 0, self.tableWidth, CGRectGetMaxY(_textDesc.frame) + 20 );
        }
        
        
    }
    
    [_textDesc setText:zcLibConvertToString(self.tempModel.ticketDesc)];
    
    _tipLab.attributedText = [self getOtherColorString:@"*" Color:[UIColor redColor] withString:ZCSTLocalString(@"问题描述*")];
       _tipLab.hidden = YES;
//    [self setFrame:CGRectMake(0, 0, self.tableWidth, tf.size.height + tf.origin.y)];
}



- (void)reloadScrollView{
    
    // 先移除，后添加
    [[self.fileScrollView subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    // 加一是为了有个添加button
    NSUInteger assetCount = self.imageArr.count +1 ;
    
    CGFloat width = (self.fileScrollView.frame.size.width - 5*3)/4;
    CGFloat heigth = 60;
    for (NSInteger i = 0; i < assetCount; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
        btn.imageView.contentMode = UIViewContentModeScaleAspectFill;
        btn.frame = CGRectMake((width + 5)*i,0, width, heigth);
        imageView.frame = btn.frame;
        // UIButton
        if (i == self.imageArr.count){
            // 最后一个Button
            [btn setImage: [ZCUITools zcuiGetBundleImage:@"zcicon_add_photo"]  forState:UIControlStateNormal];
            // 添加图片的点击事件
            [btn addTarget:self action:@selector(photoSelecte) forControlEvents:UIControlEventTouchUpInside];
            if (assetCount == 5) {
                btn.frame = CGRectZero;
            }
            [btn.imageView setContentMode:UIViewContentModeScaleAspectFit];
        }else{
            [btn.imageView setContentMode:UIViewContentModeScaleAspectFill];
            // 就从本地取
//            ZCUploadImageModel *model = [_imageArr objectAtIndex:i];
            if(zcLibCheckFileIsExsis([_imagePathArr objectAtIndex:i])){
                UIImage *localImage=[UIImage imageWithContentsOfFile:[_imagePathArr objectAtIndex:i]];
                [btn setImage:localImage forState:UIControlStateNormal];
            }
            
            NSDictionary *imgDic = [_imageArr objectAtIndex:i];
            NSString *imgFileStr =  zcLibConvertToString(imgDic[@"cover"]);
            if (imgFileStr.length>0) {
                UIImage *localImage=[UIImage imageWithContentsOfFile:imgFileStr];
                [btn setImage:localImage forState:UIControlStateNormal];
            }
            
            btn.tag = i;
            // 点击放大图片，进入图片
            [btn addTarget:self action:@selector(tapBrowser:) forControlEvents:UIControlEventTouchUpInside];
                btn.layer.borderColor = UIColorFromRGB(0xF1F1F1).CGColor;
            

            
            
        }
        
        
        btn.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin;
        [self.fileScrollView addSubview:btn];
        
        if (i != self.imageArr.count){
            UIButton *btnDel = [UIButton buttonWithType:UIButtonTypeCustom];
            btnDel.imageView.contentMode = UIViewContentModeScaleAspectFit;
            btnDel.frame = CGRectMake((width + 5)*i + width - 24,4, 20, 20);
            [btnDel setImage:[ZCUITools zcuiGetBundleImage:@"zcicon_close_down"] forState:0];
            btnDel.tag = 100 + i;
            // 点击放大图片，进入图片
            [btnDel addTarget:self action:@selector(tapDelFiles:) forControlEvents:UIControlEventTouchUpInside];
            [self.fileScrollView addSubview:btnDel];
        }
    }
    self.fileScrollView.scrollEnabled = NO;
    // 设置contentSize
    self.fileScrollView.contentSize = CGSizeMake((width+5)*assetCount,self.fileScrollView.frame.size.height);
}


#pragma mark - 选择图片
// 添加图片
- (void)photoSelecte{
    if (self.delegate && [self.delegate respondsToSelector:@selector(itemCreateCellOnClick:dictKey:model:withButton:)]) {
        if(self.isReply){
            [self.delegate  itemCreateCellOnClick:ZCOrderCreateItemTypeAddReplyPhoto dictKey:@"dictContentImages" model:self.tempModel withButton:nil];
        }else{
        [self.delegate  itemCreateCellOnClick:ZCOrderCreateItemTypeAddPhoto dictKey:@"dictContentImages" model:self.tempModel withButton:nil];
        }
    }
    [_textDesc resignFirstResponder];
}


//预览图片
- (void)tapBrowser:(UIButton *)btn{
    // 点击图片浏览器 放大图片
//    NSLog(@"点击图片浏览器 放大图片");
    if (self.delegate && [self.delegate respondsToSelector:@selector(itemCreateCellOnClick:dictKey:model:withButton:)]) {
        if(self.isReply){
            [self.delegate  itemCreateCellOnClick:ZCOrderCreateItemTypeLookAtReplyPhoto dictKey: [NSString stringWithFormat:@"%d",(int)btn.tag] model:self.tempModel withButton:btn];
        }else{
            [self.delegate  itemCreateCellOnClick:ZCOrderCreateItemTypeLookAtPhoto dictKey:[NSString stringWithFormat:@"%d",(int)btn.tag]  model:self.tempModel withButton:btn];
        }
    }
    [_textDesc resignFirstResponder];
}


//
- (void)tapDelFiles:(UIButton *)btn{
    // 点击图片浏览器 放大图片
    //    NSLog(@"点击图片浏览器 放大图片");
    if (self.delegate && [self.delegate respondsToSelector:@selector(itemCreateCellOnClick:dictKey:model:withButton:)]) {
        if(self.isReply){
            [self.delegate  itemCreateCellOnClick:ZCOrderCreateItemTypeDeletePhoto dictKey: [NSString stringWithFormat:@"%d",(int)btn.tag - 100]  model:self.tempModel withButton:nil];
        }else{
            [self.delegate  itemCreateCellOnClick:ZCOrderCreateItemTypeDeletePhoto dictKey:[NSString stringWithFormat:@"%d",(int)btn.tag - 100]   model:self.tempModel withButton:nil];
        }
    }
    [_textDesc resignFirstResponder];
}
-(void)textViewDidChange:(ZCUIPlaceHolderTextView *)textView{
    
    self.tempModel.ticketDesc = zcLibConvertToString(textView.text);
   
    if (self.delegate && [self.delegate respondsToSelector:@selector(itemCreateCellOnClick:dictKey:model:withButton:)]) {
        
        [self.delegate  itemCreateCellOnClick:ZCOrderCreateItemTypeTitle dictKey:@"dictDesc" model:self.tempModel withButton:nil];
    }
}

-(void)textViewDidBeginEditing:(UITextView *)textView{
    if(self.delegate && [self.delegate respondsToSelector:@selector(didKeyboardWillShow:view1:view2:)]){
        [self.delegate didKeyboardWillShow:self.indexPath view1:textView view2:nil];
    }
}

-(void)textFieldDidChangeBegin:(UITextField *) textField{
    if(self.delegate && [self.delegate respondsToSelector:@selector(didKeyboardWillShow:view1:view2:)]){
        [self.delegate didKeyboardWillShow:self.indexPath view1:nil view2:textField];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



-(CGRect)getTextRectWith:(NSString *)str WithMaxWidth:(CGFloat)width  WithlineSpacing:(CGFloat)LineSpacing AddLabel:(UILabel *)label{
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc]initWithString:str];
    NSMutableParagraphStyle * parageraphStyle = [[NSMutableParagraphStyle alloc]init];
    [parageraphStyle setLineSpacing:LineSpacing];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:parageraphStyle range:NSMakeRange(0, [str length])];
    [attributedString addAttribute:NSFontAttributeName value:label.font range:NSMakeRange(0, str.length)];
    
    label.attributedText = attributedString;
    
    // 这里的高度的计算，不能在按 attributedString的属性去计算了，需要拿到label中的
    CGSize size = [self autoHeightOfLabel:label with:width];
    
    CGRect labelF = label.frame;
    labelF.size.height = size.height;
    label.frame = labelF;
    
    
    return labelF;
}


- (CGSize )autoHeightOfLabel:(UILabel *)label with:(CGFloat )width{
    //Calculate the expected size based on the font and linebreak mode of your label
    // FLT_MAX here simply means no constraint in height
    CGSize maximumLabelSize = CGSizeMake(width, FLT_MAX);
    
    CGSize expectedLabelSize = [label sizeThatFits:maximumLabelSize];
    
    //adjust the label the the new height.
    CGRect newFrame = label.frame;
    newFrame.size.height = expectedLabelSize.height;
    label.frame = newFrame;
    [label updateConstraintsIfNeeded];
    
    return expectedLabelSize;
}


@end
