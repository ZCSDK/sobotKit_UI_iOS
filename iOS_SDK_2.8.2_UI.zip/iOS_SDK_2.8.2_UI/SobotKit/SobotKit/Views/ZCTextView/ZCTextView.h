//
//  ZCTextView.h
//  SobotKit
//
//  Created by xuhan on 2019/9/24.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZCTextView : UITextView

@property(nonatomic,strong) NSString *placeholder;

-(void)setPlaceholder:(NSString *)str and:(UIColor *)color;

@end

NS_ASSUME_NONNULL_END
