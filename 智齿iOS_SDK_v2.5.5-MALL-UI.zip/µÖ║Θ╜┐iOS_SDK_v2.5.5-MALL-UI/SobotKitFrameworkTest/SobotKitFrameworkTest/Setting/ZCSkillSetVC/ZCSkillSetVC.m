//
//  ZCSkillSetVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCSkillSetVC.h"
#import "ZCDetailTextCell.h"

#define cellSetIdentifier @"ZCDetailTextCell"
@interface ZCSkillSetVC ()<UITableViewDataSource,UITableViewDelegate,ZCDetailTextCellDelegate>{
    NSString * skillSetID ;
    NSString * skillSetName;
}
@property (nonatomic,strong) NSMutableArray * listArray;

@property (nonatomic,strong) UITableView * listTable;

@property (nonatomic,strong) UITextField * textField;

@end

@implementation ZCSkillSetVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self createNavc];
    _listArray = [NSMutableArray arrayWithCapacity:0];
    [self createTabelView];
    [self loadData];
}
-(void)loadData{
    
    skillSetName = @"";
    skillSetID = @"";
    
    if ( [ZCUUserDefaults valueForKey:@"skillSetId"]!=nil) {
        skillSetID = ZCUserDefaultsGetValue(@"skillSetId");
    }
    if ([ZCUUserDefaults valueForKey:@"skillSetName"] !=nil) {
        skillSetName = ZCUserDefaultsGetValue(@"skillSetName");
    }
    
    // @"cellType"   0 默认状态  1，右边添加选中的箭头   2单选样式
    [_listArray removeAllObjects];
    
    [_listArray addObject:@{@"code":@41,
                            @"dictName":@"技能组ID",
                            @"dictDesc":@"skillSetId",
                            @"placeholder":@"请输入技能组id",
                            @"dictValue":skillSetID,
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}
                            }];
    
    [_listArray addObject:@{@"code":@42,
                            @"dictName":@"技能组昵称",
                            @"dictDesc":@"skillSetName",
                            @"placeholder":@"请输入技能组昵称",
                            @"dictValue":skillSetName,
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}
                            }];
    
    [_listTable reloadData];
}

-(void)createTabelView{
    _listTable = [[UITableView alloc]initWithFrame:CGRectMake(0, NavBarHeight, ScreenHeight, ScreenHeight - NavBarHeight) style:UITableViewStylePlain];
    _listTable.delegate = self;
    _listTable.dataSource = self;
    [self.view addSubview:_listTable];
    
    // 注册cell
    [_listTable registerNib:[UINib nibWithNibName:cellSetIdentifier bundle:nil] forCellReuseIdentifier:cellSetIdentifier];
    
    UIView * footView = [[UIView alloc]initWithFrame:CGRectMake(0, 1, ScreenWidth, ScreenHeight)];
    footView.backgroundColor = UIColorFromRGB(0xEFF3FA);
    _listTable.tableFooterView = footView;
    [_listTable setSeparatorColor:UIColorFromRGB(0xdadada)];
    [_listTable setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    [self setTableSeparatorInset];
    
    
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hidKeyboardAction)];
    [footView addGestureRecognizer:tap];
}

-(void)hidKeyboardAction{
    [self hideKeyBoard];
}

#pragma mark -- 全局回收键盘
- (void)hideKeyBoard
{
    for (UIWindow* window in [UIApplication sharedApplication].windows)
    {
        for (UIView* view in window.subviews)
        {
            [self dismissAllKeyBoardInView:view];
        }
    }
}

-(BOOL) dismissAllKeyBoardInView:(UIView *)view
{
    if([view isFirstResponder])
    {
        [view resignFirstResponder];
        return YES;
    }
    for(UIView *subView in view.subviews)
    {
        if([self dismissAllKeyBoardInView:subView])
        {
            return YES;
        }
    }
    return NO;
}


-(void)createNavc{
    self.view.backgroundColor = UIColorFromRGB(0xEFF3FA);
    self.title = @"对接技能组";

    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    [leftBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 0);
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    
    UIButton * rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(ScreenWidth - 60, NavBarHeight - 40, 50, 40);
    [rightBtn setTitle:@"保存" forState:UIControlStateNormal];
    [rightBtn addTarget:self action:@selector(saveAction:) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    rightBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    UIBarButtonItem * rightItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    
    self.navigationItem.rightBarButtonItem = rightItem;
}

// 返回
-(void)backAction:(UIButton*)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

// 保存
-(void)saveAction:(UIButton *)sender{
    [self hideKeyBoard];
//    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
//    if (_skillSetId.text.length>0) {
//        ZCZCUserDefaultsSetValue(_skillSetId.text, @"skillSetId");
//    }
//    if (_skillSetName.text.length>0) {
//        ZCZCUserDefaultsSetValue(_skillSetName.text, @"skillSetName");
//    }

    [self.navigationController popViewControllerAnimated:YES];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _listArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ZCDetailTextCell * cell = (ZCDetailTextCell*)[tableView dequeueReusableCellWithIdentifier:cellSetIdentifier];
    if (cell == nil) {
        cell =[[ZCDetailTextCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellSetIdentifier];
    }
    
    NSDictionary * dic = _listArray[indexPath.row];
    cell.delegate = self;
    [cell initWithDict:dic];
    
//    cell.textValueBlock = ^(NSString *textValue) {
//        ZCZCUserDefaultsSetValue(textValue, dic[@"dictDesc"]);
//    };
    
    self.textField = cell.textField;
    // 设置分割线
    if(indexPath.row==_listArray.count-1){
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
            [cell setSeparatorInset:UIEdgeInsetsZero];
        }
        
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:UIEdgeInsetsZero];
        }
        
        if([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]){
            [cell setPreservesSuperviewLayoutMargins:NO];
        }
    }
    return cell;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    return nil;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    return  nil;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}

-(void)textValueChange:(UITextField *)textValue WithDict:(NSDictionary *)dict{
    ZCZCUserDefaultsSetValue(textValue.text, dict[@"dictDesc"]);
    NSMutableDictionary * Dict  = _listArray[[dict[@"code"] intValue]-41];
    Dict = [NSMutableDictionary dictionaryWithDictionary:dict];
    _listArray[[dict[@"code"] intValue]-41] = Dict;
    // 添加中间变量，处理cell 重用时的 还原问题
    switch ([dict[@"code"] intValue]) {
        case 41:{
            skillSetID = textValue.text;
        }
            
            break;
        case 42:{
            skillSetName = textValue.text;
        }
            
            break;
        default:
            break;
    }
}

/**
 *  设置UITableView分割线空隙
 */
-(void)setTableSeparatorInset{
    UIEdgeInsets inset = UIEdgeInsetsMake(0, 10, 0, 0);
    if ([_listTable respondsToSelector:@selector(setSeparatorInset:)]) {
        [_listTable setSeparatorInset:inset];
    }
    
    if ([_listTable respondsToSelector:@selector(setLayoutMargins:)]) {
        [_listTable setLayoutMargins:inset];
    }
}


//设置分割线间距
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    if((indexPath.row+1) < _listArray.count){
        UIEdgeInsets inset = UIEdgeInsetsMake(0, 10, 0, 0);
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
            [cell setSeparatorInset:inset];
        }
        
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:inset];
        }
    }
}

//去掉UItableview headerview黏性
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == self.listTable)
    {
        CGFloat sectionHeaderHeight = 50;
        if (scrollView.contentOffset.y<=sectionHeaderHeight&&scrollView.contentOffset.y>=0) {
            scrollView.contentInset = UIEdgeInsetsMake(-scrollView.contentOffset.y, 0, 0, 0);
        } else if (scrollView.contentOffset.y>=sectionHeaderHeight) {
            scrollView.contentInset = UIEdgeInsetsMake(-sectionHeaderHeight, 0, 0, 0);
        }
    }
}


@end
