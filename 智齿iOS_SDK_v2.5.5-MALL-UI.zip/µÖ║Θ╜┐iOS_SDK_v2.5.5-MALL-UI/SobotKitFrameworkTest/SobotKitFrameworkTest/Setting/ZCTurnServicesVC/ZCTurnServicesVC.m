//
//  ZCTurnServicesVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCTurnServicesVC.h"

@interface ZCTurnServicesVC ()

@end

@implementation ZCTurnServicesVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self createNavc];
    [self layoutSubviews];
    self.bgScrollView.backgroundColor = UIColorFromRGB(0xEFF3FA);
    
    self.toplineView.backgroundColor = UIColorFromRGB(0xdadada);
    self.rotboLineView.backgroundColor = UIColorFromRGB(0xdadada);
    self.midLineView.backgroundColor = UIColorFromRGB(0xdadada);
    self.bottomLineView.backgroundColor = UIColorFromRGB(0xdadada);
    
    
    CGRect topLineF = self.toplineView.frame;
    topLineF.size.height = 0.5f;
    self.toplineView.frame = topLineF;
    
    CGRect rotboLineF = self.rotboLineView.frame;
    rotboLineF.size.height = 0.5f;
    self.rotboLineView.frame = rotboLineF;
    
    CGRect midLineF = self.midLineView.frame;
    midLineF.size.height = 0.5f;
    self.toplineView.frame = midLineF;
    
    CGRect bottomLineF = self.bottomLineView.frame;
    bottomLineF.size.height = 0.5f;
    self.toplineView.frame = bottomLineF;
}


-(void)createNavc{
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"转人工设置";
    

    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    [leftBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 0);
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    
    UIButton * rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(ScreenWidth - 60, NavBarHeight - 40, 50, 40);
    [rightBtn setTitle:@"保存" forState:UIControlStateNormal];
    [rightBtn addTarget:self action:@selector(saveAction:) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    rightBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    UIBarButtonItem * rightItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
    
    self.navigationItem.rightBarButtonItem = rightItem;
}

-(void)layoutSubviews{
    _isOpenTurnSwitch.on = NO;
    
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
    if ([userDefaults boolForKey:@"isShowTansfer"]) {
        
        _turnServerSwitch.on = [userDefaults boolForKey:@"isShowTansfer"];
    }
    if ([userDefaults boolForKey:@"isOpenRecord"]) {
        _isOpenVideoSwitch.on = [userDefaults boolForKey:@"isOpenRecord"];
    }
    if ([userDefaults boolForKey:@"isOpenActiveUser"]) {
        _isOpenTurnSwitch.on = [userDefaults boolForKey:@"isOpenActiveUser"];
    }
    if ([userDefaults valueForKey:@"unWordsCount"]) {
        _robotCountLab.text = [userDefaults valueForKey:@"unWordsCount"];
    }
    if ([userDefaults valueForKey:@"activeKeywords"]) {
        _turnKeyWordLab.text = [userDefaults valueForKey:@"activeKeywords"];
    }
}

-(void)backAction:(UIButton*)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)saveAction:(UIButton *)sender{
    
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setBool:_turnServerSwitch.on forKey:@"isShowTansfer"];
    [userDefaults setBool:_isOpenVideoSwitch.on forKey:@"isOpenRecord"];
    [userDefaults setBool:_isOpenTurnSwitch.on forKey:@"isOpenActiveUser"];
    
    [userDefaults setValue:_robotCountLab.text forKey:@"unWordsCount"];
    [userDefaults setValue:_turnKeyWordLab.text forKey:@"activeKeywords"];
    


    if (_passWordkitInfoBlock) {
        _passWordkitInfoBlock(_kitInfo);
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
