//
//  ZCSettingeRobotVC.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCSettingeRobotVC : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *robotIdTF;

@end
