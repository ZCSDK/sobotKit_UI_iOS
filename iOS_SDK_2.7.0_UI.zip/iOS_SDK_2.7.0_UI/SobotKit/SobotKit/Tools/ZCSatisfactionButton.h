//
//  ZCSatisfactionButton.h
//  SobotKit
//
//  Created by lizhihui on 2017/6/15.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCSatisfactionButton : UIButton

- (void)setBackgroundColor:(UIColor *)backgroundColor forState:(UIControlState)state;

@end
