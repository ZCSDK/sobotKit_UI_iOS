# Sets the target folders and the final framework product.
# 如果工程名称和Framework的Target名称不一样的话，要自定义FMKNAME
# 例如: FMK_NAME = "MyFramework"
#FMK_NAME=${PROJECT_NAME}
FMK_NAME="SobotKit"
# Install dir will be the final output to the framework.
# The following line create it in the root folder of the current project.
# $1获取第一个参数，普通版本与电商版本存放不同的路径
PACKAGE_TYPE=$1
if [ -z "$PACKAGE_TYPE" ]; then
echo "STRING is empty"
PACKAGE_TYPE="SobotSDK_MALL"
fi
INSTALL_DIR=../SobotSDK/${PACKAGE_TYPE}/${FMK_NAME}.framework
# Working dir will be deleted after the framework creation.
WRK_DIR=../SobotKit/build
DEVICE_DIR=${WRK_DIR}/Release-iphoneos/${FMK_NAME}.framework
SIMULATOR_DIR=${WRK_DIR}/Release-iphonesimulator/${FMK_NAME}.framework
# -configuration ${CONFIGURATION}
# Clean and Building both architectures.
xcodebuild -project "../SobotKit/SobotKit.xcodeproj" OTHER_CFLAGS="-fembed-bitcode" -configuration "Release" -target "${FMK_NAME}" -sdk iphoneos
xcodebuild -project "../SobotKit/SobotKit.xcodeproj" -configuration "Release" -target "${FMK_NAME}" -sdk iphonesimulator -arch i386 -arch x86_64
# Cleaning the oldest.
if [ -d "${INSTALL_DIR}" ]
then
rm -rf "${INSTALL_DIR}"
fi

mkdir -p "${INSTALL_DIR}"

cp -R "${DEVICE_DIR}/" "${INSTALL_DIR}/"
# Uses the Lipo Tool to merge both binary files (i386 + armv6/armv7) into one Universal final product.
lipo -create "${DEVICE_DIR}/${FMK_NAME}" "${SIMULATOR_DIR}/${FMK_NAME}" -output "${INSTALL_DIR}/${FMK_NAME}"
rm -r "${WRK_DIR}"
#open "${INSTALL_DIR}"
