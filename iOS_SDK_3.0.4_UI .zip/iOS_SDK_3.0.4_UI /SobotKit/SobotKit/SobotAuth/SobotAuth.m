//
//  SobotAuth.m
//  SobotAuth
//
//  Created by zhangxy on 2021/8/26.
//

#import "SobotAuth.h"
#import <CommonCrypto/CommonDigest.h>


@implementation SobotAuth

+(NSString *) getAuthVersion{    
    return @"1.0.0";
}

+(NSString *)getParameterDefaultSign:(NSDictionary *)paramters{
    return [self getParameterSign:paramters withKey:@"sobot*&^%$#@!"];
}

+(NSString *) getParameterSign:(NSDictionary *)paramters withKey:(NSString *)key{
    if(paramters == nil || ![paramters isKindOfClass:[NSDictionary class]]){
        return @"";
    }
    NSMutableString *preSign = [[NSMutableString alloc] init];
    for (NSString *v in paramters.allValues) {
        [preSign appendString:v];
    }
    
    if(key!=nil){
        [preSign appendString:key];
    }
    
    return [SobotAuth sobotAuthMd5:preSign];
}



+(NSString *)sobotAuthMd5:(NSString *)inputString{
    if(nil == inputString || [@"" isEqual:inputString] || [inputString isKindOfClass:[NSNull class]]){
        return @"";
    }
    const char *cStr = [inputString UTF8String];
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
    CC_MD5( cStr, (CC_LONG)strlen(cStr), digest ); // This is the md5 call
    
    NSMutableString *output = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH * 2];
    
    for(int i = 0; i < CC_MD5_DIGEST_LENGTH; i++)
    [output appendFormat:@"%02x", digest[i]];
    
    return  output;
}

@end
