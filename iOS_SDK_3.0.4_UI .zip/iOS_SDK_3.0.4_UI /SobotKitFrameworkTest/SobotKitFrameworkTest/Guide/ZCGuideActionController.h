//
//  ZCGuideStartController.h
//  SobotKitFrameworkTest
//
//  Created by zhangxy on 2020/7/28.
//  Copyright © 2020 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZCGuideActionController : UIViewController

@property(nonatomic,strong) NSDictionary *sectionData;

@end

NS_ASSUME_NONNULL_END
