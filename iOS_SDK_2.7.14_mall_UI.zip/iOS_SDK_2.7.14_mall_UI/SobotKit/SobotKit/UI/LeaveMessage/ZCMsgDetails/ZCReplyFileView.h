//
//  ZCReplyFileView.h
//  SobotKit
//
//  Created by xuhan on 2019/12/10.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZCRecordListModel.h"

NS_ASSUME_NONNULL_BEGIN
typedef void(^ZCReplyFileViewClickBlock)(ZCTicketFileModel* modelDic , UIImageView *imgView);

@interface ZCReplyFileView : UIView

- (instancetype)initWithDic:(ZCTicketFileModel *)model withFrame:(CGRect )frame;

@property (nonatomic , assign) NSInteger viewTag;

@property (nonatomic , copy) ZCReplyFileViewClickBlock clickBlock;

@end

NS_ASSUME_NONNULL_END
