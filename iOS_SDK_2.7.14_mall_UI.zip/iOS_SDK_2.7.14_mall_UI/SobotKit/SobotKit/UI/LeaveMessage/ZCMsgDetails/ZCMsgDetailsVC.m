//
//  ZCMsgDetailsVC.m
//  SobotKit
//
//  Created by lizhihui on 2019/2/20.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import "ZCMsgDetailsVC.h"
#import "ZCUIColorsDefine.h"
#import "ZCLIbGlobalDefine.h"
#import "ZCUIImageTools.h"
#import "ZCUICore.h"
#import "ZCMsgDetailCell.h"
#import "ZCButton.h"

#import "ZCUIConfigManager.h"
#import "ZCPlatformTools.h"
#import "ZCUIConfigManager.h"
#import "ZCRecordListModel.h"
#define cellmsgDetailIdentifier @"ZCMsgDetailCell"
#import "ZCUICustomActionSheet.h"
#import "ZCUIWebController.h"
#import "ZCReplyLeaveController.h"
#import "ZCMLEmojiLabel.h"
#import "ZCHtmlFilter.h"
#import "ZCHtmlCore.h"
#import "ZCToolsCore.h"

#import "ZCMsgDetailsReplyVC.h"
#import "ZCReplyFileView.h"
#import "ZCUIXHImageViewer.h"
#import "ZCVideoPlayer.h"
#import "ZCDocumentLookController.h"

@interface ZCMsgDetailsVC ()<UITableViewDelegate,UITableViewDataSource,ZCUIBackActionSheetDelegate,ZCMLEmojiLabelDelegate>{
    // 屏幕宽高
    CGFloat                     viewWidth;
    CGFloat                     viewHeigth;
    
    BOOL     isShowHeard;
    BOOL     isAddShowBtn;// 添加展开按钮
    
}
@property(nonatomic,strong)UITableView      *listTable;

@property (nonatomic,strong) NSMutableArray * listArray;

@property (nonatomic,strong) ZCButton * showBtn;

@property (nonatomic,strong) UIView * headerView;

/***  评价页面 **/
@property (nonatomic,strong) ZCUICustomActionSheet *sheet;

@end

@implementation ZCMsgDetailsVC

// 横竖屏切换
-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    
    if (toInterfaceOrientation == UIInterfaceOrientationPortrait ||toInterfaceOrientation == UIInterfaceOrientationPortraitUpsideDown) {
        
        CGFloat c = viewWidth;
        if(viewWidth > viewHeigth){
            viewWidth = viewHeigth;
            viewHeigth = c;
        }
    }else{
        CGFloat c = viewHeigth;
        if(viewWidth < viewHeigth){
            viewHeigth = viewWidth;
            viewWidth = c;
        }
    }
    // 切换的方法必须调用
    [self viewDidLayoutSubviews];
}

//**************************项目中的导航栏一部分是自定义的View,一部分是系统自带的NavigationBar*********************************
- (void)setNavigationBarStyle{
    NSString * img ;
    NSString * selImg;
    if (zcLibConvertToString([ZCUICore getUICore].kitInfo.topBackNolImg).length >0) {
        img = zcLibConvertToString([ZCUICore getUICore].kitInfo.topBackNolImg);
    }
    if (zcLibConvertToString([ZCUICore getUICore].kitInfo.topBackSelImg).length >0) {
        selImg = zcLibConvertToString([ZCUICore getUICore].kitInfo.topBackSelImg);
    }
    
    NSString *backStr = @"";
    if ([ZCUICore getUICore].kitInfo.isShowNavBackString) {
        backStr = ZCSTLocalString(@"返回");
    }
    UIButton *leftBtn= [self createLeftBarItemSelect:@selector(buttonClick:) norImageName:@"zcicon_titlebar_back_normal"  highImageName:@"zcicon_titlebar_back_pressed" title:backStr];
    
    UIBarButtonItem *barItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    //    self.navigationItem.leftBarButtonItem = item;
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc]   initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace   target:nil action:nil];
    /**
     width为负数时，相当于btn向右移动width数值个像素，由于按钮本身和  边界间距为5pix，所以width设为-5时，间距正好调整为0；width为正数 时，正好相反，相当于往左移动width数值个像素
     */
    negativeSpacer.width = -5;
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer, barItem, nil];
    
    
    
//    if ([ZCUICore getUICore].kitInfo.leaveCompleteCanReply) {
        UIButton *rightBtn = [self createLeftBarItemSelect:@selector(rightButton:) norImageName:@""  highImageName:@"" title:ZCSTLocalString(@"回复")];
        [rightBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentRight];
        rightBtn.tag = 101;
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
//    }
    
    
    [self.navigationController.navigationBar setBarTintColor:[ZCUITools zcgetDynamicColor]];
    if ([ZCUICore getUICore].kitInfo.topViewBgColor != nil) {
        [self.navigationController.navigationBar setBarTintColor:[ZCUICore getUICore].kitInfo.topViewBgColor];
    }
}

- (UIButton *)createLeftBarItemSelect:(SEL)select norImageName:(NSString *)imageName highImageName:(NSString *)heightImageName title:(NSString *) btnTitle{
    //12 * 19
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn.titleLabel setFont:[ZCUITools zcgetListKitTitleFont]];
    //    [btn addTarget:self action:select forControlEvents:UIControlEventTouchUpInside];
    btn.frame = CGRectMake(0, 0, 44,44) ;
    [btn setImage:[ZCUITools zcuiGetBundleImage:imageName] forState:UIControlStateNormal];
    [btn setImage:[ZCUITools zcuiGetBundleImage:heightImageName] forState:UIControlStateHighlighted];
    
    if ([ZCUICore getUICore].kitInfo.topBackNolColor != nil) {
        [btn setBackgroundImage:[ZCUIImageTools zcimageWithColor:[ZCUICore getUICore].kitInfo.topBackNolColor] forState:UIControlStateNormal];
    }
    if ([ZCUICore getUICore].kitInfo.topBackSelColor != nil) {
        [btn setBackgroundImage:[ZCUIImageTools zcimageWithColor:[ZCUICore getUICore].kitInfo.topBackSelColor] forState:UIControlStateHighlighted];
    }
    [btn setTitleColor:[ZCUITools zcgetTopSubheadTextColor] forState:UIControlStateNormal];
    [btn setTitleColor:[ZCUITools zcgetTopSubheadTextColor] forState:UIControlStateHighlighted];
    [btn setTitleColor:[ZCUITools zcgetTopSubheadTextColor] forState:UIControlStateDisabled];
    [btn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    btn.tag = BUTTON_BACK;
    [btn addTarget:self action:select forControlEvents:UIControlEventTouchUpInside];
    
    CGRect lf = btn.frame;
    lf.size.width=60;
    [btn setFrame:lf];
    
    [btn setTitle:btnTitle forState:UIControlStateNormal];
    return btn;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self loadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    viewHeigth = self.view.frame.size.height;
    viewWidth = self.view.frame.size.width;
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(actionSheetItemClick:) name:@"actionSheetClick:" object:nil];
    if ([ZCUICore getUICore].kitInfo.navcBarHidden) {
        self.navigationController.navigationBarHidden = YES;
//        [self.navigationController setNavigationBarHidden:YES];
        self.navigationController.navigationBar.translucent = NO;
    }
    
    if (self.navigationController.navigationBarHidden) {
        self.navigationController.navigationBar.translucent = NO;
    }
    
    if(!self.navigationController.navigationBarHidden){
        [self setNavigationBarStyle];
        self.title = ZCSTLocalString(@"留言详情");
        [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[ZCUITools zcgetTitleFont],NSForegroundColorAttributeName:[ZCUITools zcgetTopViewTextColor]}];
                
    }else{
        [self createTitleView];
        self.titleLabel.text = ZCSTLocalString(@"留言详情");
        [self.backButton.imageView setContentMode:UIViewContentModeScaleAspectFit];
        [self.backButton setTitle:ZCSTLocalString(@"返回") forState:UIControlStateNormal];
        
        [self.moreButton setTitle:ZCSTLocalString(@"回复") forState:0];
        [self.moreButton setImage:nil forState:0];
        [self.moreButton setImage:nil forState:UIControlStateHighlighted];
//        [self.moreButton addTarget:self action:@selector(rightButton:) forControlEvents:UIControlEventTouchUpInside];
        self.moreButton.tag = 101;
        self.moreButton.hidden = YES;
    }
    

    
    isShowHeard = NO;
    _listArray = [NSMutableArray arrayWithCapacity:0];
    [self createTableView];
    [self loadData];
}


-(ZCLibConfig *)getCurConfig{
    return [[ZCPlatformTools sharedInstance] getPlatformInfo].config;
}
// 加载数据
-(void)loadData{
    [[ZCUIToastTools shareToast] showProgress:@"" with:self.view];
    __weak ZCMsgDetailsVC * weakSelf = self;
    [[[ZCUIConfigManager getInstance] getZCAPIServer] postUserDealTicketinfoListWith:[self getCurConfig] ticketld:_ticketId start:^{
        
    } success:^(NSDictionary *dict, NSMutableArray *itemArray, ZCNetWorkCode sendCode) {
        [[ZCUIToastTools shareToast] dismisProgress];
        if (itemArray.count > 0) {
//            if (_listArray.count >0) {
                [_listArray removeAllObjects];
            [_listTable reloadData];
//            }
            
            // flag ==2 时是 还需要处理
            for (ZCRecordListModel * model in itemArray) {
                if (model.flag == 2 && model.replayList.count > 0) {
                    for (ZCRecordListModel * item in model.replayList) {
                        item.flag = 2;
                        [self.listArray addObject:item];
                    }
                }else{
                    [self.listArray addObject:model];
                }
                    
            }
    
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            //这里进行UI更新
            
//            如果 flag = 3 ，是已完成已完成状态，并且 leaveCompleteCanReply 为 NO  则不显示 留言
            if (self.listArray.count > 0) {
                ZCRecordListModel * model = [self.listArray firstObject];
                if (model.flag == 1 && ![ZCUICore getUICore].kitInfo.leaveCompleteCanReply) {
                    if(!self.navigationController.navigationBarHidden){
                        UIButton *rightBtn = [self createLeftBarItemSelect:@selector(rightButton:) norImageName:@""  highImageName:@"" title:@""];
                        [rightBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentRight];
                        rightBtn.tag = 1000;
                        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
                    }
                    else{
                        self.moreButton.hidden = YES;
                    }
                }
                else{
                    if(!self.navigationController.navigationBarHidden){
                        UIButton *rightBtn = [self createLeftBarItemSelect:@selector(rightButton:) norImageName:@""  highImageName:@"" title:ZCSTLocalString(@"回复")];
                        [rightBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentRight];
                        rightBtn.tag = 101;
                        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:rightBtn];
                    }
                    else{
                        self.moreButton.hidden = NO;
                    }
                }
                
            }
            
            
            
            [weakSelf.listTable reloadData];
            [weakSelf.listTable layoutIfNeeded];
//            NSLog(@"刷新了");
        });
        
  
        
    } failed:^(NSString *errorMessage, ZCNetWorkCode errorCode) {
        [[ZCUIToastTools shareToast] dismisProgress];
    } ];
    
}

-(void)rightButton:(UIButton *)button{
    if (button.tag == 101) {
        ZCReplyLeaveController *vc = [[ZCReplyLeaveController alloc] init];
        vc.ticketId = _ticketId;
        [self.navigationController pushViewController:vc animated:YES];
    }

}

-(void)buttonClick:(UIButton *)sender{
    
    if (sender.tag == 101) {
        ZCReplyLeaveController *vc = [[ZCReplyLeaveController alloc] init];
               vc.ticketId = _ticketId;
               [self.navigationController pushViewController:vc animated:YES];
    }else{
        if (self.navigationController) {
            [self.navigationController popViewControllerAnimated:YES];
          }else{
              [self dismissViewControllerAnimated:YES completion:nil];
          }
    }

}


-(void)createTableView{
    // 计算Y值
    CGFloat Y = 0;
    if (self.navigationController.navigationBarHidden) {
        Y = NavBarHeight;
    }
    if ([ZCUICore getUICore].kitInfo.navcBarHidden) {
        Y = NavBarHeight;
    }
    
    _listTable = [[UITableView alloc]initWithFrame:CGRectMake(0, Y, viewWidth, viewHeigth - NavBarHeight) style:UITableViewStyleGrouped];
    _listTable.delegate = self;
    _listTable.dataSource = self;
    [self.view addSubview:_listTable];
    
    [_listTable registerClass:[ZCMsgDetailCell class] forCellReuseIdentifier:cellmsgDetailIdentifier];
    
    if (iOS7) {
        _listTable.backgroundView = nil;
    }
    
    [_listTable setSeparatorColor:UIColorFromRGB(0xdce0e5)];
//    [_listTable setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    [_listTable setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [_listTable setBackgroundColor:UIColor.whiteColor];
    [self setTableSeparatorInset];
    _listTable.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    _listTable.autoresizesSubviews = YES;
    // 关闭安全区域，否则UITableViewCell横屏时会是全屏的宽
    NSString *version = [UIDevice currentDevice].systemVersion;
    if (version.doubleValue >= 11.0) {
       [_listTable setInsetsContentViewsToSafeArea:NO];
    }
    
//    UIView * bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tableWidth, 100)];
//    bgView.backgroundColor = UIColorFromRGB(0xEFF3FA);
//    _listTable.tableFooterView = bgView;
    
}



#pragma mark UITableView delegate Start
// 返回section数
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

// 返回section高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    ZCRecordListModel * model=nil;
    if (self.listArray.count > 0) {
        model = [_listArray lastObject];
    }
    UIView *bgView = [self getHeaderViewHeight:model];
    return bgView.frame.size.height;
}

// 返回section 的View
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    ZCRecordListModel * model =nil;
    if (self.listArray.count > 0) {
        model = [_listArray lastObject];
    }
    return [self getHeaderViewHeight:model];
 
}

-(void)showMoreAction:(UIButton *)sender{
    if (sender.tag == 1001) {
        isShowHeard = YES;
    }else{
        isShowHeard = NO;
    }
    [self.listTable reloadData];
}

// 返回section下得行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
//    if(_listArray==nil){
//        return 0;
//    }
    return _listArray.count;
}

// cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ZCMsgDetailCell *cell = (ZCMsgDetailCell*)[tableView dequeueReusableCellWithIdentifier:cellmsgDetailIdentifier];
    if (cell == nil) {
        cell = [[ZCMsgDetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellmsgDetailIdentifier];
    }
    if(indexPath.row==_listArray.count-1){
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
            [cell setSeparatorInset:UIEdgeInsetsZero];
        }
        
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:UIEdgeInsetsZero];
        }
        
        if([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]){
            [cell setPreservesSuperviewLayoutMargins:NO];
        }
    }
    if ( indexPath.row > _listArray.count -1) {
        return cell;
    }
    cell.tableWidth = self.listTable.frame.size.width;
    [cell setBackgroundColor:UIColor.whiteColor];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    ZCRecordListModel * model = _listArray[indexPath.row];
    
    __weak ZCMsgDetailsVC * saveSelf = self;
    [cell initWithData:model IndexPath:indexPath.row btnClick:^(ZCRecordListModel * _Nonnull model) {
        // 去评价
        _sheet = [[ZCUICustomActionSheet alloc] initActionSheet:ServerSatisfcationOrderType Name:@"" Cofig:[ZCUICore getUICore].getLibConfig cView:saveSelf.view IsBack:NO isInvitation:1 WithUid:[ZCUICore getUICore].getLibConfig.uid   IsCloseAfterEvaluation:NO Rating:5 IsResolved:YES IsAddServerSatifaction:NO txtFlag:model.txtFlag ticketld:_ticketId ticketScoreInfooList:model.ticketScoreInfooList];
        _sheet.delegate = saveSelf;
//        _sheet.textFlag = model.txtFlag;
//        _sheet.ticketld = _ticketId;/Users/shiyao/Documents/newProjects/ZCNavBar/ZCNavBar/ZCNavBar/ZCNavBar.m
//        _sheet.ticketScoreInfooList = model.ticketScoreInfooList;
        [_sheet showInView:saveSelf.view];
    }];
    
    [cell setShowDetailClickCallback:^(ZCRecordListModel * _Nonnull model,NSString *urlStr) {
        if (urlStr) {
            ZCUIWebController *webVC = [[ZCUIWebController alloc] initWithURL:urlStr];
            [saveSelf.navigationController pushViewController:webVC animated:YES];
            return;
        }
        
        NSString *htmlString = model.replyContent;
        if (model.flag == 3) {
            htmlString = model.content;
        }
        ZCUIWebController *webVC = [[ZCUIWebController alloc] initWithURL:htmlString];
        
        [saveSelf.navigationController pushViewController:webVC animated:YES];
    }];

    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    cell.selected = NO;

    return cell;
}

//-(void)dimissCustomActionSheetPage{
//    _sheet = nil;
//    [ZCUICore getUICore].isDismissSheetPage = YES;
    // 刷新数据
//    [self loadData];
//}


// table 行的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
        UITableViewCell *cell = [self tableView:tableView cellForRowAtIndexPath:indexPath];
        return cell.frame.size.height;
}

// table 行的点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

//设置分割线间距
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    if((indexPath.row+1) < _listArray.count){
        UIEdgeInsets inset = UIEdgeInsetsMake(0, 39, 0, 0);
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
            [cell setSeparatorInset:inset];
        }

        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:inset];
        }
    }
}

-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    [self setTableSeparatorInset];
    //    [self.listTable setFrame:CGRectMake(0, NavBarHeight, viewWidth, viewHeigth - NavBarHeight)];
//    [self.listTable reloadData];
    
    
    int direction = [[ZCToolsCore getToolsCore] getCurScreenDirection];
    CGFloat spaceX = 0;
    CGFloat LW = viewWidth;
    // iphoneX 横屏需要单独处理
    if(direction > 0){
        LW = viewWidth - XBottomBarHeight;
    }
    if(direction == 2){
        spaceX = XBottomBarHeight;
    }
    CGFloat Y = 0;
    if (self.navigationController.navigationBarHidden) {
        Y = NavBarHeight;
    }
    if ([ZCUICore getUICore].kitInfo.navcBarHidden) {
        Y = NavBarHeight;
    }
    [self.listTable setFrame:CGRectMake(spaceX, Y, LW, viewHeigth-Y)];
    [self.listTable reloadData];
}

#pragma mark UITableView delegate end

/**
 *  设置UITableView分割线空隙
 */
-(void)setTableSeparatorInset{
    UIEdgeInsets inset = UIEdgeInsetsMake(0, 39, 0, 0);
    if ([_listTable respondsToSelector:@selector(setSeparatorInset:)]) {
        [_listTable setSeparatorInset:inset];
    }
    
    if ([_listTable respondsToSelector:@selector(setLayoutMargins:)]) {
        [_listTable setLayoutMargins:inset];
    }
}


#pragma mark -- 计算文本高度
-(CGRect)getTextRectWith:(NSString *)str WithMaxWidth:(CGFloat)width  WithlineSpacing:(CGFloat)LineSpacing AddLabel:(UILabel *)label {
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc]initWithString:str];
    NSMutableParagraphStyle * parageraphStyle = [[NSMutableParagraphStyle alloc]init];
    [parageraphStyle setLineSpacing:LineSpacing];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:parageraphStyle range:NSMakeRange(0, [str length])];
    [attributedString addAttribute:NSFontAttributeName value:label.font range:NSMakeRange(0, str.length)];
    
    label.attributedText = attributedString;
    
    CGSize size = [self autoHeightOfLabel:label with:width IsSetFrame:YES];
    
    CGRect labelF = label.frame;
    labelF.size.height = size.height;
    label.frame = labelF;
    
    
    return labelF;
}

/**
 计算Label高度
 
 @param label 要计算的label，设置了值
 @param width label的最大宽度
 @param type 是否从新设置宽，1设置，0不设置
 */
- (CGSize )autoHeightOfLabel:(UILabel *)label with:(CGFloat )width IsSetFrame:(BOOL)isSet{
    //Calculate the expected size based on the font and linebreak mode of your label
    // FLT_MAX here simply means no constraint in height
    CGSize maximumLabelSize = CGSizeMake(width, FLT_MAX);
    
    CGSize expectedLabelSize = [label sizeThatFits:maximumLabelSize];// 返回最佳的视图大小
    
    //adjust the label the the new height.
    if (isSet) {
        CGRect newFrame = label.frame;
        newFrame.size.height = expectedLabelSize.height;
        label.frame = newFrame;
        [label updateConstraintsIfNeeded];
    }
    return expectedLabelSize;
}


-(UIView*)getHeaderViewHeight:(ZCRecordListModel *)model{
    CGFloat tableWidth = _listTable.frame.size.width;
    if (_headerView != nil) {
        [_headerView removeFromSuperview];
        _headerView = nil;
    }
    NSString * str = @"";
    if (model != nil) {
        str = zcLibConvertToString(model.content);
        
//        for (ZCTicketFileModel *fileModel in model.fileList) {
//            str = [str stringByAppendingFormat:@"\n<a href=%@>%@</a>",fileModel.fileUrl,fileModel.fileName];
//        }
    }

    _headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableWidth, ZCNumber(140))];
    _headerView.backgroundColor = [UIColor whiteColor];
    
    
    UILabel *titleLab = [[UILabel alloc] initWithFrame:CGRectMake(ZCNumber(15), ZCNumber(10), tableWidth- ZCNumber(30), ZCNumber(20))];
    [titleLab setFont:VoiceButtonFont];
    titleLab.text =ZCSTLocalString(@"问题描述:");
    [titleLab setTextAlignment:NSTextAlignmentLeft];
    [titleLab setTextColor:UIColorFromRGB(TextRecordTitleColor)];
    [_headerView addSubview:titleLab];
//    str = @"kasjkdlfj按时间拉开点附近绿卡交了多少客服建立刺啦地方呢个电动阀SDK静安寺老地方金额卢卡斯打开缴费老款就死饿了咖啡记录客服看撒娇拉开大姐夫了看记录的卡；的客服ID吃撒的看法就立刻拉开圣诞节联发科就爱收到了发科技类分开就按拉卡上的缴费老卡机阿拉丁是看级分类卡上的缴费扩就拉卡上的缴费老卡机收到了拉看得见水立方看记录的控件爱上了克己复礼科技二路反馈拉卡上的缴费";
    
//    UILabel * conlab = [[UILabel alloc]initWithFrame:CGRectMake(ZCNumber(15), CGRectGetMaxY(titleLab.frame) + 10, tableWidth - ZCNumber(30), ZCNumber(20))];
//    conlab.numberOfLines = 0;
//    conlab.textColor = UIColorFromRGB(TextRecordDetailColor);
//    conlab.font = [UIFont systemFontOfSize:14];
//    conlab.text = str;
//    [_headerView addSubview:conlab];
//    CGSize conlabSize = [self autoHeightOfLabel:conlab with:tableWidth - ZCNumber(30) IsSetFrame:NO];
    
    ZCMLEmojiLabel *conlab=[[ZCMLEmojiLabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(titleLab.frame) + 10, tableWidth-30, 30)];
    [conlab setFont:DetGoodsFont];
    [conlab setBackgroundColor:[UIColor clearColor]];
    [conlab setTextAlignment:NSTextAlignmentLeft];
    [conlab setTextColor:UIColorFromRGB(TextRecordDetailColor)];
    conlab.numberOfLines = 0;
    conlab.isNeedAtAndPoundSign = NO;
    conlab.disableEmoji = NO;
    
    conlab.lineSpacing = 3.0f;
    [conlab setLinkColor:[ZCUITools zcgetChatLeftLinkColor]];
    conlab.delegate = self;
    
    [ZCHtmlCore filterHtml:str result:^(NSString * _Nonnull text1, NSMutableArray * _Nonnull arr, NSMutableArray * _Nonnull links) {
        if (text1 !=nil && text1.length > 0) {
             conlab.attributedText =   [ZCHtmlFilter setHtml:text1 attrs:arr view:conlab textColor:conlab.textColor textFont:conlab.font linkColor:[ZCUITools zcgetChatLeftLinkColor]];
        }else{
             conlab.attributedText = [[NSAttributedString alloc] initWithString:@""];
        }
       
    }];
    CGSize  conlabSize  =  [conlab preferredSizeWithMaxWidth:tableWidth - ZCNumber(30)];
    conlab.frame = CGRectMake(15, CGRectGetMaxY(titleLab.frame) + 10, conlabSize.width, conlabSize.height);
    [_headerView addSubview:conlab];

    
//    2.7.14  增加附件 图片
    float pics_height = 0;
    float h = conlab.frame.origin.y + conlabSize.height + 10;
       if(model.fileList.count > 0) {
            
            float fileBgView_margin_left = 20;
            float fileBgView_margin_top = 10;
            float fileBgView_margin_right = 20;
            float fileBgView_margin = 10;
            
    //      宽度固定为  （屏幕宽度 - 60)/3
            CGSize fileViewRect = CGSizeMake((ScreenWidth - 60)/3, 85);
            
    //      算一下每行多少个 ，
            float nums = (self.view.frame.size.width - fileBgView_margin_left - fileBgView_margin_right)/(fileViewRect.width + fileBgView_margin);
            NSInteger numInt = floor(nums);
            
    //      行数：
            NSInteger rows = ceil(model.fileList.count/(float)numInt);
            
            
            for (int i = 0 ; i < model.fileList.count;i++) {
                ZCTicketFileModel *fileModel = model.fileList[i];
//                NSDictionary *modelDic = @{@"fileType":@"",@"fileUrl":@""};
                
                //           当前列数
                NSInteger currentColumn = i%numInt;
    //           当前行数
                NSInteger currentRow = i/numInt;
                
                float x = fileBgView_margin_left + (fileViewRect.width + fileBgView_margin)*currentColumn;
                float y = h + fileBgView_margin_top + (fileViewRect.height + fileBgView_margin)*currentRow;
                float w = fileViewRect.width;
                float h = fileViewRect.height;
                
                ZCReplyFileView *fileBgView = [[ZCReplyFileView alloc]initWithDic:fileModel withFrame:CGRectMake(x, y, w, h)];
                
                
                [fileBgView setClickBlock:^(ZCTicketFileModel * _Nonnull fileModel, UIImageView * _Nonnull imgView) {
//                   NSString *fileType = modelDic[@"fileModel"];
//                   NSString *fileUrlStr = modelDic[@"fileUrl"];
                    
                    NSString *fileType = fileModel.fileType;
                    NSString *fileUrlStr = fileModel.fileUrl;
    //                NSArray *imgArray = [[NSArray alloc]initWithObjects:fileUrlStr, nil];
                    if ([fileType isEqualToString:@"jpg"] ||
                        [fileType isEqualToString:@"png"] ||
                        [fileType isEqualToString:@"gif"] ) {
                        
                        //     图片预览
                        
                        UIImageView *picView = imgView;
                        CALayer *calayer = picView.layer.mask;
                        [picView.layer.mask removeFromSuperlayer];
                        
                        ZCUIXHImageViewer *xh=[[ZCUIXHImageViewer alloc] initWithImageViewerWillDismissWithSelectedViewBlock:^(ZCUIXHImageViewer *imageViewer, UIImageView *selectedView) {
                            
                        } didDismissWithSelectedViewBlock:^(ZCUIXHImageViewer *imageViewer, UIImageView *selectedView) {
                            
                            selectedView.layer.mask = calayer;
                            [selectedView setNeedsDisplay];
                        } didChangeToImageViewBlock:^(ZCUIXHImageViewer *imageViewer, UIImageView *selectedView) {
                            
                        }];
                        
                        NSMutableArray *photos = [[NSMutableArray alloc] init];
                        [photos addObject:picView];
                        xh.disableTouchDismiss = NO;
                        [xh showWithImageViews:photos selectedView:picView];
                        
                        
                    }
                    else if ([fileType isEqualToString:@"mp4"]){
                        NSURL *imgUrl = [NSURL URLWithString:fileUrlStr];
                        
                         UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
                         ZCVideoPlayer *player = [[ZCVideoPlayer alloc] initWithFrame:window.bounds withShowInView:window url:imgUrl Image:nil];
                         [player showControlsView];
                        
                    }
                    
                    else{
                        ZCLibMessage *message = [[ZCLibMessage alloc]init];
                        ZCLibRich *rich = [[ZCLibRich alloc]init];
                        rich.richmoreurl = fileUrlStr;
                        
                        /**
                        * 13 doc文件格式
                        * 14 ppt文件格式
                        * 15 xls文件格式
                        * 16 pdf文件格式
                        * 17 mp3文件格式
                        * 18 mp4文件格式
                        * 19 压缩文件格式
                        * 20 txt文件格式
                        * 21 其他文件格式
                        */
                        if ([fileType isEqualToString:@"doc"]) {
                            rich.fileType = 13;
                        }
                        else if ([fileType isEqualToString:@"ppt"]){
                            rich.fileType = 14;
                        }
                        else if ([fileType isEqualToString:@"xls"]){
                            rich.fileType = 15;
                        }
                        else if ([fileType isEqualToString:@"pdf"]){
                            rich.fileType = 16;
                        }
                        else if ([fileType isEqualToString:@"mp3"]){
                            rich.fileType = 17;
                        }
    //                    else if ([fileType isEqualToString:@"mp4"]){
    //                        rich.fileType = 18;
    //                    }
                        else if ([fileType isEqualToString:@"zip"]){
                            rich.fileType = 19;
                        }
                        else if ([fileType isEqualToString:@"txt"]){
                            rich.fileType = 20;
                        }
                        else{
                            rich.fileType = 21;
                        }
                        
                        
                        message.richModel = rich;
                        
                        ZCDocumentLookController *docVc = [[ZCDocumentLookController alloc]init];
                        docVc.message = message;
                        [self.navigationController pushViewController:docVc animated:YES];
                    }
                    
                }];
                [_headerView addSubview:fileBgView];
            }
            
            pics_height =  (fileViewRect.height + fileBgView_margin_top)*rows;
        }
    
    _showBtn = [ZCButton buttonWithType:UIButtonTypeCustom];
    [_showBtn addTarget:self action:@selector(showMoreAction:) forControlEvents:UIControlEventTouchUpInside];
    _showBtn.tag = 1001;
    _showBtn.type = 2;
    _showBtn.space = ZCNumber(10);
    _showBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [_showBtn setTitle: ZCSTLocalString(@"查看更多") forState:UIControlStateNormal];
    [_showBtn setImage:[ZCUITools zcuiGetBundleImage:@"zciocn_arrow_down"] forState:UIControlStateNormal];
    [_headerView addSubview: _showBtn];
    _showBtn.frame = CGRectMake(tableWidth/2- ZCNumber(120/2), CGRectGetMaxY(conlab.frame) + ZCNumber(8) + pics_height, 120, ZCNumber(0));
    _showBtn.hidden = YES;
    [_showBtn setTitleColor:UIColorFromRGB(BgTitleColor) forState:UIControlStateNormal];
    if (conlabSize.height > 40 || model.fileList.count > 0) {
        // 添加 展开全文btn
        _showBtn.hidden = NO;
    }
    
    if (!_showBtn.hidden) {
        if (isShowHeard) {
            NSString *clickText = ZCSTLocalString(@"收起");
            // 防止英文过长，箭头被覆盖
            CGSize s = [clickText sizeWithAttributes:@{NSFontAttributeName:_showBtn.titleLabel.font}];
            // 显示全部
            _showBtn.frame = CGRectMake(tableWidth/2- ZCNumber((s.width + 50)/2), CGRectGetMaxY(conlab.frame) + ZCNumber(8) + pics_height, s.width + 50, ZCNumber(20));
//            [self getTextRectWith:str WithMaxWidth:tableWidth - ZCNumber(30) WithlineSpacing:6 AddLabel:conlab];
            //展开之后
            conlab.frame = CGRectMake(ZCNumber(15), CGRectGetMaxY(titleLab.frame) + ZCNumber(10) , conlabSize.width, conlabSize.height);
            _showBtn.tag = 1002;
            [_showBtn setTitle:clickText forState:UIControlStateNormal];
            [_showBtn setImage:[ZCUITools zcuiGetBundleImage:@"zciocn_arrow_up"] forState:UIControlStateNormal];
            CGRect sf = _showBtn.frame;
            sf.origin.y = CGRectGetMaxY(conlab.frame) + ZCNumber(20) + pics_height;
            _showBtn.frame = sf;
            for (UIView *view in [_headerView subviews]) {
                 if ([view isKindOfClass:[ZCReplyFileView class]]) {
                     view.hidden = NO;
                 }
             }
        }else{
            // 收起之后
            conlab.frame = CGRectMake(ZCNumber(15), CGRectGetMaxY(titleLab.frame) + ZCNumber(10), tableWidth - ZCNumber(30), ZCNumber(50));
            
            _showBtn.frame = CGRectMake(tableWidth/2- ZCNumber(120/2), CGRectGetMaxY(conlab.frame) + ZCNumber(8), ZCNumber(120), ZCNumber(20));
            _showBtn.tag = 1001;
            [_showBtn setTitle:ZCSTLocalString(@"全部展开") forState:UIControlStateNormal];
            [_showBtn setImage:[ZCUITools zcuiGetBundleImage:@"zciocn_arrow_down"] forState:UIControlStateNormal];
            for (UIView *view in [_headerView subviews]) {
                 if ([view isKindOfClass:[ZCReplyFileView class]]) {
                     view.hidden = YES;
                 }
             }
        }
    }
    
    // 线条
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(ZCNumber(15), CGRectGetMaxY(_showBtn.frame) + ZCNumber(8), tableWidth - ZCNumber(30), 0.5)];
    lineView.backgroundColor = UIColorFromRGB(recordElineColor);
    [_headerView addSubview:lineView];
    
    CGRect hf = _headerView.frame;
    hf.size.height = CGRectGetMaxY(lineView.frame);
    _headerView.frame = hf;
    
    return _headerView;
}




//-(void) actionSheetItemClick:(NSNotification *)sender{
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            NSLog(@"指定刷新页面");
//            [self loadData];
//        });
//}
-(void) actionSheetClick:(int) isCommentType{
    [[ZCUIToastTools shareToast] showProgress:@"" with:self.view];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"指定刷新页面");
        [self loadData];
    });
}




#pragma mark EmojiLabel链接点击事件
// 链接点击
-(void)attributedLabel:(ZCTTTAttributedLabel *)label didSelectLinkWithURL:(NSURL *)url{
    // 此处得到model 对象对应的值
    
    //    NSLog(@"url:%@  url.absoluteString:%@",url,url.absoluteString);
    [self doClickURL:url.absoluteString text:@""];
}


// 链接点击
-(void)ZCMLEmojiLabel:(ZCMLEmojiLabel *)emojiLabel didSelectLink:(NSString *)link withType:(ZCMLEmojiLabelLinkType)type{
    [self doClickURL:link text:@""];
}


// 链接点击
-(void)doClickURL:(NSString *)url text:(NSString * )htmlText{
    if(url){
        url=[url stringByReplacingOccurrencesOfString:@"\"" withString:@""];
        if([ZCUICore getUICore].LinkClickBlock && ![ZCUICore getUICore].LinkClickBlock(url)){
            if([url hasPrefix:@"tel:"] || zcLibValidateMobile(url)){
               __block NSString *callURL=url;
                
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle: nil message:[url stringByReplacingOccurrencesOfString:@"tel:" withString:@""] preferredStyle: UIAlertControllerStyleAlert];
                
                UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:ZCSTLocalString(@"取消") style: UIAlertActionStyleCancel handler: nil];
                
                UIAlertAction *okAction = [UIAlertAction actionWithTitle:ZCSTLocalString(@"呼叫") style: UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:callURL]];
                }];
                
                [alertController addAction: cancelAction];
                
                [alertController addAction: okAction];
                
                [self.navigationController presentViewController:alertController animated: YES completion: nil];
                
                
            }else if([url hasPrefix:@"mailto:"] || zcLibValidateEmail(url)){
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
            }
         
            else{
                if (![url hasPrefix:@"https"] && ![url hasPrefix:@"http"]) {
                    url = [@"http://" stringByAppendingString:url];
                }
                ZCUIWebController *webPage=[[ZCUIWebController alloc] initWithURL:zcUrlEncodedString(url)];
                if(self.navigationController != nil ){
                    [self.navigationController pushViewController:webPage animated:YES];
                }else{
                    UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:webPage];
                    nav.navigationBarHidden=YES;
                    
                    nav.modalPresentationStyle = UIModalPresentationOverFullScreen;
                    [self presentViewController:nav animated:YES completion:^{
                        
                    }];
                }
            }
        }
    }
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
