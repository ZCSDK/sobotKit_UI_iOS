//
//  ViewController.m
//  SobotKitFrameworkTest
//
//  Created by zhangxy on 15/11/21.
//  Copyright © 2015年 zhichi. All rights reserved.
//

#import "ViewController.h"
#import <SobotKit/SobotKit.h>


#import "PlatformTestController.h"
@interface ViewController ()<ZCChatControllerDelegate>{
    UIView *menuView;
    int     _type ;
    UISwitch * _imagePickerSwitch;
    UIColor * _selectedColor;
    int     _aidTurn;
    NSString *titleType;
    BOOL    isPlatformUnion;
}


@property (nonatomic,strong) UIScrollView * scrollView; // 背景

@property (nonatomic,strong) UILabel * titleLab;//

@property (nonatomic,strong) UILabel * detailLab;

@property (nonatomic,strong) UIImageView * bgImg;// 背景图





@end

@implementation ViewController


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
//    [self.navigationController setToolbarHidden:YES animated:NO];
    self.tabBarController.tabBar.hidden = NO;
    self.navigationController.navigationBarHidden = YES;
    [self.navigationController.navigationBar setBarTintColor:[UIColor yellowColor]];
    [self viewDidLayoutSubviews];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
//    isPlatformUnion = NO;
    
    [self layoutCoustomUI];
#pragma mark 设置默认APPKEY

   
}

-(IBAction)buttonClick:(UIButton *)sender{

    
//    [ZCNSuserdefaultdManager shareUserdefaultd].type = 0;
//    [[ZCNSuserdefaultdManager shareUserdefaultd] openSDKWith:self];
   
//    self.navigationController.navigationBarHidden = YES;
//    self.navigationController.navigationBar.translucent = NO;
    //  初始化配置信息
    ZCLibInitInfo *initInfo = [ZCLibClient getZCLibClient].libInitInfo;
//    initInfo.userId = @"test-123-1"; //initInfo.robotId = @"3";
//    initInfo.platformKey = @"1";
//    initInfo.avatarUrl = @"https://est-123-1ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1528443275&di=d746da19eef2e3e02dba690fd695295d&src=http://images.macx.cn/forum/leadbbsfile/2011/08/05_054446.jpg";
//    initInfo.robotId = @"234234";
    [self setZCLibInitInfoParam:initInfo];
//    initInfo.appKey = @"1ff3e4ff91314f5ca308e19570ba24bb";
    //自定义用户参数
    [self customUserInformationWith:initInfo];


    ZCKitInfo *uiInfo=[ZCKitInfo new];
//    uiInfo.apiHost = @"https://ten.sobot.com";
//    uiInfo.apiHost = @"http://test.sobot.com";
  NSMutableArray *arr = [[NSMutableArray alloc] init];
    for (int i = 0; i<20; i++) {
        ZCLibCusMenu *menu1 = [[ZCLibCusMenu alloc] init];
        menu1.title = [NSString stringWithFormat:@"测试%d",i+1];
        menu1.url = [NSString stringWithFormat:@"https://www.baidu.com/%d",i+1];;
        menu1.imgName = @"zcicon_sendpictures";
        [arr addObject:menu1];
    }
    
      
    uiInfo.cusMoreArray = arr;
//    uiInfo.navcBarHidden = YES;
    
//    initInfo.goodMsg = @"订购的商品订单号：124345890 该商品正在发货";
//    initInfo.goodMsgType = 3;
//    initInfo.sourceURL = @"www.baidu.com";
//    initInfo.sourceTitle = @"测试用户来源页";
    
    // 自定义UI(设置背景颜色相关)
    [self customerUI:uiInfo];


    // 之定义商品和留言页面的相关UI
    [self customerGoodAndLeavePageWithParameter:uiInfo];


    // 自定义提示语相关设置
    [self customTipWord:initInfo];
   

    // 未读消息
//    [self customUnReadNumber:uiInfo];

    // 测试模式
//    [ZCSobot setShowDebug:YES];
//

//    self.navigationController.navigationBarHidden = YES;
    
    [[ZCLibClient getZCLibClient] setLibInitInfo:initInfo];
    
    [ZCSobot startZCChatVC:uiInfo with:self target:nil pageBlock:^(id object, ZCPageBlockType type) {
                // 点击返回
                if(type==ZCPageBlockGoBack){
//                    NSLog(@"点击了关闭按钮");
                    self.navigationController.toolbarHidden = YES;
                    NSLog(@"%p",object);
                    // 显示导航
                    
                }
        
                // 页面UI初始化完成，可以获取UIView，自定义UI
                if(type==ZCPageBlockLoadFinish){
//                    NSLog(@"页面加载完成");
                    NSLog(@" ++++++ %@  ++++++",object);
                    // 2.6.6 之后 修改方法替换
//                    ZCChatView * chatView = (ZCChatView *)object;
//                    [chatView.backButton setTitle:@"" forState:UIControlStateNormal];
                }
    } messageLinkClick:^(NSString *link) {
        NSLog(@"%@",link);return NO;
    }];

}




#define delegate
//-(void)openLeaveMsgClick:(NSString*)tipMsg{
//    NSLog(@"tipMsg ==%@",tipMsg);
    
//    ZCSettingAidVC * vc = [[ZCSettingAidVC alloc]init];
//    [self.navigationController pushViewController:vc animated:YES];
//}


- (void)customTipWord:(ZCLibInitInfo*)initInfo{

    // 用户超时下线提示语
//    initInfo.customUserOutWord = ZCUserDefaultsGetValue(@"customUserOutWord");//_customUserOutWord.text;
//
//    // 用户超时提示语
//    initInfo.customUserTipWord = ZCUserDefaultsGetValue(@"customUserTipWord");//_customUserTipWord.text;
//
//    // 人工客服提示语
//    initInfo.customAdminTipWord = ZCUserDefaultsGetValue(@"customAdminTipWord");//_customAdminTipWord.text;
//
//    // 机器人欢迎语
//    initInfo.customRobotHelloWord = ZCUserDefaultsGetValue(@"customRobotHelloWord");//_customRobotHelloWord.text;
//
//    // 暂无客服在线说辞
//    initInfo.customAdminNonelineTitle = ZCUserDefaultsGetValue(@"customAdminNonelineTitle");//_customAdminNonelineTitle.text;
//
//    // 人工客服欢迎语
//    initInfo.customAdminHelloWord  = ZCUserDefaultsGetValue(@"customAdminHelloWord");//_customAdminHelloWord.text;
}


- (void)setZCLibInitInfoParam:(ZCLibInitInfo *)initInfo{

//     获取AppKey
//    initInfo.appKey = ZCUserDefaultsGetValue(@"appkey"); // _appKeyTF.text; appkey;
//
//    initInfo.skillSetId = ZCUserDefaultsGetValue(@"skillSetId");//_groupIdTF.text;
//    initInfo.skillSetName = ZCUserDefaultsGetValue(@"skillSetName");//_groupNameTF.text;
//    initInfo.receptionistId = ZCUserDefaultsGetValue(@"receptionistId");//@"927dc485c6ff4dd7ad26b7e07649eccb"; //_aidTF.text;
//    initInfo.robotId = ZCUserDefaultsGetValue(@"robotId");//_robotIdTF.text;
//    initInfo.tranReceptionistFlag = (int)[ZCUUserDefaults boolForKey:@"tranReceptionistFlag"];//1;//_aidTurn;
//    initInfo.scopeTime = [ZCUserDefaultsGetValue(@"scopeTime") intValue];//[_historyScopeTF.text intValue];
//    initInfo.titleType = ZCUserDefaultsGetValue(@"titleType");//titleType;
//    initInfo.customTitle = ZCUserDefaultsGetValue(@"customTitle");//_titleCustomTF.text;
//
//
//    //        if(_hostTF.text!=nil){
//    //            initInfo.apiHost = _hostTF.text;
//    //        }
//    //            initInfo.apiHost = @"http://test.sobot.com";
//    initInfo.apiHost = ZCUserDefaultsGetValue(@"apiHost");
}


// 设置UI部分
-(void) customerUI:(ZCKitInfo *) kitInfo{
//    kitInfo.isShowEvaluation = YES;
//    kitInfo.navcBarHidden = NO;
//    kitInfo.isCloseAfterEvaluation = YES;
//    // 点击返回是否触发满意度评价（符合评价逻辑的前提下）
//    kitInfo.isOpenEvaluation = _isBackSwitch.on;
//
//
//    // 是否显示语音按钮
//    kitInfo.isOpenRecord = _isOpenVideoSwitch.on;

    // 是否显示转人工按钮
//    kitInfo.isShowTansfer    = _isShowTansferSwitch.on;
    // 评价完人工是否关闭会话
//    kitInfo.isCloseAfterEvaluation = _isCloseSessionWhenBackSwitch.on;

//    if (!kitInfo.isShowTansfer) {
//        kitInfo.unWordsCount = _robotUnknowCount.text;
//    }

//    kitInfo.isOpenActiveUser = _isOpenTurnSwitch.on;
//    if (_turnKeyWord.text.length>0) {
//
//        kitInfo.activeKeywords = [NSDictionary dictionaryWithObject:@"" forKey:_turnKeyWord.text];
//        [kitInfo.activeKeywords setValue:@"" forKey:_turnKeyWord.text];
//    }
//    kitInfo.activeKeywords =  @{@"转人工":@"",@"R":@"",@"r":@""};

    
//    kitInfo.isCloseAfterEvaluation = [ZCUUserDefaults boolForKey:@"isCloseAfterEvaluation"];//  YES;
//    // 点击返回是否触发满意度评价（符合评价逻辑的前提下）
//    kitInfo.isOpenEvaluation =  [ZCUUserDefaults boolForKey:@"isOpenEvaluation"];//_isBackSwitch.on;
//
//
//    // 是否显示语音按钮
//    if (ZCUserDefaultsGetValue(@"isOpenRecord")) {
//        kitInfo.isOpenRecord = [ZCUUserDefaults boolForKey:@"isOpenRecord"];//_isOpenVideoSwitch.on;
//    }else{
//        kitInfo.isOpenRecord = YES;
//    }
//
//    // 需要本地配置
//    if (kitInfo.isOpenRecord) {
//        kitInfo.isOpenRobotVoice = YES;
//    }else{
//        kitInfo.isOpenRobotVoice = NO;
//    }
    
//
//    // 是否显示转人工按钮
//    if (ZCUserDefaultsGetValue(@"isShowTansfer")!= nil) {
//       kitInfo.isShowTansfer    = [ZCUUserDefaults boolForKey:@"isShowTansfer"];//_isShowTansferSwitch.on;
//    }else{
//        kitInfo.isShowTansfer = YES;
//    }
    
//
//
//    if (!kitInfo.isShowTansfer) {
//        kitInfo.unWordsCount = ZCUserDefaultsGetValue(@"unWordsCount");//_robotUnknowCount.text;
//    }
//
//    kitInfo.isOpenActiveUser = [ZCUUserDefaults boolForKey:@"isOpenActiveUser"];//_isOpenTurnSwitch.on;
//    //    if (_turnKeyWord.text.length>0) {
//

//    NSString * activeKeywords = @"";
//    if (ZCUserDefaultsGetValue(@"activeKeywords")!= nil) {
//        activeKeywords = ZCUserDefaultsGetValue(@"activeKeywords");
//    }
//    if (![activeKeywords isEqualToString:@""]) {
//        kitInfo.activeKeywords = [NSDictionary dictionaryWithObject:@"" forKey:activeKeywords];
//    }
//    NSArray * cusarr = @[
//                         @{@"lableName":@"测试1",
//                           @"lableLink":@"http://www.sobot.com"
//                           },
//                         @{@"lableName":@"测试2",
//                           @"lableLink":@"http://www.sobot.com"
//                           },
//                         @{@"lableName":@"测试3----------长一点",
//                           @"title":@"http://www.sobot.com"
//                           },
//                         @{@"lableName":@"测试4",
//                           @"lableLink":@"http://www.sobot.com"
//                           },
//                         @{@"lableName":@"测试55555",
//                           @"lableLink":@"http://www.sobot.com"
//                           },
//                         @{@"lableName":@"测试66666666",
//                           @"lableLink":@"http://www.sobot.com"
//                           },
//                         @{@"lableName":@"测试777",
//                           @"lableLink":@"http://www.sobot.com"
//                           },
//                         @{@"lableName":@"测试8888888",
//                           @"lableLink":@"http://www.sobot.com"
//                           }];
//
//    kitInfo.cusMenuArray = [NSMutableArray arrayWithArray:cusarr];
    

//            [kitInfo.activeKeywords setValue:@"" forKey:_turnKeyWord.text];
//        }
    //    kitInfo.activeKeywords =  //@{@"转人工":@"",@"R":@"",@"r":@""};
    
    
    
    /**
     *  自定义信息
     */
    // 顶部导航条标题文字 评价标题文字 系统相册标题文字 评价客服（立即结束 取消）按钮文字
//        kitInfo.titleFont = [UIFont systemFontOfSize:30];

    // 返回按钮      输入框文字   评价客服是否有以下情况 label 文字  提价评价按钮
//        kitInfo.listTitleFont = [UIFont systemFontOfSize:22];
    
    //没有网络提醒的button 没有更多记录label的文字    语音tipLabel的文字   评价不满意（4个button）文字  占位图片的lablel文字   语音输入时间label文字   语音输入的按钮文字
//        kitInfo.listDetailFont = [UIFont systemFontOfSize:25];
    
    // 录音按钮的文字
//        kitInfo.voiceButtonFont = [UIFont systemFontOfSize:25];
    // 消息提醒 （转人工、客服接待等）
//        kitInfo.listTimeFont = [UIFont systemFontOfSize:22];
    
    // 聊天气泡中的文字
//        kitInfo.chatFont  = [UIFont systemFontOfSize:22];
    
    // 聊天的背景颜色
//        kitInfo.backgroundColor = [UIColor redColor];
    
    // 导航、客服气泡、线条的颜色
//    kitInfo.customBannerColor  = [UIColor redColor];
    
    // 左边气泡的颜色
//        kitInfo.leftChatColor = [UIColor redColor];
    
    // 右边气泡的颜色
//        kitInfo.rightChatColor = [UIColor redColor];
    
    // 底部bottom的背景颜色
//        kitInfo.backgroundBottomColor = [UIColor redColor];
    
    // 底部bottom的输入框线条背景颜色
//        kitInfo.bottomLineColor = [UIColor redColor];
    
    // 提示气泡的背景颜色
//        kitInfo.BgTipAirBubblesColor = [UIColor redColor];
    
    // 顶部文字的颜色
//        kitInfo.topViewTextColor  =  [UIColor redColor];
    
    // 提示气泡文字颜色
//            kitInfo.tipLayerTextColor = [UIColor redColor];
    
    // 评价普通按钮选中背景颜色和边框(默认跟随主题色customBannerColor)
//            kitInfo.commentOtherButtonBgColor=[UIColor redColor];

    // 评价背景颜色(默认跟随主题色customBannerColor)
//        kitInfo.commentCommitButtonColor = [UIColor redColor];
    
    //评价提交按钮背景颜色和边框(默认跟随主题色customBannerColor)
//        kitInfo.commentCommitButtonBgColor = [UIColor redColor];
    
    //    评价提交按钮点击后背景色，默认0x089899, 0.95
//        kitInfo.commentCommitButtonBgHighColor = [UIColor yellowColor];
    
    // 左边气泡文字的颜色
    //    kitInfo.leftChatTextColor = [UIColor redColor];
    
    // 右边气泡文字的颜色[注意：语音动画图片，需要单独替换]
//        kitInfo.rightChatTextColor  = [UIColor redColor];
    
    // 时间文字的颜色
//        kitInfo.timeTextColor = [UIColor redColor];
    
    // 客服昵称颜色
//            kitInfo.serviceNameTextColor = [UIColor redColor];
    
    
    // 提交评价按钮的文字颜色
//        kitInfo.submitEvaluationColor = [UIColor blueColor];
    
    // 相册的导航栏背景颜色
//    kitInfo.imagePickerColor =   _selectedColor;
    // 相册的导航栏标题的文字颜色
//        kitInfo.imagePickerTitleColor = [UIColor redColor];
    
    // 左边超链的颜色
//        kitInfo.chatLeftLinkColor = [UIColor blueColor];
    
    // 右边超链的颜色
//        kitInfo.chatRightLinkColor =[UIColor redColor];
    
    // 提示客服昵称的文字颜色
//        kitInfo.nickNameTextColor = [UIColor redColor];
    // 相册的导航栏是否设置背景图片(图片来自SobotKit.bundle中zcicon_navcbgImage)
//        kitInfo.isSetPhotoLibraryBgImage = YES;
    
    // 富媒体cell中线条的背景色
//        kitInfo.LineRichColor = [UIColor redColor];
    
        // 语音cell选中的背景颜色
//        kitInfo.videoCellBgSelColor = [UIColor redColor];
    
        // 商品cell中标题的文字颜色
//        kitInfo.goodsTitleTextColor = [UIColor redColor];
    
        // 商品详情cell中摘要的文字颜色
//        kitInfo.goodsDetTextColor = [UIColor redColor];
    //
    //    // 商品详情cell中标签的文字颜色
//        kitInfo.goodsTipTextColor = [UIColor redColor];
    //
    //    // 商品详情cell中发送的文字颜色
//        kitInfo.goodsSendTextColor = [UIColor redColor];
    
    // 发送按钮的背景色
//        kitInfo.goodSendBtnColor = [UIColor yellowColor];
    
    // “连接中。。。”  button 的背景色和文字的颜色
//        kitInfo.socketStatusButtonBgColor  = [UIColor yellowColor];
//        kitInfo.socketStatusButtonTitleColor = [UIColor redColor];
    
//    kitInfo.notificationTopViewLabelFont = [UIFont systemFontOfSize:20];
//    kitInfo.notificationTopViewLabelColor = [UIColor yellowColor];
//    kitInfo.notificationTopViewBgColor = [UIColor redColor];
    
    // 评价 已解决 未解决的 颜色
//    kitInfo.satisfactionSelectedBgColor = [UIColor redColor];
//    kitInfo.satisfactionTextSelectedColor = [UIColor blueColor];
    
    // 2.6.3新增
//    kitInfo.moreBtnNolImg = @"home_Robot";
//    kitInfo.moreBtnSelImg = @"home_chat";
//
//    kitInfo.turnBtnSelImg = @"home_Robot";
//    kitInfo.turnBtnNolImg = @"home_chat";
//
//
//    kitInfo.topBackSelImg = @"home_Robot";
//    kitInfo.topBackNolImg = @"home_chat";

//    kitInfo.topBackNolColor = [UIColor redColor];
//    kitInfo.topBackSelColor = [UIColor yellowColor];
//
//    kitInfo.topViewBgColor = [UIColor yellowColor];
    
    // 2.6.5 新增 顶踩按钮文字的三种状态
//    kitInfo.topBtnNolColor = [UIColor redColor];
//    kitInfo.topBtnSelColor = [UIColor yellowColor];
//    kitInfo.topBtnGreyColor = [UIColor blueColor];
    
    //2.6.6
//    kitInfo.topBackTitle = @"你好";
}



//屏幕点击事件
- (void)didTapAnywhere1:(UITapGestureRecognizer *)recognizer {
    [_appKeyTF resignFirstResponder];
    [_hostTF resignFirstResponder];
    [_userIdTF resignFirstResponder];
    [_goodTagTF resignFirstResponder];
    [_goodsImgTF resignFirstResponder];
    [_goodsSendTF resignFirstResponder];
    [_goodsTitleTF resignFirstResponder];
    [_goodsSummaryTF resignFirstResponder];
    [_groupNameTF resignFirstResponder];
    [_groupIdTF resignFirstResponder];
    [_aidTF resignFirstResponder];
    [_robotIdTF resignFirstResponder];
    [_titleCustomTF resignFirstResponder];
    [_historyScopeTF resignFirstResponder];
    [_robotUnknowCount resignFirstResponder];
    [_customAdminHelloWord resignFirstResponder];
    [_customAdminNonelineTitle resignFirstResponder];
    [_customUserTipWord resignFirstResponder];
    [_customAdminTipWord resignFirstResponder];
    [_customUserOutWord resignFirstResponder];
    [_customRobotHelloWord resignFirstResponder];
    [_turnKeyWord resignFirstResponder];


}



-(IBAction)buttonCloseSession:(id)sender{
//    [[ZCLibClient getZCLibClient] closeIMConnection];
//    // 将是否显示转人工按钮的设置回复默认值
//    [ZCLibClient getZCLibClient].isShowTurnBtn = NO;
}

// 离线消息
- (void)offLineAction:(UIButton *)btn{
//    [[ZCLibClient getZCLibClient] setAutoNotification:YES];
//    _offLineMsgCount.text = @"0";
//    _offLineMsgCount.hidden = YES;
//    if (btn.tag == 201) {
//       // [[ZCLibClient getZCLibClient] initZCIMCaht];
//        [ZCLibClient getZCLibClient].receivedBlock=^(id obj,int unRead,NSDictionary *object){
//            NSLog(@"未读消息数量：\n%d,%@",unRead,obj);
//            if(unRead>0){
//                _offLineMsgCount.hidden = NO;
//                _offLineMsgCount.text = [NSString stringWithFormat:@"%d",unRead];
//            }else{
//                _offLineMsgCount.hidden = YES;
//                _offLineMsgCount.text = @"0";
//            }
//        };
//        [self.openOffLineMsgBtn setTitle:@"关闭离线消息" forState:UIControlStateNormal];
//        btn.tag =202;
//    }else{
//        [ZCLibClient  closeAndoutZCServer:YES];
//        [self.openOffLineMsgBtn setTitle:@"开启离线消息" forState:UIControlStateNormal];
//        btn.tag = 201;
//
//    }
}

// 关闭推送
-(void)btnClosePush:(UIButton *) btn{
  
//    [[ZCLibClient getZCLibClient] remove]
//    [ZCLibClient  closeAndoutZCServer:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


// 自定义用户信息参数
- (void)customUserInformationWith:(ZCLibInitInfo*)initInfo{
//    initInfo.userId         = ZCUserDefaultsGetValue(@"userID");//_userIdTF.text;
//    initInfo.customInfo = @{@"标题1":@"自定义1",@"内容1":@"我是一个自定义字段。",@"标题2":@"自定义字段2",@"内容2":@"我是一个自定义字段，我是一个自定义字段，我是一个自定义字段，我是一个自定义字段。",@"标题3":@"自定义字段字段3",@"内容3":@"<a href=\"www.baidu.com\" target=\"_blank\">www.baidu.com</a>",@"标题4":@"自定义4",@"内容4":@"我是一个自定义字段 https://www.sobot.com/chat/pc/index.html?sysNum=9379837c87d2475dadd953940f0c3bc8&partnerId=112"};

//    NSUserDefaults *user  = [NSUserDefaults standardUserDefaults];
//    initInfo.email        = [user valueForKey:@"email"];
//    initInfo.avatarUrl    = [user valueForKey:@"avatarUrl"];
//    initInfo.sourceURL    = [user valueForKey:@"sourceURL"];
//    initInfo.sourceURL = @"http://mall.haoyunbang.com.cn/hmall/v2/order/confirm?goods_id=582d60560cf24af052c05b71";

//    initInfo.sourceTitle  = [user valueForKey:@"sourceTitle"];
//    initInfo.serviceMode  = [ZCUserDefaultsGetValue(@"serverModel") intValue];//_type;
//
    // 以下字段为方便测试使用，上线打包时注掉
//    initInfo.phone       = [user valueForKey:@"phone"];
//    initInfo.nickName    = [user valueForKey:@"nickName"];
    // 微信，微博，用户的真实昵称，生日，备注性别 QQ号
    // 生日字段用户传入的格式，例：20170323，如果不是这个格式，初始化接口会给过滤掉
    
//    initInfo.qqNumber = [user valueForKey:@"qqNumber"];
//    initInfo.userSex = [user valueForKey:@"userSex"];
//    initInfo.userSex = @"";
//    initInfo.realName = [user valueForKey:@"useName"];
//    initInfo.weiBo = [user valueForKey:@"weiBo"];
//    initInfo.weChat = [user valueForKey:@"weChat"];
//    initInfo.userBirthday = [user valueForKey:@"userBirthday"];
//    initInfo.userRemark = [user valueForKey:@"userRemark"];
    
//    initInfo.customerFields = @{@"customField22":@"我是自定义的分校",
//                                @"userSex":@"保密",
//                                @"weixin":@"微信号",
//                                @"weibo":@"微博账号",
//                                @"birthday":@"2017-06-08"};
//    initInfo.customerFields = @{@"isVip":@""};

//    NSDictionary * dict = [NSDictionary dictionaryWithObjectsAndKeys:initInfo.phone,@"tel",useName,@"realname",initInfo.email,@"email",initInfo.nickName,@"uname" ,weChat,@"weixin",weibo,@"weibo",sex,@"sex",userBirthday,@"birthday",userRemark,@"remark",initInfo.avatarUrl,@"face",qq,@"qq",initInfo.sourceURL,@"visitUrl",initInfo.sourceTitle,@"visitTitle",@"自定义1",@"标题1",@"<a href=\"www.baidu.com\" target=\"_blank\">www.baidu.com</a>",@"内容3",nil];
//    initInfo.customInfo = dict;
//    initInfo.customInfo = @{
//                            @"access-key":@"自定义1"
//                            @"access-key":@"自定义1",
//                            @"内容1":@"我是一个自定义字段。",
//                            @"标题2":@"自定义字段2",
//                            @"内容2":@"我是一个自定义字段，我是一个自定义字段，我是一个自定义字段，我是一个自定义字段。",
//                            @"标题3":@"自定义字段字段3",
//                            @"内容3":@"<a href=\"www.baidu.com\" target=\"_blank\">www.baidu.com</a>",
//                            @"标题4":@"自定义4",
//                            };
    
//    @"access-key":@"自定义1",
//    @"内容1":@"我是一个自定义字段。",
//    @"标题2":@"自定义字段2",
//    @"内容2":@"我是一个自定义字段，我是一个自定义字段，我是一个自定义字段，我是一个自定义字段。",
//    @"标题3":@"自定义字段字段3",
//    @"内容3":@"<a href=\"www.baidu.com\" target=\"_blank\">www.baidu.com</a>",
//    @"标题4":@"自定义4",
//    @"内容4":@"我是一个自定义字段 https://www.sobot.com/chat/pc/index.html?sysNum=9379837c87d2475dadd953940f0c3bc8&partnerId=112"
}


// 自定义参数 商品信息相关
- (void)customerGoodAndLeavePageWithParameter:(ZCKitInfo *)uiInfo{
    
    // 商品信息自定义
//    if (ZCUserDefaultsGetValue(@"goods_Title")!= nil && ZCUserDefaultsGetValue(@"gPageUrl_Text")!= nil) {
//        ZCProductInfo *productInfo = [ZCProductInfo new];
//        productInfo.thumbUrl = ZCUserDefaultsGetValue(@"goods_IMG");
//        productInfo.title = ZCUserDefaultsGetValue(@"goods_Title");
//        productInfo.desc = ZCUserDefaultsGetValue(@"goods_SENDMGS");
//        productInfo.label = ZCUserDefaultsGetValue(@"glabel_Text");
//        productInfo.link = ZCUserDefaultsGetValue(@"gPageUrl_Text");
//        uiInfo.productInfo = productInfo;
//    }
   
    // 设置电话号和昵称（留言界面的显示）
//    uiInfo.isAddNickName = _isAddNickSwitch.on;
//    uiInfo.isShowNickName = _isShowNickSwitch.on;
//    if(_hostTF.text!=nil){
//        uiInfo.apiHost = _hostTF.text;
//    }
    //    uiInfo.apiHost = @"http://test.sobot.com";
//    uiInfo.apiHost = ZCUserDefaultsGetValue(@"apiHost");
//
    
}


// 未读消息数
- (void)customUnReadNumber:(ZCKitInfo *)uiInfo{
    // 未读消息
//    _unReadMsgCount.hidden = YES;
//    _unReadMsgCount.text = @"0";
//
//
//    if (ZCUserDefaultsGetValue(@"autoNotification") !=nil) {
//
//        [[ZCLibClient getZCLibClient] setAutoNotification: (BOOL)ZCUserDefaultsGetValue(@"autoNotification")];
//    }
    
    //[[ZCLibClient getZCLibClient] initZCIMCaht];
//    [ZCLibClient getZCLibClient].receivedBlock = ^(id obj,int unRead,NSDictionary *object){
////        NSLog(@"当前消息数：%d \n %@",unRead,obj);
//        if(unRead>0){
//            _unReadMsgCount.hidden = NO;
//            _unReadMsgCount.text = [NSString stringWithFormat:@"%d",unRead];
//        }else{
//            _unReadMsgCount.hidden = YES;
//            _unReadMsgCount.text = @"0";
//        }
//    };
    
}


#pragma mark -- demo中UI界面
- (void)layoutCoustomUI{
    [[ZCLibClient getZCLibClient] setAutoNotification:_isAutoRemindSwitch.on];
    _robotIdTF.keyboardType = UIKeyboardTypeNumberPad;
    _robotUnknowCount.keyboardType = UIKeyboardTypeNumberPad;
    _historyScopeTF.keyboardType = UIKeyboardTypeNumberPad;
    _aidTurn =0;
    _type = 0;
//    [self.navigationController setNavigationBarHidden:NO];

    UIGestureRecognizer *tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapAnywhere1:)];
    [self.view addGestureRecognizer:tap];

    [_closePushBtn setImage:[self createImageWithColor:[UIColor lightGrayColor]] forState:UIControlStateHighlighted];
    [_closePushBtn addTarget:self action:@selector(btnClosePush:) forControlEvents:UIControlEventTouchUpInside];
    [_openOffLineMsgBtn addTarget:self action:@selector(offLineAction:) forControlEvents:UIControlEventTouchUpInside];

    [_closeSessionButton addTarget:self action:@selector(buttonCloseSession:) forControlEvents:UIControlEventTouchUpInside];
    _openOffLineMsgBtn.tag = 201;


    _hostSwitch.tag               = 3;
    _hostSwitch.on                = NO;
    _hostTF.text                  = @"http://test.sobot.com";

    _isShowGoodsSwitch.on         = YES;
    _isShowGoodsSwitch.tag        = 4;

    _isOpenVideoSwitch.tag        = 5;
    _isOpenVideoSwitch.on         = YES;

    _isShowTansferSwitch.tag      = 6;
    _isShowTansferSwitch.on       = YES;
    _robotUnknowCount.hidden  = YES;


    _robotPreferredSwitch.tag     = 7;
    _robotPreferredSwitch.on      = NO;

    _onlyServiceSwitch.tag        = 8;
    _onlyServiceSwitch.on         = NO;

    _artificialPrioritySwitch.tag = 9;
    _artificialPrioritySwitch.on  = NO;

    _onlyRobotSwitch.tag          = 10;
    _onlyRobotSwitch.on           = NO;

    _isBackSwitch.on              = YES;
    _isBackSwitch.tag             = 18;

    _isCloseSessionWhenBackSwitch.on = NO;
    _isCloseSessionWhenBackSwitch.tag = 40;

    _isAutoRemindSwitch.on         = YES;
    _isAutoRemindSwitch.tag        = 19;

    _isAidSwitch.on                = NO;
    _isAidSwitch.tag               = 30;

    _titleDefaultSwitch.on         = YES;
    _titleDefaultSwitch.tag        = 31;

    _titleCustomSwitch.on          = NO;
    _titleCustomSwitch.tag         = 32;
    _titleEnterpriseSwitch.on      = NO;
    _titleEnterpriseSwitch.tag     = 33;
    _titleCustomTF.hidden          = YES;

    _isAddNickSwitch.on            = NO;
    titleType = @"0";

    _isOpenTurnSwitch.on           = NO;
    _isOpenTurnSwitch.tag          = 34;


    [[ZCLibClient getZCLibClient] setAutoNotification:YES];

    [_titleDefaultSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [_titleCustomSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [_titleEnterpriseSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];

    [_isAidSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [_isAutoRemindSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];

    [_hostSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [_isShowGoodsSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [_isShowTansferSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [_isOpenVideoSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [_robotPreferredSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [_onlyServiceSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [_artificialPrioritySwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [_onlyRobotSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    [_isBackSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];



    // 未读消息数
    _unReadMsgCount.layer.cornerRadius = 10.0f;
    _unReadMsgCount.layer.masksToBounds = YES;
    _unReadMsgCount.hidden = YES;
//    _unknownCountTextField.hidden = YES;
//    _unknownCountLabel.hidden = YES;

    // 离线消息数
    _offLineMsgCount.layer.cornerRadius = 10.0f;
    _offLineMsgCount.layer.masksToBounds = YES;
    _offLineMsgCount.hidden = YES;

//    _debugModelSwitch.on = YES;
//    _debugModelSwitch.tag = 20;
//    [[ZCLibClient getZCLibClient] setIsDebugMode:_debugModelSwitch.on];



    NSString *SkillSet_Text=[[NSUserDefaults standardUserDefaults] valueForKey:@"SkillSet_Text"];
    if(SkillSet_Text != nil){
        _groupIdTF.text = SkillSet_Text;
    }else{
        // 设置默认值
    }

    NSString *gimg_Text=[[NSUserDefaults standardUserDefaults] valueForKey:@"goods_IMG"];
    if(gimg_Text != nil){
        _goodsImgTF.text = gimg_Text;
    }else{
        // 设置默认值
        _goodsImgTF.text = @"http://gtb.baidu.com/HttpService/get?p=dHlwZT1pbWFnZS9qcGVnJm49dmlzJnQ9YWRpbWcmYz10YjppZyZyPTM2MzI4MTA4MCw0MjcwMDE0NjkAa38";
    }
    NSString *gimg_TitleText=[[NSUserDefaults standardUserDefaults] valueForKey:@"goods_Title"];
    if(gimg_TitleText != nil){
        _goodsTitleTF.text = gimg_TitleText;
    }else{
        // 设置默认值
        _goodsTitleTF.text = @"我是要显示饿标题我是要显示饿标题我是要显示饿标题我是要最多显示三行";
    }
    NSString *gsend_Text=[[NSUserDefaults standardUserDefaults] valueForKey:@"goods_SENDMGS"];
    if(gimg_Text != nil){
        _goodsSendTF.text = gsend_Text;
    }else{
        // 设置默认值
        _goodsSendTF.text = @"摘要描述内容 http://www.baidu.com 你好";
    }

    NSString *glabel_Text = [[NSUserDefaults standardUserDefaults] valueForKey:@"glabel_Text"];
    if (glabel_Text !=nil) {
        _goodTagTF.text = glabel_Text;
    }else{
        _goodTagTF.text = @"300元";
    }

    NSString *gPageUrl_Text = [[NSUserDefaults standardUserDefaults] valueForKey:@"gPageUrl_Text"];
    if (gPageUrl_Text !=nil) {
        _goodsSummaryTF.text = gPageUrl_Text;
    }else{
        _goodsSummaryTF.text = @"https://api.sobot.com";
    }



    NSLog(@"\nvc=%zd\ndivice=%zd\napp=%zd",self.interfaceOrientation,[[UIDevice currentDevice] orientation],[[UIApplication sharedApplication] statusBarOrientation]);
    if([[UIApplication sharedApplication] statusBarOrientation] == UIDeviceOrientationPortrait || [[UIApplication sharedApplication] statusBarOrientation] == UIDeviceOrientationPortraitUpsideDown){
        NSLog(@" 竖排");
    }else{
        NSLog(@"横屏");
    }

}


-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{

    if([[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationMaskPortrait || [[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationPortraitUpsideDown)
        NSLog(@"\nvc=%zd\ndivice=%zd\napp=%zd",self.interfaceOrientation,[[UIDevice currentDevice] orientation],[[UIApplication sharedApplication] statusBarOrientation]);

    if([[UIApplication sharedApplication] statusBarOrientation] == UIDeviceOrientationPortrait || [[UIApplication sharedApplication] statusBarOrientation] == UIDeviceOrientationPortraitUpsideDown){
        NSLog(@" 竖排");
    }else{
        NSLog(@"横屏");
    }
}


#pragma mark -- switch事件
-(IBAction)switchValueChanged:(UISwitch *)sender{
    switch (sender.tag) {
        case 2:
            if(sender.on){
                _groupIdTF.hidden = NO;
            }else{
                _groupIdTF.hidden = YES;
            }
            break;
        case 3:
            if(sender.on){
                _hostTF.text = @"https://api.sobot.com";
            }else{
                _hostTF.text = @"http://test.sobot.com";
            }
            break;
        case 4:
            if(sender.on){
                _goodsSummaryTF.hidden = NO;
                _goodTagTF.hidden = NO;
                _goodsSendTF.hidden = NO;
                _goodsTitleTF.hidden = NO;
                _goodsImgTF.hidden = NO;
            }else{
                _goodsSummaryTF.hidden = YES;
                _goodTagTF.hidden = YES;
                _goodsSendTF.hidden = YES;
                _goodsTitleTF.hidden = YES;
                _goodsImgTF.hidden = YES;
            }
            break;
        case 5:
            if (sender.on) {

            }else{

            }
            break;
        case 6:
            if (sender.on) {
                _robotUnknowCount.hidden = YES;
//                _unknownCountTextField.hidden = YES;
            }else{
//                _unknownCountTextField.hidden = NO;
                _robotUnknowCount.hidden = NO;
            }
            break;
        case 7:
            if (sender.on) {
                // 接入方式,1只有机器人,2.仅人工 3.智能客服-机器人优先 4智能客服-人工客服优先
                //                _robotPreferredSwitch.on = YES;
                _onlyServiceSwitch.on = NO;
                _onlyRobotSwitch.on = NO;
                _artificialPrioritySwitch.on = NO;
                _type = 3;
            }else{
                _type = 0;
            }
            break;
        case 8:
            if (sender.on) {
                _robotPreferredSwitch.on = NO;
                //                _onlyServiceSwitch.on = NO;
                _onlyRobotSwitch.on = NO;
                _artificialPrioritySwitch.on = NO;
                _type = 2;
            }else{
                _type = 0;
            }
            break;
        case 9:
            if (sender.on) {
                _robotPreferredSwitch.on = NO;
                _onlyServiceSwitch.on = NO;
                _onlyRobotSwitch.on = NO;
                //                _artificialPrioritySwitch.on = NO;
                _type = 4;
            }else{
                _type = 0;
            }
            break;
        case 10:
            if (sender.on) {
                _robotPreferredSwitch.on = NO;
                _onlyServiceSwitch.on = NO;
                //                _onlyRobotSwitch.on = NO;
                _artificialPrioritySwitch.on = NO;
                _type = 1;
            }else{
                _type = 0;
            }
            break;
        case 11:
            if (sender.on) {
                _selectedColor = [UIColor purpleColor];
            }else{
                _selectedColor = [UIColor redColor];
            }
            break;
        case 14:
            if (sender.on) {
//                _isAddNickNameSwitch.hidden = NO;
//                _isAddNickLab.hidden = NO;
//                isShowNickName = YES;
            }else{
//                _isAddNickNameSwitch.hidden = YES;
//                _isAddNickLab.hidden = YES;
//                isShowNickName = NO;
            }
            break;
        case 15:
            if (sender.on) {
//                isAddNickName = YES;
            }else{
//                isAddNickName = NO;
            }
            break;
        case 16:
            if (sender.on) {
//                _isAddPhoneNumberSwitch.hidden = NO;
//                _isAddPoneLab.hidden = NO;
//                isShowPhoneNumber = YES;
            }else{
//                _isAddPhoneNumberSwitch.hidden = YES;
//                _isAddPoneLab.hidden = YES;
//                isShowPhoneNumber = NO;
            }
            break;
        case 17:
            if (sender.on) {
//                isAddPhoneNumber = YES;
            }else{
//                isAddPhoneNumber = NO;
            }
            break;
        case 18:
            if (sender.on) {
//                isBackEvaluation = YES;
            }else{
//                isBackEvaluation = NO;
            }
            break;

        case 19:
            [[ZCLibClient getZCLibClient] setAutoNotification:sender.on];
            break;
        case 20:
            break;
        case 30:
            if (sender.on) {
                _aidTurn = 1;
            }else{
                _aidTurn = 0;
            }
            break;
        case 31:
            if (sender.on) {
                _titleEnterpriseSwitch.on = NO;
                _titleCustomSwitch.on  = NO;
                _titleCustomTF.hidden = YES;
                titleType = @"0";
            }else{
                _titleEnterpriseSwitch.on = NO;
                _titleCustomSwitch.on  = NO;
                _titleCustomTF.hidden = YES;
                titleType = @"0";
            }
            break;
        case 32:
            if (sender.on) {
                _titleDefaultSwitch.on = NO;
                _titleCustomTF.hidden = NO;
                _titleEnterpriseSwitch.on = NO;
                titleType = @"2";
            }else{
                _titleDefaultSwitch.on = NO;
                _titleCustomTF.hidden = YES;
                _titleEnterpriseSwitch.on = NO;
                titleType = @"0";
            }
            break;
        case 33:
            if (sender.on) {
                _titleDefaultSwitch.on = NO;
                _titleCustomTF.hidden = YES;
                _titleCustomSwitch.on = NO;
                titleType = @"1";
            }else{
                _titleDefaultSwitch.on = NO;
                _titleCustomTF.hidden = YES;
                _titleCustomSwitch.on = NO;
                titleType = @"0";
            }
            break;


        default:
            break;
    }
}

- (UIImage*) createImageWithColor: (UIColor*) color
{
    CGRect rect=CGRectMake(0,0, 1, 1);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;

}


// 解决tabbar 影藏后，他的位置不能被其他视图覆盖
- (void) hideTabBar:(BOOL) hidden
{
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0];
    for(UIView *view in self.tabBarController.view.subviews)
    {
        if([view isKindOfClass:[UITabBar class]])
        {
            if (hidden)
            {
                [view setFrame:CGRectMake(view.frame.origin.x, 480, view.frame.size.width, view.frame.size.height)];
                
            } else
            {
                [view setFrame:CGRectMake(view.frame.origin.x, 431, view.frame.size.width, view.frame.size.height)];
            }
        }
        else
        {
            if (hidden)
            {
                [view setFrame:CGRectMake(view.frame.origin.x, view.frame.origin.y, view.frame.size.width, 480)];
                
            } else
            {
                [view setFrame:CGRectMake(view.frame.origin.x, view.frame.origin.y, view.frame.size.width, 431)];
            }
        }
    }
    [UIView commitAnimations];
}


@end
