//
//  ZCInfoCardCell.h
//  SobotKit
//
//  Created by lizhihui on 2019/4/24.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import "ZCChatBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZCInfoCardCell : ZCChatBaseCell

@end

NS_ASSUME_NONNULL_END
