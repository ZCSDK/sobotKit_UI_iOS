//
//  ZCMsgDetailCell.m
//  SobotKit
//
//  Created by lizhihui on 2019/2/20.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import "ZCMsgDetailCell.h"
#import "ZCUIColorsDefine.h"
#import "ZCLIbGlobalDefine.h"

@interface ZCMsgDetailCell(){
    
}

@property (nonatomic,strong) UIImageView * timeIcon; // 时间图标

@property (nonatomic,strong) UILabel * timeLab;

@property (nonatomic,strong) UIImageView * statusIcon; // 受理状态图标

@property (nonatomic,strong) UILabel * statusLab;

@property (nonatomic,strong) UILabel * replyLab; // 问题回复

@property (nonatomic,strong) UILabel * replycont;// 回复内容

@property (nonatomic,strong) UIView * lineView; // 竖线条



@end

@implementation ZCMsgDetailCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]){
//        self.contentView.backgroundColor = UIColorFromRGB(0xF0F0F0);
        _timeIcon = [[UIImageView alloc]init];
        [self.contentView addSubview:_timeIcon];
        
        _timeLab = [[UILabel alloc]init];
        _timeLab.textColor = UIColorFromRGB(recordTimeTextColor);
        _timeLab.font = DetGoodsFont;
        [self.contentView addSubview:_timeLab];
        
        _statusIcon = [[UIImageView alloc]init];
        [self.contentView addSubview:_statusIcon];
        
        _statusLab = [[UILabel alloc]init];
        _statusLab.font = VoiceButtonFont;
        [self.contentView addSubview:_statusLab];
        
        _replyLab = [[UILabel alloc]init];
        _replyLab.font = DetGoodsFont;
        _replyLab.text = @"客服回复";
        [self.contentView addSubview:_replyLab];
        
        _replycont = [[UILabel alloc]init];
        _replycont.textColor = UIColorFromRGB(TextRecordDetailColor);
        _replycont.font = DetGoodsFont;
        _replycont.numberOfLines = 0;
        [self.contentView addSubview:_replycont];
        
        _lineView = [[UIView alloc]init];
        _lineView.backgroundColor = UIColorFromRGB(BgTitleColor);
        [self.contentView addSubview:_lineView];
        
    }
    
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)initWithData:(ZCRecordListModel *)model IndexPath:(NSInteger)row{
    
    // 回执
    _timeLab.text = @"";
    _timeIcon.image = nil;
    _statusLab.text = @"";
    _statusIcon.image = nil;
    _replyLab.text = @"";
    _replycont.text = @"";
    _lineView.frame = CGRectMake(0, 0, 0, 0);
    
    _timeIcon.image =  [ZCUITools zcuiGetBundleImage:@"zcicon_time_new"];
    _timeIcon.frame = CGRectMake(ZCNumber(15), ZCNumber(8), ZCNumber(16), ZCNumber(16));
    
    _timeLab.frame = CGRectMake(CGRectGetMaxX(_timeIcon.frame) + ZCNumber(15), _timeIcon.frame.origin.y -ZCNumber(2), 160, ZCNumber(20));
    _timeLab.text = zcLibConvertToString(model.timeStr);  //@"2018-04-11 22:22:22";
    
    _statusIcon.image = [ZCUITools zcuiGetBundleImage:@"zcicon_point_new"];
    _statusIcon.frame = CGRectMake(ZCNumber(15), CGRectGetMaxY(_timeLab.frame) + ZCNumber(13), ZCNumber(16), ZCNumber(16));
    
    _statusLab.frame = CGRectMake(CGRectGetMaxX(_statusIcon.frame) + ZCNumber(15), _statusIcon.frame.origin.y -ZCNumber(3), 160, ZCNumber(20));
    _statusLab.text = @"已创建";
    
    _replyLab.frame = CGRectMake(_timeLab.frame.origin.x, CGRectGetMaxY(_statusLab.frame) + ZCNumber(8), 160, ZCNumber(20));
    _replyLab.text = @"客服回复";
    _replyLab.textColor = UIColorFromRGB(TextRecordTitleColor);
    
    
    NSString *tmp = zcLibConvertToString(model.replyContent);
    // 过滤标签
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<br />" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<br/>" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<br>" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<BR/>" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<BR />" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"<p>" withString:@"\n"];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"</p>" withString:@" "];
    tmp = [tmp stringByReplacingOccurrencesOfString:@"&nbsp;" withString:@" "];
    while ([tmp hasPrefix:@"\n"]) {
        tmp=[tmp substringWithRange:NSMakeRange(1, tmp.length-1)];
    }
    
    
    //1 创建了  2 受理了 3 关闭了
    switch (model.flag) {
        case 1:
             _statusLab.text = @"已创建";
            _replycont.text = @"";
             _replyLab.frame = CGRectMake(_timeLab.frame.origin.x, CGRectGetMaxY(_statusLab.frame) + ZCNumber(8), 160, ZCNumber(0));
            break;
        case 2:
             _statusLab.text = @"受理中";
            _replycont.text = @"客服已经成功收到您的问题，请耐心等待";
            _timeLab.text = [self getTimeTextStr:zcLibConvertToString(model.replyTime)];
           
//            _timeLab.text = zcLibConvertToString(model.replyTime);// 时间戳由服务端处理
            if (model.startType == 0) {
                _replyLab.text = @"客服回复";
                if (model.replyContent.length > 0) {
                    _replycont.text = tmp;
                }
            }else if (model.startType == 1){
                _replyLab.frame = CGRectMake(_timeLab.frame.origin.x, CGRectGetMaxY(_statusLab.frame) + ZCNumber(8), 160, ZCNumber(0));
                _statusLab.text = @"客户回复";
                if (model.replyContent.length > 0) {
                    _replycont.text = tmp;
                }else{
                    _replycont.text = @"无";
                }
            }
            break;
        case 3:{
             _statusLab.text = @"已完成";
            NSString *tmps = zcLibConvertToString(model.content);
            // 过滤标签
            tmps = [tmps stringByReplacingOccurrencesOfString:@"<br />" withString:@"\n"];
            tmps = [tmps stringByReplacingOccurrencesOfString:@"<br/>" withString:@"\n"];
            tmps = [tmps stringByReplacingOccurrencesOfString:@"<br>" withString:@"\n"];
            tmps = [tmps stringByReplacingOccurrencesOfString:@"<BR/>" withString:@"\n"];
            tmps = [tmps stringByReplacingOccurrencesOfString:@"<BR />" withString:@"\n"];
            tmps = [tmps stringByReplacingOccurrencesOfString:@"<p>" withString:@"\n"];
            tmps = [tmps stringByReplacingOccurrencesOfString:@"</p>" withString:@" "];
            tmps = [tmps stringByReplacingOccurrencesOfString:@"&nbsp;" withString:@" "];
            while ([tmps hasPrefix:@"\n"]) {
                tmps=[tmps substringWithRange:NSMakeRange(1, tmps.length-1)];
            }
            _replycont.text = tmps;
        }
            break;
        default:
            break;
    }
    
   
    
    // 计算文本内容的高度
    _replycont.frame = CGRectMake(_timeLab.frame.origin.x, CGRectGetMaxY(_replyLab.frame) + ZCNumber(5), ScreenWidth- ZCNumber(60), ZCNumber(20));
    
   
    CGRect CC = CGRectMake(0, 0, 0, 0);
    
    CGRect RF = [self getTextRectWith: _replycont.text WithMaxWidth:ScreenWidth- ZCNumber(60) WithlineSpacing:6 AddLabel:_replycont];
    
    if (row == 0) {
        _timeLab.textColor = UIColorFromRGB(BgTitleColor);
        _statusLab.textColor = UIColorFromRGB(BgTitleColor);

        CC = RF;
        _lineView.backgroundColor = UIColorFromRGB(BgTitleColor);
    }else{
        _timeLab.textColor = UIColorFromRGB(recordTimeTextColor);
//        _statusLab.text = @"受理中";
        _statusLab.textColor = UIColorFromRGB(TextRecordTitleColor);
//        _replycont.text = @"客服已经成功收到您的问题，请耐心等待";
        CC = _replycont.frame;
        _lineView.backgroundColor = UIColorFromRGB(recordLineColor);
        [_timeIcon setImage:[ZCUITools zcuiGetBundleImage:@"zcicon_time_old"]];
        [_statusIcon setImage:[ZCUITools zcuiGetBundleImage:@"zciocn_point_old"]];
    }
    
   
    self.contentView.frame = CGRectMake(0, 0, ScreenWidth, CGRectGetMaxY(_replycont.frame) + ZCNumber(5));
    self.frame = self.contentView.frame;
     _lineView.frame = CGRectMake(ZCNumber(22.5), CGRectGetMaxY(_statusLab.frame) + ZCNumber(8), 1, CGRectGetHeight(self.frame) -(CGRectGetMaxY(_statusLab.frame) + ZCNumber(10)));
    if (model.flag == 1) {
        _lineView.hidden = YES;
    }else{
         _lineView.hidden = NO;
    }
}

#pragma mark -- 计算文本高度
-(CGRect)getTextRectWith:(NSString *)str WithMaxWidth:(CGFloat)width  WithlineSpacing:(CGFloat)LineSpacing AddLabel:(UILabel *)label{
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc]initWithString:str];
    NSMutableParagraphStyle * parageraphStyle = [[NSMutableParagraphStyle alloc]init];
    [parageraphStyle setLineSpacing:LineSpacing];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:parageraphStyle range:NSMakeRange(0, [str length])];
    [attributedString addAttribute:NSFontAttributeName value:label.font range:NSMakeRange(0, str.length)];
    
    label.attributedText = attributedString;
    
    CGSize size = [self autoHeightOfLabel:label with:width];
    
    CGRect labelF = label.frame;
    labelF.size.height = size.height;
    label.frame = labelF;
    
    
    return labelF;
}

/**
 计算Label高度
 
 @param label 要计算的label，设置了值
 @param width label的最大宽度
 @param type 是否从新设置宽，1设置，0不设置
 */
- (CGSize )autoHeightOfLabel:(UILabel *)label with:(CGFloat )width{
    //Calculate the expected size based on the font and linebreak mode of your label
    // FLT_MAX here simply means no constraint in height
    CGSize maximumLabelSize = CGSizeMake(width, FLT_MAX);
    
    CGSize expectedLabelSize = [label sizeThatFits:maximumLabelSize];// 返回最佳的视图大小
    
    //adjust the label the the new height.
    CGRect newFrame = label.frame;
    newFrame.size.height = expectedLabelSize.height;
    label.frame = newFrame;
    [label updateConstraintsIfNeeded];
    
    return expectedLabelSize;
}




//- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
//    [super setSelected:selected animated:NO];
//
//    // Configure the view for the selected state
//}

-(NSString *)getTimeTextStr:(NSString *)time{
    // iOS 生成的时间戳是10位
    NSTimeInterval interval    = [time doubleValue];
    NSDate *date               = [NSDate dateWithTimeIntervalSince1970:interval];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *dateString       = [formatter stringFromDate: date];
    return  dateString;
}

@end
