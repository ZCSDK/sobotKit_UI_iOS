//
//  ZCAccessInformationVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCAccessInformationVC.h"
#import "ZCSettingCell.h"
#define cellSetIdentifier @"ZCSettingCell"
#import "ZCSetServiceTypeVC.h"
#import "ZCSettingGoodVC.h"
#import "ZCSettingGuideVC.h"
#import "ZCTurnServicesVC.h"
#import "ZCCustomTitleVC.h"
#import "ZCDetailVC.h"

@interface ZCAccessInformationVC ()<UITableViewDelegate,UITableViewDataSource>{
    
}

@property (nonatomic,strong) NSMutableArray * listArray;

@property (nonatomic,strong) UITableView * listTable;

@end

@implementation ZCAccessInformationVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (_listArray == nil) {
        _listArray = [NSMutableArray arrayWithCapacity:0];
    }
    [self createNavc];
    [self createTableView];
    [self loadData];
}


-(void)createNavc{
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"接入信息";
    
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    [leftBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 0);
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
}

-(void)backAction:(UIButton*)sender{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)createTableView{
    _listTable = [[UITableView alloc]initWithFrame:CGRectMake(0, NavBarHeight, ScreenHeight, ScreenHeight - NavBarHeight) style:UITableViewStylePlain];
    _listTable.delegate = self;
    _listTable.dataSource = self;
    [self.view addSubview:_listTable];
    
    // 注册cell
    [_listTable registerNib:[UINib nibWithNibName:cellSetIdentifier bundle:nil] forCellReuseIdentifier:cellSetIdentifier];
    
    UIView * footView = [[UIView alloc]initWithFrame:CGRectMake(0, 1, ScreenWidth, ScreenHeight/2)];
    footView.backgroundColor = UIColorFromRGB(0xEFF3FA);
    _listTable.tableFooterView = footView;
    
    [_listTable setSeparatorColor:UIColorFromRGB(0xdadada)];
    [_listTable setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    [self setTableSeparatorInset];
}


-(void)loadData{
    // @"cellType"   0 默认状态  1，右边添加选中的箭头   2单选样式
    [_listArray removeAllObjects];
    NSString * serverModel = @"默认";
    
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
    if ([userDefaults valueForKey:@"serverModel"] != nil) {
        switch ([[userDefaults valueForKey:@"serverModel"] intValue]) {
            case 0:
                serverModel = @"默认";
                break;
            case 1:
                serverModel = @"仅机器人";
                break;
            case 2:
                serverModel = @"仅人工";
                break;
            case 3:
                serverModel = @"机器人优先";
                break;
            case 4:
                serverModel = @"人工优先";
                break;
            default:
                break;
        }
    }
    
    [_listArray addObject:@{@"code":@"21",
                            @"dictName":@"接入模式",
                            @"dictDesc":@"接入模式",
                            @"placeholder":@"",
                            @"dictValue":serverModel,
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}
                            }];
    
    [_listArray addObject:@{@"code":@"22",
                            @"dictName":@"商品信息",
                            @"dictDesc":@"商品信息",
                            @"placeholder":@"",
                            @"dictValue":@"",
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}
                            }];
    
    [_listArray addObject:@{@"code":@"23",
                            @"dictName":@"引导语",
                            @"dictDesc":@"引导语",
                            @"placeholder":@"",
                            @"dictValue":@"",
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}}];
    
    
    [_listArray addObject:@{@"code":@"24",
                            @"dictName":@"转人工设置",
                            @"dictDesc":@"转人工设置",
                            @"placeholder":@"",
                            @"dictValue":@"",
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}
                            }];
    
    [_listArray addObject:@{@"code":@"25",
                            @"dictName":@"历史记录时间",
                            @"dictDesc":@"scopeTime",
                            @"placeholder":@"请输入历史记录时间范围",
                            @"dictValue":@"",
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}
                            }];
    
    
    [_listArray addObject:@{@"code":@"26",
                            @"dictName":@"自定义标题",
                            @"dictDesc":@"自定义标题",
                            @"placeholder":@"",
                            @"dictValue":@"",
                            @"cellType":@"0",
                            @"propertyType":@"0",
                            @"contentDict":@{}
                            }];
    
    [_listTable reloadData];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _listArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ZCSettingCell * cell = (ZCSettingCell*)[tableView dequeueReusableCellWithIdentifier:cellSetIdentifier];
    if (cell == nil) {
        cell =[[ZCSettingCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellSetIdentifier];
    }
    
    NSDictionary * dic = _listArray[indexPath.row];
    [cell initWithNSDictionary:dic];
    
    return cell;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    return nil;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    return  nil;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];// 取消选中
    __weak  ZCAccessInformationVC  * safeVC = self;
    NSDictionary * dic =_listArray[indexPath.row];
    switch ([dic[@"code"] intValue]) {
        case 21:{
            ZCSetServiceTypeVC * typeVC = [[ZCSetServiceTypeVC alloc]init];
            typeVC.type = [ZCLibClient getZCLibClient].libInitInfo.serviceMode;
            typeVC.refreshValueBlock = ^{
                [safeVC loadData];
            };
            [self.navigationController pushViewController:typeVC animated:YES];
        }
            break;
        case 22:{
            ZCSettingGoodVC * goodVC = [[ZCSettingGoodVC alloc]init];
            goodVC.uiInfo = _kitInfo;
            [self.navigationController pushViewController:goodVC animated:YES];
        }
            break;
        case 23:{
            ZCSettingGuideVC * guideVC = [[ZCSettingGuideVC alloc]init];
            guideVC.passWorkBlock = ^(ZCLibInitInfo *libInitInfo) {
                [ZCLibClient getZCLibClient].libInitInfo = libInitInfo;
            };
            [self.navigationController pushViewController:guideVC animated:YES];
        }
            break;
        case 24:{
            ZCTurnServicesVC * turnVC = [[ZCTurnServicesVC alloc]init];
            turnVC.kitInfo = _kitInfo;
            turnVC.passWordkitInfoBlock = ^(ZCKitInfo *kitInfo) {
                safeVC.kitInfo = kitInfo;
            };
            [self.navigationController pushViewController:turnVC animated:YES];
        }
            break;
        case 25:{
            ZCDetailVC * detailVC = [[ZCDetailVC alloc]init];
            detailVC.code = dic[@"code"];
            detailVC.titleName = dic[@"dictName"];
            detailVC.dictDesc = dic[@"dictDesc"];
            detailVC.placeholder = dic[@"placeholder"];
            
            [self.navigationController pushViewController:detailVC animated:YES];
        }
            break;
        case 26:{
            ZCCustomTitleVC * customTitleVC = [[ZCCustomTitleVC alloc]init];
            [self.navigationController pushViewController:customTitleVC animated:YES];
        }
            break;
            
        default:
            break;
    }
}
/**
 *  设置UITableView分割线空隙
 */
-(void)setTableSeparatorInset{
    UIEdgeInsets inset = UIEdgeInsetsMake(0, 10, 0, 0);
    if ([_listTable respondsToSelector:@selector(setSeparatorInset:)]) {
        [_listTable setSeparatorInset:inset];
    }
    
    if ([_listTable respondsToSelector:@selector(setLayoutMargins:)]) {
        [_listTable setLayoutMargins:inset];
    }
}


//设置分割线间距
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    if((indexPath.row+1) < _listArray.count){
        UIEdgeInsets inset = UIEdgeInsetsMake(0, 10, 0, 0);
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
            [cell setSeparatorInset:inset];
        }
        
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:inset];
        }
    }
}


//去掉UItableview headerview黏性
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == self.listTable)
    {
        CGFloat sectionHeaderHeight = 50;
        if (scrollView.contentOffset.y<=sectionHeaderHeight&&scrollView.contentOffset.y>=0) {
            scrollView.contentInset = UIEdgeInsetsMake(-scrollView.contentOffset.y, 0, 0, 0);
        } else if (scrollView.contentOffset.y>=sectionHeaderHeight) {
            scrollView.contentInset = UIEdgeInsetsMake(-sectionHeaderHeight, 0, 0, 0);
        }
    }
}

@end
