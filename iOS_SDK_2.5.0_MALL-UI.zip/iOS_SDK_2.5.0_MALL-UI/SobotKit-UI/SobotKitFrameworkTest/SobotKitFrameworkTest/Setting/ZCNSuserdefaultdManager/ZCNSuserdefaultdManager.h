//
//  ZCNSuserdefaultdManager.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/30.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZCNSuserdefaultdManager : NSObject

@property (nonatomic,assign) int type; // 0 测试用的appkey 1 上线后全部添加公司的appkey


-(void)openSDKWith:(UIViewController *)byController;


+(instancetype)shareUserdefaultd;

-(void)defatlutsRemoveAllObject;

//-(void)clearAllUserDefaultsData;

@end
