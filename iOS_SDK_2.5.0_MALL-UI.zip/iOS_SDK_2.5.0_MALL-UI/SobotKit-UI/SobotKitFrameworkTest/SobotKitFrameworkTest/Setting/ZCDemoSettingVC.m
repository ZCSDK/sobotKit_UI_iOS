//
//  ZCDemoSettingVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCDemoSettingVC.h"
#import "ZCSettingCell.h"
#import "ZCSettingPushVC.h"

#define cellSetIdentifier @"ZCSettingCell"
#import "ZCSettingevaluationVC.h"
#import "ZCSettingeRobotVC.h"
#import "ZCSkillSetVC.h"
#import "ZCSettingAidVC.h"
#import "ZCAccessInformationVC.h"
#import "ZCUserSettingVC.h"
@interface ZCDemoSettingVC ()<UITableViewDelegate,UITableViewDataSource>{
    
}

@property (nonatomic,strong) NSMutableArray * listArray;

@property (nonatomic,strong) UITableView * listTable;

@end

@implementation ZCDemoSettingVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (_listArray == nil) {
        _listArray = [NSMutableArray arrayWithCapacity:0];
    }
    [UITabBar appearance].translucent = NO;
    [[UITabBar appearance] setBarTintColor:[UIColor whiteColor]];
    [self.navigationController.navigationBar setBarTintColor:[UIColor whiteColor]];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    [self createTableView];
    [self loadData];
    
    
    self.view.backgroundColor = UIColorFromRGB(0xEFF3FA);
    
}



-(void)createTableView{
    _listTable = [[UITableView alloc]initWithFrame:CGRectMake(0, NavBarHeight, ScreenHeight, ScreenHeight - NavBarHeight) style:UITableViewStylePlain];
    _listTable.delegate = self;
    _listTable.dataSource = self;
    [self.view addSubview:_listTable];
    
    // 注册cell
    [_listTable registerNib:[UINib nibWithNibName:cellSetIdentifier bundle:nil] forCellReuseIdentifier:cellSetIdentifier];
    
    UIView * footView = [[UIView alloc]initWithFrame:CGRectMake(0, 1, ScreenWidth, ScreenHeight/2)];
    footView.backgroundColor = UIColorFromRGB(0xEFF3FA);
    _listTable.tableFooterView = footView;
    [_listTable setSeparatorColor:UIColorFromRGB(0xdadada)];
    [_listTable setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
     [self setTableSeparatorInset];
}


-(void)loadData{
    
    // @"cellType"   0 默认状态  1，右边添加选中的箭头   2单选样式
    [_listArray removeAllObjects];
    
    [_listArray addObject:@{@"code":@"1",
                      @"dictName":@"基本设置",
                      @"dictDesc":@"基本设置",
                      @"placeholder":@"",
                      @"dictValue":@"",
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    [_listArray addObject:@{@"code":@"2",
                      @"dictName":@"接入信息",
                      @"dictDesc":@"接入信息",
                      @"placeholder":@"",
                      @"dictValue":@"",
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    [_listArray addObject:@{@"code":@"3",
                      @"dictName":@"对接客服",
                      @"dictDesc":@"对接客服",
                      @"placeholder":@"",
                      @"dictValue":@"",
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}}];
    
    
    [_listArray addObject:@{@"code":@"4",
                      @"dictName":@"对接技能组",
                      @"dictDesc":@"对接技能组",
                      @"placeholder":@"",
                      @"dictValue":@"",
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    [_listArray addObject:@{@"code":@"5",
                      @"dictName":@"对接机器人",
                      @"dictDesc":@"对接机器人",
                      @"placeholder":@"",
                      @"dictValue":@"",
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    
    [_listArray addObject:@{@"code":@"6",
                      @"dictName":@"评价",
                      @"dictDesc":@"评价",
                      @"placeholder":@"",
                      @"dictValue":@"",
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    [_listArray addObject:@{@"code":@"7",
                      @"dictName":@"推送",
                      @"dictDesc":@"推送",
                      @"placeholder":@"",
                      @"dictValue":@"",
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    [_listArray addObject:@{@"code":@"8",
                      @"dictName":@"结束会话",
                      @"dictDesc":@"scopeTime",
                      @"placeholder":@"",
                      @"dictValue":@"",
                      @"cellType":@"0",
                      @"propertyType":@"0",
                      @"contentDict":@{}
                      }];
    
    
    [_listTable reloadData];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _listArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ZCSettingCell * cell = (ZCSettingCell*)[tableView dequeueReusableCellWithIdentifier:cellSetIdentifier];
    if (cell == nil) {
        cell =[[ZCSettingCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellSetIdentifier];
    }
    
    NSDictionary * dic = _listArray[indexPath.row];
    [cell initWithNSDictionary:dic];
    // 设置分割线
    if(indexPath.row==_listArray.count-1){
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
            [cell setSeparatorInset:UIEdgeInsetsZero];
        }
        
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:UIEdgeInsetsZero];
        }
        
        if([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]){
            [cell setPreservesSuperviewLayoutMargins:NO];
        }
    }
    return cell;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    return nil;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{

    return  nil;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];// 取消选中
    __weak  ZCDemoSettingVC  * safeVC = self;
    NSDictionary * dic =_listArray[indexPath.row];
    switch ([dic[@"code"] intValue]) {
        case 1:
        {
            ZCUserSettingVC * userSettingVC = [[ZCUserSettingVC alloc]init];
            [self.navigationController pushViewController:userSettingVC animated:YES];
        }
            break;
        case 2:
        {
            ZCAccessInformationVC * accessInformationVC = [[ZCAccessInformationVC alloc]init];
            [self.navigationController pushViewController:accessInformationVC animated:YES];
        }
            break;
        case 3:{
            ZCSettingAidVC * aidVC = [[ZCSettingAidVC alloc]init];
            [self.navigationController pushViewController:aidVC animated:YES];
        }
            
            break;
        case 4:{
            ZCSkillSetVC * skillVC = [[ZCSkillSetVC alloc]init];
            [self.navigationController pushViewController:skillVC animated:YES];
        }
            
            break;
        case 5:{
            ZCSettingeRobotVC *settingRobotVC = [[ZCSettingeRobotVC alloc]init];
            [self.navigationController pushViewController:settingRobotVC animated:YES];
        }
            
            break;
        case 6:{
            ZCSettingevaluationVC * evaluationVC = [[ZCSettingevaluationVC alloc]init];
            evaluationVC.kitInfo =  _kitInfo;
            evaluationVC.evaluationBlock = ^(ZCKitInfo *kitInfo) {
                safeVC.kitInfo = kitInfo;
            };
            [self.navigationController pushViewController:evaluationVC animated:YES];
        }
            
            break;
        case 7:{
            ZCSettingPushVC * pushVC = [[ZCSettingPushVC alloc]init];
            [self.navigationController pushViewController:pushVC animated:YES];
        }
            break;
        case 8:
            [ZCLibClient closeAndoutZCServer:YES];
            // 将是否显示转人工按钮的设置回复默认值
            [ZCLibClient getZCLibClient].isShowTurnBtn = NO;
            
           UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"会话已结束" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alertView show];
            break;
    }
}


/**
 *  设置UITableView分割线空隙
 */
-(void)setTableSeparatorInset{
    UIEdgeInsets inset = UIEdgeInsetsMake(0, 10, 0, 0);
    if ([_listTable respondsToSelector:@selector(setSeparatorInset:)]) {
        [_listTable setSeparatorInset:inset];
    }
    
    if ([_listTable respondsToSelector:@selector(setLayoutMargins:)]) {
        [_listTable setLayoutMargins:inset];
    }
}


//设置分割线间距
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    if((indexPath.row+1) < _listArray.count){
        UIEdgeInsets inset = UIEdgeInsetsMake(0, 10, 0, 0);
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
            [cell setSeparatorInset:inset];
        }
        
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:inset];
        }
    }
}

//去掉UItableview headerview黏性
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == self.listTable)
    {
        CGFloat sectionHeaderHeight = 50;
        if (scrollView.contentOffset.y<=sectionHeaderHeight&&scrollView.contentOffset.y>=0) {
            scrollView.contentInset = UIEdgeInsetsMake(-scrollView.contentOffset.y, 0, 0, 0);
        } else if (scrollView.contentOffset.y>=sectionHeaderHeight) {
            scrollView.contentInset = UIEdgeInsetsMake(-sectionHeaderHeight, 0, 0, 0);
        }
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
