//
//  ZCSettingevaluationVC.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/23.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^EvaluationBlock)(ZCKitInfo * kitInfo);

@interface ZCSettingevaluationVC : UIViewController
@property (weak, nonatomic) IBOutlet UISwitch *isBackevaluationSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *isCloseSessionWhenBackSwitch;

@property (nonatomic,strong) ZCKitInfo * kitInfo;

@property (nonatomic,copy) EvaluationBlock evaluationBlock;

@property (weak, nonatomic) IBOutlet UIScrollView *bgScrollView;

@property (weak, nonatomic) IBOutlet UIView *lineView;

@end
