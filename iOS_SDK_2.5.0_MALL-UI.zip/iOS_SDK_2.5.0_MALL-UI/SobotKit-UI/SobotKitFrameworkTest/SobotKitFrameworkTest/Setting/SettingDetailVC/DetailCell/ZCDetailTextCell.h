//
//  ZCDetailTextCell.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/21.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^TextValueChangeBlock)(NSString * textValue);


@protocol ZCDetailTextCellDelegate <NSObject>
@optional

-(void)textValueChange:(UITextField*)textValue WithDict:(NSDictionary *)dict;

- (void) markPiontActionWithTextField:(UITextField *)textField;

- (void)changePiontAction:(UITextField*)textField;

@end


@interface ZCDetailTextCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UITextField *textField;

@property (weak, nonatomic) IBOutlet UILabel *titleLab;

@property (nonatomic,copy)TextValueChangeBlock textValueBlock;

@property (nonatomic,assign) id <ZCDetailTextCellDelegate> delegate;


-(void)initWithDict:(NSDictionary *)dict;



@end
