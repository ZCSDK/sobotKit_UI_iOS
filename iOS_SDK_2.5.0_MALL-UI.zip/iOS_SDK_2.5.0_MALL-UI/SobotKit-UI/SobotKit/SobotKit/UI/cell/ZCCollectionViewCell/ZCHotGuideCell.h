//
//  ZCHotGuideCell.h
//  SobotKit
//
//  Created by lizhihui on 2018/1/11.
//  Copyright © 2018年 zhichi. All rights reserved.
//

#import "ZCChatBaseCell.h"

@interface ZCHotGuideCell : ZCChatBaseCell

@end
