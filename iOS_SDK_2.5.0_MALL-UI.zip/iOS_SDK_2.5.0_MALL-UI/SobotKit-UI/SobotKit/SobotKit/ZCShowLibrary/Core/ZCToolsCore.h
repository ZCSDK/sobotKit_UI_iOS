//
//  ZCToolsCore.h
//  SobotKit
//
//  Created by zhangxy on 2018/1/29.
//  Copyright © 2018年 zhichi. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 工具类
 如：
    图片处理
    获取图片地址
 
 */
@interface ZCToolsCore : NSObject

+(ZCToolsCore *)getToolsCore;



-(void)clear;

@end
