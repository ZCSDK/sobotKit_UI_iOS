//
//  ZCRobotIntroduceView.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/12/8.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCRobotIntroduceView : UIView


-(instancetype)initWithFrame:(CGRect)frame WithDict:(NSDictionary *)dict WithSuperView:(UIView*)superView;

@end
