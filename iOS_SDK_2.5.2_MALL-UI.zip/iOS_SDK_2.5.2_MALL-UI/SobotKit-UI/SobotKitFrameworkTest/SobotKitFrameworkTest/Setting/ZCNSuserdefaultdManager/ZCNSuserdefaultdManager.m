//
//  ZCNSuserdefaultdManager.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/30.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCNSuserdefaultdManager.h"
#import <SobotKit/SobotKit.h>
#import <SobotKit/ZCUIChatController.h>

@implementation ZCNSuserdefaultdManager

  static id _instance;
+(instancetype)shareUserdefaultd{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[self alloc]init];
    });
    return _instance;
}


-(void)openSDKWith:(UIViewController *)byController{
    //  初始化配置信息
    ZCLibInitInfo *initInfo = [ZCLibClient getZCLibClient].libInitInfo;
    [self setZCLibInitInfoParam:initInfo];
    
    //自定义用户参数
    [self customUserInformationWith:initInfo];
    
    ZCKitInfo *uiInfo=[ZCKitInfo new];
    
    
    // 自定义UI(设置背景颜色相关)
    [self customerUI:uiInfo];
    
    
    // 之定义商品和留言页面的相关UI
//    [self customerGoodAndLeavePageWithParameter:uiInfo];
    
    
    // 自定义提示语相关设置
    [self customTipWord:initInfo];

    // 未读消息
//    [self customUnReadNumber:uiInfo];
    
    // 测试模式
    [ZCSobot setShowDebug:YES];
    
    [[ZCLibClient getZCLibClient] setLibInitInfo:initInfo];
    //    ViewController *VC = [[ViewController alloc]init];
    //    if (self.isOpenLeaveMsgSwitch.on) {
    //        VC = self;
    //    }else{
    //        VC = nil;
    //    }
    
    
    
    
    // 启动
    [ZCSobot startZCChatView:uiInfo with:byController target:nil pageBlock:^(ZCUIChatController *object, ZCPageBlockType type) {
        
        // 点击返回
        if(type==ZCPageBlockGoBack){
            NSLog(@"点击了关闭按钮");
            // 显示导航栏
//             NSLog(@"%@",[[ZCLibClient getZCLibClient] getLastMessage]);
        }
        
        // 页面UI初始化完成，可以获取UIView，自定义UI
        if(type==ZCPageBlockLoadFinish){
            
        }
        
    } messageLinkClick:nil];
    
}


-(void)defatlutsRemoveAllObject{
    NSUserDefaults *defatluts = [NSUserDefaults standardUserDefaults];
    NSDictionary *dictionary = [defatluts dictionaryRepresentation];
    for(NSString *key in [dictionary allKeys]){
        [defatluts removeObjectForKey:key];
        [defatluts synchronize];
    }
}

//-(void)clearAllUserDefaultsData{
//    NSString * appDomain = [[NSBundle mainBundle] bundleIdentifier];
//    [[NSUserDefaults standardUserDefaults]removePersistentDomainForName:appDomain];
//}


- (void)customTipWord:(ZCLibInitInfo*)initInfo{
    
    // 用户超时下线提示语
    initInfo.customUserOutWord = ZCUserDefaultsGetValue(@"customUserOutWord");//_customUserOutWord.text;
    
    // 用户超时提示语
    initInfo.customUserTipWord = ZCUserDefaultsGetValue(@"customUserTipWord");//_customUserTipWord.text;
    
    // 人工客服提示语
    initInfo.customAdminTipWord = ZCUserDefaultsGetValue(@"customAdminTipWord");//_customAdminTipWord.text;
    
    // 机器人欢迎语
    initInfo.customRobotHelloWord = ZCUserDefaultsGetValue(@"customRobotHelloWord");//_customRobotHelloWord.text;
    
    // 暂无客服在线说辞
    initInfo.customAdminNonelineTitle = ZCUserDefaultsGetValue(@"customAdminNonelineTitle");//_customAdminNonelineTitle.text;
    
    // 人工客服欢迎语
    initInfo.customAdminHelloWord  = ZCUserDefaultsGetValue(@"customAdminHelloWord");//_customAdminHelloWord.text;
}


- (void)setZCLibInitInfoParam:(ZCLibInitInfo *)initInfo{
    
    NSString * appkey ;
        appkey = @"1ff3e4ff91314f5ca308e19570ba24bb";
    

    
    // 获取AppKey
    initInfo.appKey = ZCUserDefaultsGetValue(@"appkey"); // _appKeyTF.text;appkey;//
    if (_type ==1) {
        initInfo.appKey = @"";
    }

    
    initInfo.skillSetId = ZCUserDefaultsGetValue(@"skillSetId");//_groupIdTF.text;
    initInfo.skillSetName = ZCUserDefaultsGetValue(@"skillSetName");//_groupNameTF.text;
    initInfo.receptionistId = ZCUserDefaultsGetValue(@"receptionistId");//@"927dc485c6ff4dd7ad26b7e07649eccb"; //_aidTF.text;
    initInfo.robotId = ZCUserDefaultsGetValue(@"robotId");//_robotIdTF.text;
    initInfo.tranReceptionistFlag = (int)[ZCUUserDefaults boolForKey:@"tranReceptionistFlag"];//1;//_aidTurn;
    initInfo.scopeTime = [ZCUserDefaultsGetValue(@"scopeTime") intValue];//[_historyScopeTF.text intValue];
    initInfo.titleType = ZCUserDefaultsGetValue(@"titleType");//titleType;
    initInfo.customTitle = ZCUserDefaultsGetValue(@"customTitle");//_titleCustomTF.text;
    
}


// 设置UI部分
-(void) customerUI:(ZCKitInfo *) kitInfo{
        kitInfo.isCloseAfterEvaluation = YES;
    //    // 点击返回是否触发满意度评价（符合评价逻辑的前提下）
    //    kitInfo.isOpenEvaluation = _isBackSwitch.on;
    //
    //
    //    // 是否显示语音按钮
    //    kitInfo.isOpenRecord = _isOpenVideoSwitch.on;
    //
    //    // 是否显示转人工按钮
    //    kitInfo.isShowTansfer    = _isShowTansferSwitch.on;
    //    // 评价完人工是否关闭会话
    //    kitInfo.isCloseAfterEvaluation = _isCloseSessionWhenBackSwitch.on;
    //
    //    if (!kitInfo.isShowTansfer) {
    //        kitInfo.unWordsCount = _robotUnknowCount.text;
    //    }
    //
    //    kitInfo.isOpenActiveUser = _isOpenTurnSwitch.on;
    //    if (_turnKeyWord.text.length>0) {
    //
    //        kitInfo.activeKeywords = [NSDictionary dictionaryWithObject:@"" forKey:_turnKeyWord.text];
    ////        [kitInfo.activeKeywords setValue:@"" forKey:_turnKeyWord.text];
    //    }
    //    kitInfo.activeKeywords =  //@{@"转人工":@"",@"R":@"",@"r":@""};
    
    
    kitInfo.isCloseAfterEvaluation = [ZCUUserDefaults boolForKey:@"isCloseAfterEvaluation"] ;//  YES;
    // 点击返回是否触发满意度评价（符合评价逻辑的前提下）
    kitInfo.isOpenEvaluation = [ZCUUserDefaults boolForKey:@"isOpenEvaluation"];//_isBackSwitch.on;
    
    
    // 是否显示语音按钮
    
    if ([ZCUUserDefaults valueForKey:@"isOpenRecord"] == nil) {
        kitInfo.isOpenRecord = YES;
        [ZCUUserDefaults setBool:YES forKey:@"isOpenRecord"];
        
    }else{
        kitInfo.isOpenRecord = [ZCUUserDefaults boolForKey:@"isOpenRecord"];//_isOpenVideoSwitch.on;
    }
    
    if (kitInfo.isOpenRecord) {
        kitInfo.isOpenRobotVoice = YES;
    }else{
        kitInfo.isOpenRobotVoice = NO;
    }
    
    // 是否显示转人工按钮
    if ([ZCUUserDefaults valueForKey:@"isShowTansfer"] == nil) {
        kitInfo.isShowTansfer = YES;
        [ZCUUserDefaults setBool:YES forKey:@"isShowTansfer"];
    }else{
        kitInfo.isShowTansfer    = [ZCUUserDefaults boolForKey:@"isShowTansfer"];//_isShowTansferSwitch.on;
    }
    
    
    
    if (!kitInfo.isShowTansfer) {
        kitInfo.unWordsCount = ZCUserDefaultsGetValue(@"unWordsCount");//_robotUnknowCount.text;
    }
    
    kitInfo.isOpenActiveUser = [ZCUUserDefaults boolForKey:@"isOpenActiveUser"];//_isOpenTurnSwitch.on;
    //    if (_turnKeyWord.text.length>0) {
    
    kitInfo.activeKeywords = ZCUserDefaultsGetValue(@"activeKeywords");//[NSDictionary dictionaryWithObject:@"" forKey:_turnKeyWord.text];
    NSString * activeKeywords = @"";
    if (ZCUserDefaultsGetValue(@"activeKeywords")!= nil) {
        activeKeywords = ZCUserDefaultsGetValue(@"activeKeywords");
    }
    if (![activeKeywords isEqualToString:@""]) {
        kitInfo.activeKeywords = [NSDictionary dictionaryWithObject:@"" forKey:activeKeywords];
    }
    
    //        [kitInfo.activeKeywords setValue:@"" forKey:_turnKeyWord.text];
    //    }
    //    kitInfo.activeKeywords =  //@{@"转人工":@"",@"R":@"",@"r":@""};
    
    
    
    /**
     *  自定义信息
     */
    // 顶部导航条标题文字 评价标题文字 系统相册标题文字 评价客服（立即结束 取消）按钮文字
    //    kitInfo.titleFont = [UIFont systemFontOfSize:30];
    
    // 返回按钮      输入框文字   评价客服是否有以下情况 label 文字  提价评价按钮
    //    kitInfo.listTitleFont = [UIFont systemFontOfSize:22];
    
    //没有网络提醒的button 没有更多记录label的文字    语音tipLabel的文字   评价不满意（4个button）文字  占位图片的lablel文字   语音输入时间label文字   语音输入的按钮文字
    //    kitInfo.listDetailFont = [UIFont systemFontOfSize:25];
    
    // 录音按钮的文字
    //    kitInfo.voiceButtonFont = [UIFont systemFontOfSize:25];
    // 消息提醒 （转人工、客服接待等）
    //    kitInfo.listTimeFont = [UIFont systemFontOfSize:22];
    
    // 聊天气泡中的文字
    //    kitInfo.chatFont  = [UIFont systemFontOfSize:22];
    
    // 聊天的背景颜色
    //    kitInfo.backgroundColor = [UIColor redColor];
    
    // 导航、客服气泡、线条的颜色
    //            kitInfo.customBannerColor  = [UIColor redColor];
    
    // 左边气泡的颜色
    //        kitInfo.leftChatColor = [UIColor redColor];
    
    // 右边气泡的颜色
    //        kitInfo.rightChatColor = [UIColor redColor];
    
    // 底部bottom的背景颜色
    //    kitInfo.backgroundBottomColor = [UIColor redColor];
    
    // 底部bottom的输入框线条背景颜色
    //    kitInfo.bottomLineColor = [UIColor redColor];
    
    // 提示气泡的背景颜色
    //    kitInfo.BgTipAirBubblesColor = [UIColor redColor];
    
    // 顶部文字的颜色
    //    kitInfo.topViewTextColor  =  [UIColor redColor];
    
    // 提示气泡文字颜色
    //        kitInfo.tipLayerTextColor = [UIColor redColor];
    
    // 评价普通按钮选中背景颜色和边框(默认跟随主题色customBannerColor)
    //            kitInfo.commentOtherButtonBgColor=[UIColor redColor];
    
    // 评价背景颜色(默认跟随主题色customBannerColor)
    //        kitInfo.commentCommitButtonColor = [UIColor redColor];
    
    //评价提交按钮背景颜色和边框(默认跟随主题色customBannerColor)
    //    kitInfo.commentCommitButtonBgColor = [UIColor redColor];
    
    //    评价提交按钮点击后背景色，默认0x089899, 0.95
    //    kitInfo.commentCommitButtonBgHighColor = [UIColor yellowColor];
    
    // 左边气泡文字的颜色
    //    kitInfo.leftChatTextColor = [UIColor redColor];
    
    // 右边气泡文字的颜色[注意：语音动画图片，需要单独替换]
    //    kitInfo.rightChatTextColor  = [UIColor redColor];
    
    // 时间文字的颜色
    //    kitInfo.timeTextColor = [UIColor redColor];
    
    // 客服昵称颜色
    //        kitInfo.serviceNameTextColor = [UIColor redColor];
    
    
    // 提交评价按钮的文字颜色
    //        kitInfo.submitEvaluationColor = [UIColor blueColor];
    
    // 相册的导航栏背景颜色
    
    //    kitInfo.imagePickerColor =   _selectedColor;
    // 相册的导航栏标题的文字颜色
    //    kitInfo.imagePickerTitleColor = [UIColor redColor];
    
    // 左边超链的颜色
    //        kitInfo.chatLeftLinkColor = [UIColor blueColor];
    
    // 右边超链的颜色
    //        kitInfo.chatRightLinkColor =[UIColor redColor];
    
    // 提示客服昵称的文字颜色
    //    kitInfo.nickNameTextColor = [UIColor redColor];
    // 相册的导航栏是否设置背景图片(图片来自SobotKit.bundle中zcicon_navcbgImage)
    //    kitInfo.isSetPhotoLibraryBgImage = YES;
    
    // 富媒体cell中线条的背景色
    //    kitInfo.LineRichColor = [UIColor redColor];
    
    //    // 语音cell选中的背景颜色
    //    kitInfo.videoCellBgSelColor = [UIColor redColor];
    //
    //    // 商品cell中标题的文字颜色
    //    kitInfo.goodsTitleTextColor = [UIColor redColor];
    //
    //    // 商品详情cell中摘要的文字颜色
    //    kitInfo.goodsDetTextColor = [UIColor redColor];
    //
    //    // 商品详情cell中标签的文字颜色
    //    kitInfo.goodsTipTextColor = [UIColor redColor];
    //
    //    // 商品详情cell中发送的文字颜色
    //    kitInfo.goodsSendTextColor = [UIColor redColor];
    
    // 发送按钮的背景色
    //        kitInfo.goodSendBtnColor = [UIColor yellowColor];
    
    // “连接中。。。”  button 的背景色和文字的颜色
    //    kitInfo.socketStatusButtonBgColor  = [UIColor yellowColor];
    //    kitInfo.socketStatusButtonTitleColor = [UIColor redColor];
    
    //    kitInfo.notificationTopViewLabelFont = [UIFont systemFontOfSize:20];
    //    kitInfo.notificationTopViewLabelColor = [UIColor yellowColor];
    //    kitInfo.notificationTopViewBgColor = [UIColor redColor];
    
    // 评价 已解决 未解决的 颜色
    //    kitInfo.satisfactionSelectedBgColor = [UIColor redColor];
    //    kitInfo.satisfactionTextSelectedColor = [UIColor blueColor];
    
    
    // 机器人问答触发转人工按钮
    kitInfo.trunServerBtnColor = [UIColor redColor];
    
    
}


// 自定义用户信息参数
- (void)customUserInformationWith:(ZCLibInitInfo*)initInfo{
    initInfo.userId         = ZCUserDefaultsGetValue(@"userID");//_userIdTF.text;
    //    initInfo.customInfo = @{@"标题1":@"自定义1",@"内容1":@"我是一个自定义字段。",@"标题2":@"自定义字段2",@"内容2":@"我是一个自定义字段，我是一个自定义字段，我是一个自定义字段，我是一个自定义字段。",@"标题3":@"自定义字段字段3",@"内容3":@"<a href=\"www.baidu.com\" target=\"_blank\">www.baidu.com</a>",@"标题4":@"自定义4",@"内容4":@"我是一个自定义字段 https://www.sobot.com/chat/pc/index.html?sysNum=9379837c87d2475dadd953940f0c3bc8&partnerId=112"};
    
    NSUserDefaults *user  = [NSUserDefaults standardUserDefaults];
    initInfo.email        = [user valueForKey:@"email"];
    initInfo.avatarUrl    = [user valueForKey:@"avatarUrl"];
    //    initInfo.sourceURL    = [user valueForKey:@"sourceURL"];
    initInfo.sourceURL = @"http://mall.haoyunbang.com.cn/hmall/v2/order/confirm?goods_id=582d60560cf24af052c05b71";
    
    initInfo.sourceTitle  = [user valueForKey:@"sourceTitle"];
    initInfo.serviceMode  = [ZCUserDefaultsGetValue(@"serverModel") intValue];//_type;
    
    // 以下字段为方便测试使用，上线打包时注掉
    initInfo.phone       = [user valueForKey:@"phone"];
    initInfo.nickName    = [user valueForKey:@"nickName"];
    // 微信，微博，用户的真实昵称，生日，备注性别 QQ号
    // 生日字段用户传入的格式，例：20170323，如果不是这个格式，初始化接口会给过滤掉
    
    initInfo.qqNumber = [user valueForKey:@"qqNumber"];
    initInfo.userSex = [user valueForKey:@"userSex"];
    //    initInfo.userSex = @"";
    initInfo.realName = [user valueForKey:@"useName"];
    initInfo.weiBo = [user valueForKey:@"weiBo"];
    initInfo.weChat = [user valueForKey:@"weChat"];
    initInfo.userBirthday = [user valueForKey:@"userBirthday"];
    initInfo.userRemark = [user valueForKey:@"userRemark"];
    
    initInfo.customerFields = @{@"customField22":@"我是自定义的分校",
                                @"userSex":@"保密",
                                @"weixin":@"微信号",
                                @"weibo":@"微博账号",
                                @"birthday":@"2017-06-08"};

    
    //    NSDictionary * dict = [NSDictionary dictionaryWithObjectsAndKeys:initInfo.phone,@"tel",useName,@"realname",initInfo.email,@"email",initInfo.nickName,@"uname" ,weChat,@"weixin",weibo,@"weibo",sex,@"sex",userBirthday,@"birthday",userRemark,@"remark",initInfo.avatarUrl,@"face",qq,@"qq",initInfo.sourceURL,@"visitUrl",initInfo.sourceTitle,@"visitTitle",@"自定义1",@"标题1",@"<a href=\"www.baidu.com\" target=\"_blank\">www.baidu.com</a>",@"内容3",nil];
    //    initInfo.customInfo = dict;
//        initInfo.customInfo = @{
    //
    //                            @"access-key":@"自定义1",
    //                            @"内容1":@"我是一个自定义字段。",
    //                            @"标题2":@"自定义字段2",
    //                            @"内容2":@"我是一个自定义字段，我是一个自定义字段，我是一个自定义字段，我是一个自定义字段。",
    //                            @"标题3":@"自定义字段字段3",
    //                            @"内容3":@"<a href=\"www.baidu.com\" target=\"_blank\">www.baidu.com</a>",
    //                            @"标题4":@"自定义4",
    //                            @"内容4":@"我是一个自定义字段 https://www.sobot.com/chat/pc/index.html?sysNum=9379837c87d2475dadd953940f0c3bc8&partnerId=112"
//                                };
    
    // 热点引导问题
    initInfo.isEnableHotGuide = YES;
    
    
    NSString * hotGuideWord = ZCUserDefaultsGetValue(@"hotGuideWord");
    
    if (hotGuideWord != nil && ![hotGuideWord isEqualToString:@""]) {
        NSMutableDictionary * hotdict = [NSMutableDictionary dictionaryWithCapacity:0];
        NSArray * hotarr = [hotGuideWord componentsSeparatedByString:@","];
        for (NSString * key in hotarr) {
            NSArray * keyarr = [key componentsSeparatedByString:@":"];
            if (keyarr.count == 2) {
                [hotdict setValue: [NSString stringWithFormat:@"%@",keyarr[1]] forKey:[NSString stringWithFormat:@"%@",keyarr[0]]];
            }
        }
        initInfo.hotguideDict = (NSDictionary*)hotdict;
        
    }
   
    
    
}


// 自定义参数 商品信息相关
- (void)customerGoodAndLeavePageWithParameter:(ZCKitInfo *)uiInfo{
    
    // 商品信息自定义

    
    if (ZCUserDefaultsGetValue(@"goods_Title")!= nil && ZCUserDefaultsGetValue(@"gPageUrl_Text")!= nil) {
        ZCProductInfo *productInfo = [ZCProductInfo new];
        productInfo.thumbUrl = ZCUserDefaultsGetValue(@"goods_IMG");
        productInfo.title = ZCUserDefaultsGetValue(@"goods_Title");
        productInfo.desc = ZCUserDefaultsGetValue(@"goods_SENDMGS");
        productInfo.label = ZCUserDefaultsGetValue(@"glabel_Text");
        productInfo.link = ZCUserDefaultsGetValue(@"gPageUrl_Text");
        uiInfo.productInfo = productInfo;
    }
    
    // 设置电话号和昵称（留言界面的显示）
    //    uiInfo.isAddNickName = _isAddNickSwitch.on;
    //    uiInfo.isShowNickName = _isShowNickSwitch.on;
    //    if(_hostTF.text!=nil){
    //        uiInfo.apiHost = _hostTF.text;
    //    }
    //    //    uiInfo.apiHost = @"http://test.sobot.com";
    
    if (_type != 1) {
        uiInfo.apiHost = ZCUserDefaultsGetValue(@"apiHost");
    }
}


@end
