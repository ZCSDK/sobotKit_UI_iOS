//
//  ZCSetServiceTypeVC.m
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/22.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import "ZCSetServiceTypeVC.h"


@interface ZCSetServiceTypeVC ()



@end

@implementation ZCSetServiceTypeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.bgScrollView.backgroundColor = UIColorFromRGB(0xEFF3FA);
    _type  = 0;
    
    [self setNavc];
    
    [self setSwitch];
    
    self.topLineView.backgroundColor = UIColorFromRGB(0xdadada);
    self.midLineView.backgroundColor = UIColorFromRGB(0xdadada);
    self.bottomLineView.backgroundColor = UIColorFromRGB(0xdadada);
    
    CGRect topLineF = self.topLineView.frame;
    topLineF.size.height = 0.5f;
    self.topLineView.frame = topLineF;
    
    CGRect midLineF = self.midLineView.frame;
    midLineF.size.height = 0.5f;
    self.midLineView.frame = midLineF;
    
    CGRect bottomLineF = self.bottomLineView.frame;
    bottomLineF.size.height = 0.5f;
    self.bottomLineView.frame = bottomLineF;

}

-(void)setNavc{

    self.title = @"接待模式";

    
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16],NSForegroundColorAttributeName:UIColorFromRGB(0x3D4966)}];
    UIButton * leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, NavBarHeight - 40, 70, 40);
    [leftBtn setImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
    leftBtn.imageView.transform = CGAffineTransformMakeRotation(M_PI);
    [leftBtn setTitleColor:UIColorFromRGB(0x3D4966) forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
    [leftBtn setContentEdgeInsets:UIEdgeInsetsZero];
    [leftBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [leftBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 15, 0, 0)];
    [leftBtn setTitle:@"返回" forState:UIControlStateNormal];
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    [leftBtn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.contentEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 0);
    UIBarButtonItem * leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    self.navigationItem.leftBarButtonItem = leftItem;
    

}

-(void)backAction:(UIButton *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)selectorswitchValueChanged:(UISwitch *)sender{
    switch (sender.tag) {
        case 101:
            if (sender.on) {
                // 接入方式,1只有机器人,2.仅人工 3.智能客服-机器人优先 4智能客服-人工客服优先
                //                _robotPreferredSwitch.on = YES;
                _onlyServiceSwitch.on = NO;
                _onlyRobotSwitch.on = NO;
                _artificialPrioritySwitch.on = NO;
                _type = 3;
            }else{
                _type = 0;
            }
            break;
        case 102:
            if (sender.on) {
                _robotPreferredSwitch.on = NO;
                _onlyServiceSwitch.on = NO;
                _onlyRobotSwitch.on = NO;
                //                _artificialPrioritySwitch.on = NO;
                _type = 4;
            }else{
                _type = 0;
            }
            break;
        case 103:
            if (sender.on) {
                _robotPreferredSwitch.on = NO;
                //                _onlyServiceSwitch.on = NO;
                _onlyRobotSwitch.on = NO;
                _artificialPrioritySwitch.on = NO;
                _type = 2;
            }else{
                _type = 0;
            }
            break;
        case 104:
            if (sender.on) {
                _robotPreferredSwitch.on = NO;
                _onlyServiceSwitch.on = NO;
                //                _onlyRobotSwitch.on = NO;
                _artificialPrioritySwitch.on = NO;
                _type = 1;
            }else{
                _type = 0;
            }
            break;
        default:
            break;
    }
    
    [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",_type] forKey:@"serverModel"];
//    [ZCLibClient getZCLibClient].libInitInfo.serviceMode = _type;
    if (_refreshValueBlock) {
        _refreshValueBlock();
    }
    
}

-(void)setSwitch{
    _robotPreferredSwitch.on = NO;
    _robotPreferredSwitch.tag = 101;
    [_robotPreferredSwitch addTarget:self action:@selector(selectorswitchValueChanged:) forControlEvents:UIControlEventValueChanged];
    
    _artificialPrioritySwitch.on = NO;
    _artificialPrioritySwitch.tag = 102;
    [_artificialPrioritySwitch addTarget:self action:@selector(selectorswitchValueChanged:) forControlEvents:UIControlEventValueChanged];
    
    _onlyServiceSwitch.on = NO;
    _onlyServiceSwitch.tag = 103;
    [_onlyServiceSwitch addTarget:self action:@selector(selectorswitchValueChanged:) forControlEvents:UIControlEventValueChanged];
    
    _onlyRobotSwitch.on = NO;
    _onlyRobotSwitch.tag = 104;
    [_onlyRobotSwitch addTarget:self action:@selector(selectorswitchValueChanged:) forControlEvents:UIControlEventValueChanged];
    
    
   _type = [[[NSUserDefaults standardUserDefaults] valueForKey:@"serverModel"] intValue];
    
    switch (_type) {
        case 1:
            _onlyRobotSwitch.on = YES;
            break;
        case 2:
            _onlyServiceSwitch.on = YES;
            break;
        case 3:
            _robotPreferredSwitch.on = YES;
            break;
        case 4:
            _artificialPrioritySwitch.on = YES;
            break;
            
        default:
            break;
    }
    
}






- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
