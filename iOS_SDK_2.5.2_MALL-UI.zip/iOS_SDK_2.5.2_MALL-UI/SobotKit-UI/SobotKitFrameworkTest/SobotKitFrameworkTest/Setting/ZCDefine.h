//
//  ZCDefine.h
//  SobotKitFrameworkTest
//
//  Created by lizhihui on 2017/11/20.
//  Copyright © 2017年 zhichi. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef NS_ENUM(NSInteger,LineType) {
    LineLayerBorder = 0,//边框线
    LineHorizontal  = 1,//竖线
    LineVertical    = 2,//横线
};
// 理想线宽
#define LINE_WIDTH                  1
// 实际应该显示的线宽
#define SINGLE_LINE_WIDTH           floor((LINE_WIDTH / [UIScreen mainScreen].scale)*100) / 100

//偏移的宽度
#define SINGLE_LINE_ADJUST_OFFSET   floor(((LINE_WIDTH / [UIScreen mainScreen].scale) / 2)*100) / 100


// 是否为iOS7或者iOS7以上的版本，如果设备版本<iOS7 返回NO 否则返回YES
#define iOS7                                ((floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_6_1)? NO:YES)
// 屏幕旋转后宽度的尺寸
#define ScreenWidth                         [[UIScreen mainScreen] bounds].size.width

// 屏幕旋转后高度的尺寸
#define ScreenHeight                        [[UIScreen mainScreen] bounds].size.height


#define SYSTEM_VERSION_GRATERTHAN_OR_EQUALTO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)

// iPhoneX
#define ZC_iPhoneX (ScreenWidth == 375.f && ScreenHeight == 812.f ? YES : NO)

// 导航栏的高度
//#define NavBarHeight                        (ZC_iPhoneX ? 88.f : (iOS7 ? 64.0 : 44.0))
#define NavBarHeight                        (ZC_iPhoneX ? 88.f : ( SYSTEM_VERSION_GRATERTHAN_OR_EQUALTO(@"11.0") ? 64.0 : 0))

// 状态栏的高度
#define StatusBarHeight                     (ZC_iPhoneX ? 44.f : (iOS7 ? 0.0 : 20.0))

#define TabBarHeight                       49


#define ZCScreenScale          (ScreenWidth / 375.0f)
#define ZCNumber(num)          (num*ZCScreenScale)


/**
 *  字体及大小
 *
 *  @return 字体大小
 */
#define TitleFont [UIFont fontWithName:@"Helvetica Neue" size:18.0]

#define AlertViewTitleFont [UIFont fontWithName:@"Helvetica Neue" size:17.0]
#define ListTitleFont [UIFont fontWithName:@"Helvetica Neue" size:16.0]
#define ListDetailFont [UIFont fontWithName:@"Helvetica Neue" size:14.0]
#define ListFileFont [UIFont fontWithName:@"Helvetica Neue" size:13.0]
#define ListTimeFont [UIFont fontWithName:@"Helvetica Neue" size:12.0]
#define FONT_CHAT    [UIFont fontWithName:@"Helvetica Neue" size:14.0]
#define ConfirmTitleFont  [UIFont fontWithName:@"Helvetica Neue" size:15.0]

#define BottomTitleFont [UIFont fontWithName:@"Helvetica Neue" size:10.0]
#define TimeLabelFont [UIFont fontWithName:@"Helvetica Neue" size:11.0]

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]


#define ZCUserDefaultsGET(key) [[NSUserDefaults standardUserDefaults] objectForKey:key] // 取
#define ZCUserDefaultsSET(object,key) [[NSUserDefaults standardUserDefaults] setObject:object forKey:key]  // 写
#define ZCUserDefaultsSynchronize [[NSUserDefaults standardUserDefaults] synchronize] // 存
#define ZCUserDefaultsRemove(key) [[NSUserDefaults standardUserDefaults] removeObjectForKey:key]  // 删
#define ZCZCUserDefaultsSetValue(object,key) [[NSUserDefaults standardUserDefaults] setValue:object forKey:key]// 写
#define ZCUserDefaultsGetValue(key) [[NSUserDefaults standardUserDefaults] valueForKey:key] // 取
#define ZCUUserDefaults  [NSUserDefaults standardUserDefaults]

