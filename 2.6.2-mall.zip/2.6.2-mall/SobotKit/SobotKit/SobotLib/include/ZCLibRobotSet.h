//
//  ZCLibRobotSet.h
//  SobotKit
//
//  Created by lizhihui on 2018/5/24.
//  Copyright © 2018年 zhichi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZCLibRobotSet : NSObject

@property (nonatomic,strong) NSString  *robotFlag;

@property (nonatomic,strong) NSString  *robotName;

@property (nonatomic,assign) BOOL      guideFlag; //机器人引导语开关

@property (nonatomic,strong) NSString * operationRemark; // 业务介绍

@property (nonatomic,strong) NSString * robotLog;// 机器人头像

-(id)initWithMyDict:(NSDictionary *)dict;
@end
