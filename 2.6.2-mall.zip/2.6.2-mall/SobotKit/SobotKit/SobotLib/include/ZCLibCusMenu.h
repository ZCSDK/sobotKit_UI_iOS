//
//  ZCLibCusMenu.h
//  SobotKit
//
//  Created by lizhihui on 2018/5/25.
//  Copyright © 2018年 zhichi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZCLibCusMenu : NSObject

@property (nonatomic,strong) NSString * title;

@property (nonatomic,strong) NSString * url;

@property (nonatomic,copy) NSString * lableId;

-(id)initWithMyDict:(NSDictionary *)dict;
@end
