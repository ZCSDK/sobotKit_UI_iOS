//
//  ZCTipsChatCell.h
//  SobotApp
//
//  Created by 张新耀 on 15/10/15.
//  Copyright © 2015年 com.sobot.chat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZCChatBaseCell.h"


/**
 *  ZC 提示气泡cell
 *  提示语 重新接入
 */
@interface ZCTipsChatCell : ZCChatBaseCell


@end
