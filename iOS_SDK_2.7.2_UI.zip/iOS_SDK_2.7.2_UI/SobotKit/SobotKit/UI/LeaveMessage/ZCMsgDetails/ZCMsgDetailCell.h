//
//  ZCMsgDetailCell.h
//  SobotKit
//
//  Created by lizhihui on 2019/2/20.
//  Copyright © 2019 zhichi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZCRecordListModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface ZCMsgDetailCell : UITableViewCell


-(void)initWithData:(ZCRecordListModel *)model IndexPath:(NSUInteger)row;

@end

NS_ASSUME_NONNULL_END
